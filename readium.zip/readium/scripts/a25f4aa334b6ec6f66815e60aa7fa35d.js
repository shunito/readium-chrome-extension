window.Readium={Models:{},Collections:{},Views:{},Routers:{},Utils:{},Init:function(){window.options=Readium.Models.ReadiumOptions.getInstance();window.optionsView=new Readium.Views.ReadiumOptionsView({model:window.options});window._library=new Readium.Collections.LibraryItems;window._lib_view=new Readium.Views.LibraryItemsView({collection:window._library});window._fp_view=new Readium.Views.FilePickerView({collection:window._library});window.router=new Readium.Routers.LibraryRouter({picker:window._fp_view});
Backbone.history.start({pushState:!1,root:"views/library.html"});_lawnchair=new Lawnchair(function(){this.all(function(a){a=_.reject(a,function(a){return a.key.split("_")[1]==="epubViewProperties"});window._library.reset(a)})});document.body.addEventListener("drop",function(a){a.stopPropagation();a.preventDefault();window._fp_view.handleFileSelect({target:a.dataTransfer})},!1);$("#block-view-btn").click(function(){$("#library-items-container").addClass("block-view").removeClass("row-view");Readium.Utils.setCookie("lib_view",
"block",1E3)});$("#row-view-btn").click(function(){$("#library-items-container").addClass("row-view").removeClass("block-view");Readium.Utils.setCookie("lib_view","row",1E3)})}};$(function(){window.Readium.Init()});
Readium.Utils.MD5=function(e){function h(a,b){var c,d,e,f,g;e=a&2147483648;f=b&2147483648;c=a&1073741824;d=b&1073741824;g=(a&1073741823)+(b&1073741823);return c&d?g^2147483648^e^f:c|d?g&1073741824?g^3221225472^e^f:g^1073741824^e^f:g^e^f}function i(a,b,c,d,e,f,g){a=h(a,h(h(b&c|~b&d,e),g));return h(a<<f|a>>>32-f,b)}function j(a,b,c,d,e,f,g){a=h(a,h(h(b&d|c&~d,e),g));return h(a<<f|a>>>32-f,b)}function k(a,b,d,c,e,f,g){a=h(a,h(h(b^d^c,e),g));return h(a<<f|a>>>32-f,b)}function l(a,b,d,c,e,f,g){a=h(a,h(h(d^
(b|~c),e),g));return h(a<<f|a>>>32-f,b)}function m(a){var b="",d="",c;for(c=0;c<=3;c++)d=a>>>c*8&255,d="0"+d.toString(16),b+=d.substr(d.length-2,2);return b}var f=[],n,o,p,q,a,b,c,d,e=function(a){for(var a=a.replace(/\r\n/g,"\n"),b="",d=0;d<a.length;d++){var c=a.charCodeAt(d);c<128?b+=String.fromCharCode(c):(c>127&&c<2048?b+=String.fromCharCode(c>>6|192):(b+=String.fromCharCode(c>>12|224),b+=String.fromCharCode(c>>6&63|128)),b+=String.fromCharCode(c&63|128))}return b}(e),f=function(a){var b,c=a.length;
b=c+8;for(var d=((b-b%64)/64+1)*16,e=Array(d-1),f=0,g=0;g<c;)b=(g-g%4)/4,f=g%4*8,e[b]|=a.charCodeAt(g)<<f,g++;e[(g-g%4)/4]|=128<<g%4*8;e[d-2]=c<<3;e[d-1]=c>>>29;return e}(e);a=1732584193;b=4023233417;c=2562383102;d=271733878;for(e=0;e<f.length;e+=16)n=a,o=b,p=c,q=d,a=i(a,b,c,d,f[e+0],7,3614090360),d=i(d,a,b,c,f[e+1],12,3905402710),c=i(c,d,a,b,f[e+2],17,606105819),b=i(b,c,d,a,f[e+3],22,3250441966),a=i(a,b,c,d,f[e+4],7,4118548399),d=i(d,a,b,c,f[e+5],12,1200080426),c=i(c,d,a,b,f[e+6],17,2821735955),
b=i(b,c,d,a,f[e+7],22,4249261313),a=i(a,b,c,d,f[e+8],7,1770035416),d=i(d,a,b,c,f[e+9],12,2336552879),c=i(c,d,a,b,f[e+10],17,4294925233),b=i(b,c,d,a,f[e+11],22,2304563134),a=i(a,b,c,d,f[e+12],7,1804603682),d=i(d,a,b,c,f[e+13],12,4254626195),c=i(c,d,a,b,f[e+14],17,2792965006),b=i(b,c,d,a,f[e+15],22,1236535329),a=j(a,b,c,d,f[e+1],5,4129170786),d=j(d,a,b,c,f[e+6],9,3225465664),c=j(c,d,a,b,f[e+11],14,643717713),b=j(b,c,d,a,f[e+0],20,3921069994),a=j(a,b,c,d,f[e+5],5,3593408605),d=j(d,a,b,c,f[e+10],9,38016083),
c=j(c,d,a,b,f[e+15],14,3634488961),b=j(b,c,d,a,f[e+4],20,3889429448),a=j(a,b,c,d,f[e+9],5,568446438),d=j(d,a,b,c,f[e+14],9,3275163606),c=j(c,d,a,b,f[e+3],14,4107603335),b=j(b,c,d,a,f[e+8],20,1163531501),a=j(a,b,c,d,f[e+13],5,2850285829),d=j(d,a,b,c,f[e+2],9,4243563512),c=j(c,d,a,b,f[e+7],14,1735328473),b=j(b,c,d,a,f[e+12],20,2368359562),a=k(a,b,c,d,f[e+5],4,4294588738),d=k(d,a,b,c,f[e+8],11,2272392833),c=k(c,d,a,b,f[e+11],16,1839030562),b=k(b,c,d,a,f[e+14],23,4259657740),a=k(a,b,c,d,f[e+1],4,2763975236),
d=k(d,a,b,c,f[e+4],11,1272893353),c=k(c,d,a,b,f[e+7],16,4139469664),b=k(b,c,d,a,f[e+10],23,3200236656),a=k(a,b,c,d,f[e+13],4,681279174),d=k(d,a,b,c,f[e+0],11,3936430074),c=k(c,d,a,b,f[e+3],16,3572445317),b=k(b,c,d,a,f[e+6],23,76029189),a=k(a,b,c,d,f[e+9],4,3654602809),d=k(d,a,b,c,f[e+12],11,3873151461),c=k(c,d,a,b,f[e+15],16,530742520),b=k(b,c,d,a,f[e+2],23,3299628645),a=l(a,b,c,d,f[e+0],6,4096336452),d=l(d,a,b,c,f[e+7],10,1126891415),c=l(c,d,a,b,f[e+14],15,2878612391),b=l(b,c,d,a,f[e+5],21,4237533241),
a=l(a,b,c,d,f[e+12],6,1700485571),d=l(d,a,b,c,f[e+3],10,2399980690),c=l(c,d,a,b,f[e+10],15,4293915773),b=l(b,c,d,a,f[e+1],21,2240044497),a=l(a,b,c,d,f[e+8],6,1873313359),d=l(d,a,b,c,f[e+15],10,4264355552),c=l(c,d,a,b,f[e+6],15,2734768916),b=l(b,c,d,a,f[e+13],21,1309151649),a=l(a,b,c,d,f[e+4],6,4149444226),d=l(d,a,b,c,f[e+11],10,3174756917),c=l(c,d,a,b,f[e+2],15,718787259),b=l(b,c,d,a,f[e+9],21,3951481745),a=h(a,n),b=h(b,o),c=h(c,p),d=h(d,q);return(m(a)+m(b)+m(c)+m(d)).toLowerCase()};
Readium.FileSystemApi=function(){var f,i=83886080,j=function(a){window.webkitRequestFileSystem(window.PERSITENT,i,function(b){f=b;a&&a(h)},d)},n=function(a){window.webkitStorageInfo.requestQuota(PERSISTENT,i,function(b){i=b;a(h)},function(b){console.log("Error",b);console.log("Exectution will not continue")})},d=function(a){var b="";switch(a.code){case FileError.QUOTA_EXCEEDED_ERR:b="QUOTA_EXCEEDED_ERR";break;case FileError.NOT_FOUND_ERR:b="NOT_FOUND_ERR";break;case FileError.SECURITY_ERR:b="SECURITY_ERR";
break;case FileError.INVALID_MODIFICATION_ERR:b="INVALID_MODIFICATION_ERR";break;case FileError.INVALID_STATE_ERR:b="INVALID_STATE_ERR";break;default:b="Unknown Error"}console.log("Error: "+b)},k=function(a,b){if(b[0]=="."||b[0]=="")b=b.slice(1);a.getDirectory(b[0],{create:!0},function(a){b.length&&k(a,b.slice(1))},d)},o=function(a,b,c,g,e){c.getFile(a,{create:!1},function(d){d.remove(function(){l(a,b,c,g,e)})},function(){l(a,b,c,g,e)})},l=function(a,b,c,g,e){c.getFile(a,{create:!0,exclusive:!1},
function(a){a.createWriter(function(a){var c;a.onwriteend=function(a){g(a)};a.onerror=function(a){e(a)};if(b instanceof Blob)a.write(b);else if(b.webkitRelativePath||b.relativePath){var d=new FileReader;d.onload=function(b){c=new WebKitBlobBuilder;c.append(b.target.result);a.write(c.getBlob())};d.readAsArrayBuffer(b)}else c=new WebKitBlobBuilder,typeof b==="string"?(c.append(b),a.write(c.getBlob("text/plain"))):(d=new Uint8Array(b),c.append(d.buffer),a.write(c.getBlob()))},e)},e)},m=function(a,b,
c,d,e){if(a[0]==="."||a[0]==="")a=a.slice(1);a.length===1?o(a[0],b,c,d,e):c.getDirectory(a[0],{create:!0},function(c){a=a.slice(1);m(a,b,c,d,e)},e)},h={writeFile:function(a,b,c,d){a=a.split("/");m(a,b,f.root,c,d)},getFileSystem:function(){return f},readEntry:function(a,b,c){a.file(function(d){var e=new FileReader;e.onloadend=function(){this.result?b(this.result,a):c&&c()};e.readAsText(d)},c||d)},readTextFile:function(a,b,c){var g=this;f.root.getFile(a,{},function(a){g.readEntry(a,b,c)},c||d)},rmdir:function(a){f.root.getDirectory(a,
{},function(a){a.removeRecursively(function(){console.log("Directory removed.")},d)},d)},getFsUri:function(a,b,c){f.root.getFile(a,{create:!0,exclusive:!1},function(a){b(a.toURL())},c||d)},mkdir:k,genericFsErrorHandler:d};return function(a){if(f)return a(h),h;webkitStorageInfo.queryUsageAndQuota(webkitStorageInfo.PERSITENT,function(b,c){c>0?j(a):n(function(){j(a)})})}}();
BBFileSystemSync=function(a,b,c){if(!b.file_path)throw"Cannot sync the model to the fs without a path";switch(a){case "read":Readium.FileSystemApi(function(a){a.readTextFile(b.file_path,function(a){c.success(a)},function(a){c.error(a)})});break;case "create":throw"Not yet implemented";case "update":throw"Not yet implemented";case "delete":throw"Not yet implemented";}return null};
Readium.Utils.Guid=function(){return"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(d){var b=Math.random()*16|0;return(d=="x"?b:b&3|8).toString(16)})};
Readium.Utils.LocalStorageAdaptor=function(d){var b,f=function(){localStorage.setItem(d,JSON.stringify(b))};return function(h,a,e){var c,g=localStorage.getItem(d);b=g&&JSON.parse(g)||{};switch(h){case "read":c=a.id?b[a.id]:_.values(b);break;case "create":if(!a.id)a.id=a.attributes.id=guid();b[a.id]=a;f();c=a;break;case "update":b[a.id]=a;f();c=a;break;case "delete":delete b[a.id],f(),c=a}c?e.success&&e.success(c):e.error&&e.error("Record not found")}};
Readium.Utils.setCookie=function(d,a,b){var c=new Date;c.setDate(c.getDate()+b);a=escape(a)+(b==null?"":"; expires="+c.toUTCString());document.cookie=d+"="+a};Readium.Utils.getCookie=function(d){var a,b,c,e=document.cookie.split(";");for(a=0;a<e.length;a++)if(b=e[a].substr(0,e[a].indexOf("=")),c=e[a].substr(e[a].indexOf("=")+1),b=b.replace(/^\s+|\s+$/g,""),b==d)return unescape(c)};Readium.Utils.trimString=function(d){return d.replace(/^\s+|\s+$/g,"")};
Handlebars.registerHelper("orUnknown",function(a){return a?a:chrome.i18n.getMessage("i18n_unknown")});Handlebars.registerHelper("fetchInzMessage",function(a){return new Handlebars.SafeString(chrome.i18n.getMessage(a))});
Readium.Models.ManifestItem=Backbone.Model.extend({parseMetaTags:function(){var a;typeof this.get("meta_width")==="undefined"&&(this.isSvg()?a=this.parseViewboxTag():this.isImage()||(a=this.parseViewportTag()),a&&this.set({meta_width:a.width,meta_height:a.height}))},getContentDom:function(){var a=this.get("content");if(a)return(new window.DOMParser).parseFromString(a,"text/xml")},parseViewportTag:function(){var a=this.getContentDom();if(a){a=a.getElementsByName("viewport")[0];if(!a)return null;for(var a=
a.getAttribute("content"),a=a.replace(/\s/g,""),a=a.split(","),b={},c,d=0;d<a.length;d++)c=a[d].split("="),c.length===2&&(b[c[0]]=c[1]);b.width=parseFloat(b.width,10);b.height=parseFloat(b.height,10);return b}},parseViewboxTag:function(){var a=this.getContentDom();if(a){var a=a.documentElement.getAttribute("viewBox").split(/,?\s+|,/),b={};b.width=parseFloat(a[2],10);b.height=parseFloat(a[3],10);return b}},resolvePath:function(a){return this.collection.packageDocument.resolvePath(a)},resolveUri:function(a){return this.collection.packageDocument.resolveUri(a)},
isSvg:function(){return this.get("media_type")==="image/svg+xml"},isImage:function(){var a=this.get("media_type");return a&&a.indexOf("image/")>-1?a!=="image/svg+xml":!1},loadContent:function(){var a=this,b=this.resolvePath(this.get("href"));Readium.FileSystemApi(function(c){c.readTextFile(b,function(b){a.set({content:b})},function(){console.log("Failed to load file: "+b)})})}});
Readium.Models.SpineItem=Readium.Models.ManifestItem.extend({initialize:function(){this.isFixedLayout()&&(this.on("change:content",this.parseMetaTags,this),this.loadContent())},buildSectionJSON:function(a,b){if(!a)return null;var c=Object.create(null);c.width=this.get("meta_width")||0;c.height=this.get("meta_height")||0;c.uri=this.packageDocument.resolveUri(a.get("href"));c.page_class=this.getPageSpreadClass(a,b);return c},toJSON:function(){this.isFixedLayout()&&this.parseMetaTags();var a={};a.width=
this.get("meta_width")||0;a.height=this.get("meta_height")||0;a.uri=this.resolveUri(this.get("href"));a.page_class=this.getPageSpreadClass();return a},getPageSpreadClass:function(){var a=this.collection.packageDocument.get("book"),b=this.get("spine_index");return a.get("apple_fixed")?b===0?"center_page":b%2===1&&b===this.collection.length?"center_page":b%2===0?"right_page":"left_page":this.get("page_spread")?(a=this.get("page_spread"),a==="left"?"left_page":a==="right"?"right_page":"center_page"):
this.get("page_prog_dir")==="rtl"?b%2===0?"right_page":"left_page":b%2===0?"left_page":"right_page"},isFixedLayout:function(){return this.isSvg()||this.isImage()?!0:typeof this.get("fixed_flow")!=="undefined"?this.get("fixed_flow"):this.collection.isBookFixedLayout()},getPageView:function(){if(!this.view)this.view=this.isImage()?new Readium.Views.ImagePageView({model:this}):new Readium.Views.FixedPageView({model:this});return this.view},hasMediaOverlay:function(){return!!this.get("media_overlay")&&
!!this.getMediaOverlay()},getMediaOverlay:function(){return this.collection.getMediaOverlay(this.get("media_overlay"))}});Readium.Collections.ManifestItems=Backbone.Collection.extend({model:Readium.Models.ManifestItem,initialize:function(a,b){this.packageDocument=b.packageDocument}});
Readium.Collections.Spine=Backbone.Collection.extend({model:Readium.Models.SpineItem,initialize:function(a,b){this.packageDocument=b.packageDocument},isBookFixedLayout:function(){return this.packageDocument.get("book").isFixedLayout()},getMediaOverlay:function(a){return this.packageDocument.getMediaOverlayItem(a)}});
Readium.Models.PackageDocumentParser=function(a){this.uri_obj=a};
Readium.Models.PackageDocumentParser.JathTemplate={metadata:{id:"//def:metadata/dc:identifier",epub_version:"//def:package/@version",title:"//def:metadata/dc:title",author:"//def:metadata/dc:creator",publisher:"//def:metadata/dc:publisher",description:"//def:metadata/dc:description",rights:"//def:metadata/dc:rights",language:"//def:metadata/dc:language",pubdate:"//def:metadata/dc:date",modified_date:"//def:metadata/def:meta[@property='dcterms:modified']",layout:"//def:metadata/def:meta[@property='rendition:layout']",
spread:"//def:metadata/def:meta[@property='rendition:spread']",orientation:"//def:metadata/def:meta[@property='rendition:orientation']",ncx:"//def:spine/@toc",page_prog_dir:"//def:spine/@page-progression-direction",active_class:"//def:metadata/def:meta[@property='media:active-class']"},manifest:["//def:item",{id:"@id",href:"@href",media_type:"@media-type",properties:"@properties",media_overlay:"@media-overlay"}],spine:["//def:itemref",{idref:"@idref",properties:"@properties",linear:"@linear"}],bindings:["//def:bindings/def:mediaType",
{handler:"@handler",media_type:"@media-type"}]};
Readium.Models.PackageDocumentParser.prototype.parse=function(a){var c;c=typeof a==="string"?(new window.DOMParser).parseFromString(a,"text/xml"):a;Jath.resolver=function(a){return{def:"http://www.idpf.org/2007/opf",dc:"http://purl.org/dc/elements/1.1/"}[a]};a=Jath.parse(Readium.Models.PackageDocumentParser.JathTemplate,c);a.paginate_backwards=this.paginateBackwards(c);if(c=this.getCoverHref(c))a.metadata.cover_href=this.resolveUri(c);if(a.metadata.layout==="pre-paginated")a.metadata.fixed_layout=
!0;a.manifest=new Readium.Collections.ManifestItems(a.manifest,{packageDocument:this});a.mo_map=this.resolveMediaOverlays(a.manifest);a.spine=this.parseSpineProperties(a.spine);return a};
Readium.Models.PackageDocumentParser.prototype.getCoverHref=function(a){var c,b;c=a.getElementsByTagName("manifest")[0];b=$('item[properties~="cover-image"]',c);if(b.length===1&&b.attr("href"))return b.attr("href");a=$('meta[name="cover"]',a);b=a.attr("content");if(a.length===1&&b&&(b=$('item[id="'+b+'"]',c),b.length===1&&b.attr("href")))return b.attr("href");b=$("#cover",c);return b.length===1&&b.attr("href")?b.attr("href"):null};
Readium.Models.PackageDocumentParser.prototype.parseSpineProperties=function(a){for(var c=function(a){for(var b={},a=a.split(" "),c=0;c<a.length;c++){if(a[c]==="rendition:page-spread-center")b.page_spread="center";if(a[c]==="page-spread-left")b.page_spread="left";if(a[c]==="page-spread-right")b.page_spread="right";if(a[c]==="page-spread-right")b.page_spread="right";if(a[c]==="rendition:layout-reflowable")b.fixed_flow=!1;if(a[c]==="rendition:layout-pre-paginated")b.fixed_flow=!0}return b},b=0;b<a.length;b++){var e=
c(a[b].properties);_.extend(a[b],e)}return a};Readium.Models.PackageDocumentParser.prototype.resolveMediaOverlays=function(a){var c=this,b={};a.forEach(function(a){if(a.get("media_type")==="application/smil+xml"){var d=c.resolveUri(a.get("href")),f=new Readium.Models.MediaOverlay;f.setUrl(d);f.fetch();b[a.id]=f}});return b};Readium.Models.PackageDocumentParser.prototype.paginateBackwards=function(a){return $("spine",a).attr("page-progression-direction")==="ltr"};
Readium.Models.PackageDocumentParser.prototype.crunchSpine=function(a,c){var b=this,e=-1,d=_.map(a,function(a){e+=1;var d=c.find(function(b){if(b.get("id")===a.idref)return b}),g=b.get("book");return _.extend({},a,d.attributes,{spine_index:e},{page_prog_dir:g.get("page_prog_dir")})});return new Readium.Collections.Spine(d,{packageDocument:this})};Readium.Models.PackageDocumentParser.prototype.resolveUri=function(a){uri=new URI(a);return uri.resolve(this.uri_obj).toString()};
Readium.Models.PackageDocument=Backbone.Model.extend({initialize:function(a){var b=this;if(a.file_path)this.file_path=a.file_path,Readium.FileSystemApi(function(a){a.getFsUri(b.file_path,function(a){b.uri_obj=new URI(a)})});else throw"This class cannot be synced without a file path";this.on("change:spine_position",this.onSpinePosChanged)},onSpinePosChanged:function(){this.get("spine_position")>=this.previous("spine_position")?this.trigger("increased:spine_position"):this.trigger("decreased:spine_position")},
validate:function(a){if(!a.manifest&&!this.get("manifest"))return"ERROR: All ePUBs must have a manifest";var b=a.spine||this.get("spine");if(!b)return"ERROR: All ePUBs must have a spine";if(a.spine_position<0||a.spine_position>=b.length)return"ERROR: invalid spine position"},sync:BBFileSystemSync,defaults:{spine_position:0},getManifestItemById:function(a){return this.get("manifest").find(function(b){if(b.get("id")===a)return b})},getSpineItem:function(a){return this.get("res_spine").at(a)},spineLength:function(){return this.get("res_spine").length},
getNextLinearSpinePostition:function(a){var b=this.get("res_spine");if(a===void 0||a<-1)a=-1;for(;a<b.length-1;)if(a+=1,b.at(a).get("linear")!=="no")return a;return-1},getPrevLinearSpinePostition:function(a){var b=this.get("res_spine");if(a===void 0||a>b.length)a=b.length;for(;a>0;)if(a-=1,b.at(a).get("linear")!=="no")return a;return-1},goToNextSection:function(){this.set({spine_position:this.get("spine_position")+1})},goToPrevSection:function(){this.set({spine_position:this.get("spine_position")-
1})},spineIndexFromHref:function(a){for(var b=this.get("res_spine"),a=this.resolveUri(a).replace(/#.*$/,""),c=0;c<b.length;c++){var d=b.at(c).get("href"),d=this.resolveUri(d).replace(/#.*$/,"");if(d===a)return c}return-1},goToHref:function(a){var b=this.get("spine"),c=this.get("manifest"),d=this,a=d.resolveUri(a).replace(/#.*$/,""),c=c.find(function(b){var c=d.resolveUri(b.get("href")).replace(/#.*$/,"");if(a==c)return b});if(!c)return null;for(var c=c.get("id"),e=0;e<b.length;++e)if(b[e].idref===
c){this.set({spine_position:e},{silent:!0});this._previousAttributes.spine_position=0;this.trigger("change:spine_position");break}},getTocItem:function(){var a=this.get("manifest"),b=this.get("metadata").ncx,c=a.find(function(a){return a.get("properties")==="nav"});return c?c:b&&b.length>0?a.find(function(a){return a.get("id")===b}):null},getMediaOverlayItem:function(a){var b=this.get("mo_map");return b&&b[a]},crunchSpine:function(a,b){var c=this,d=-1,e=_.map(a,function(a){d+=1;var e=b.find(function(b){if(b.get("id")===
a.idref)return b}),f=c.get("book");return _.extend({},a,e.attributes,{spine_index:d},{page_prog_dir:f.get("page_prog_dir")})});$.each(e,function(){this.id+=this.spine_index});return new Readium.Collections.Spine(e,{packageDocument:this})},parse:function(a){a=(new Readium.Models.PackageDocumentParser(this.uri_obj)).parse(a);a.res_spine=this.crunchSpine(a.spine,a.manifest);return a},resolveUri:function(a){uri=new URI(a);return uri.resolve(this.uri_obj).toString()},resolvePath:function(a){var b=this.file_path,
a=a.indexOf("../")===0?a.substr(3):a,c=b.lastIndexOf("/");return b.substr(0,c)+"/"+a}});
window.resolveLocalFileSystemURL=window.resolveLocalFileSystemURL||window.webkitResolveLocalFileSystemURL;window.BlobBuilder=window.BlobBuilder||window.WebKitBlobBuilder;window.g_uid_hashed=null;function PathResolver(a){this.baseUrl=new URI(a)}function encode_utf8(a){return unescape(encodeURIComponent(a))}function string2Bin(a){for(var c=[],b=0;b<a.length;b++)c.push(a.charCodeAt(b)&255);return c}
function string2ArrayBuffer(a){for(var c=new ArrayBuffer(a.length),b=new Uint8Array(c),d=0;d<a.length;d++)b[d]=a.charCodeAt(d);return c}function bin2String(a){return String.fromCharCode.apply(String,a)}PathResolver.prototype.resolve=function(a){return(new URI(a)).resolve(this.baseUrl)};
var domToString=function(a){return(new XMLSerializer).serializeToString(a)},fixCssLinks=function(a,c){var a=a.replace(/@import\s+(?:url\()*(.+?)(?:\))*\s*;/g,"@import url($1);"),b=/url\s*\(\s*['"]*\s*/,d=/['"]*\s*\)/;return a.replace(/url\s*\(\s*.+?\s*\)/g,function(a){a=a.replace(b,"");a=a.replace(d,"");return"url('"+c.resolve(a)+"')"})},fixXhtmlLinks=function(a,c){var b,d,f=(new window.DOMParser).parseFromString(a,"text/xml"),e=function(a){$("["+a+"]",f).each(function(){b=$(this);d=b.attr(a);d=c.resolve(d);
b.attr(a,d)})};e("src");e("href");$("image",f).each(function(){b=$(this);d=b.attr("xlink:href");d=c.resolve(d);b.attr("xlink:href",d)});if(e=f.getElementsByTagName("head")[0]){var g=e.innerHTML,g="<script type='text/javascript' src='"+window.location.origin+"/scripts/epub_reading_system.js' ><\/script>"+g;e.innerHTML=g}return domToString(f)},fixFonts=function(a){if(a.indexOf("OTTO")==0||a.indexOf("wOFF")==0)return a;else{for(var c=a.slice(0,1040),c=string2Bin(c),b=g_uid_hashed.length,d=0;d<1040;d++)c[d]^=
g_uid_hashed[d%b];return bin2String(c)+a.slice(1040)}},getBinaryFileFixingStrategy=function(a,c){if(a.substr(-4)===".otf"||a.substr(-5)===".woff"||a.substr(-4)===".OTF"||a.substr(-5)===".WOFF"){if(window.g_uid_hashed==null){var b=encode_utf8(c.trim()),b=window.Crypto.SHA1(b,{asBytes:!0});window.g_uid_hashed=b}return fixFonts}return null},getLinkFixingStrategy=function(a){return a.substr(-4)===".css"?fixCssLinks:a.substr(-5)===".html"||a.substr(-6)===".xhtml"?fixXhtmlLinks:a.substr(-4)===".xml"?fixXhtmlLinks:
null},monkeyPatchUrls=function(a,c,b,d){var f,e,g=new PathResolver(a),i=function(a){a=e(a,g);writeBinEntry(f,a,c,b)};e=getBinaryFileFixingStrategy(a,d);if(e!=null)window.resolveLocalFileSystemURL(a,function(a){f=a;readBinEntry(f,i,b)}),c();else{var h=getLinkFixingStrategy(a);if(h===null)c();else{var j=function(a){a=h(a,g);writeEntry(f,a,c,b)};window.resolveLocalFileSystemURL(a,function(a){f=a;readEntry(f,j,b)})}}},readEntry=function(a,c,b){a.file(function(a){var b=new FileReader;b.onloadend=function(){c(this.result)};
b.readAsText(a)},b)},writeEntry=function(a,c,b,d){Readium.FileSystemApi(function(f){f.writeFile(a.fullPath,c,b,d)})},readBinEntry=function(a,c,b){a.file(function(a){var b=new FileReader;b.onloadend=function(){c(this.result)};b.readAsBinaryString(a)},b)},writeBinEntry=function(a,c,b,d){a.createWriter(function(a){a.onwriteend=function(){b()};a.onerror=function(a){d(a)};var e=new BlobBuilder,g=string2ArrayBuffer(c);e.append(g);e=e.getBlob("image/jpeg");a.write(e)},d)};
Readium.Models.ReadiumOptions=Backbone.Model.extend({initialize:function(){this.set("id","singleton")},defaults:{hijack_epub_urls:!1,verbose_unpacking:!0,paginate_everything:!0},sync:Readium.Utils.LocalStorageAdaptor("READIUM_OPTIONS")},{getInstance:function(){var a=new Readium.Models.ReadiumOptions;a.fetch({error:function(){localStorage.setItem("READIUM_OPTIONS","");a.save()}});return a}});
Readium.FileSystemApi=function(){var f,i=83886080,j=function(a){window.webkitRequestFileSystem(window.PERSITENT,i,function(b){f=b;a&&a(h)},d)},n=function(a){window.webkitStorageInfo.requestQuota(PERSISTENT,i,function(b){i=b;a(h)},function(b){console.log("Error",b);console.log("Exectution will not continue")})},d=function(a){var b="";switch(a.code){case FileError.QUOTA_EXCEEDED_ERR:b="QUOTA_EXCEEDED_ERR";break;case FileError.NOT_FOUND_ERR:b="NOT_FOUND_ERR";break;case FileError.SECURITY_ERR:b="SECURITY_ERR";
break;case FileError.INVALID_MODIFICATION_ERR:b="INVALID_MODIFICATION_ERR";break;case FileError.INVALID_STATE_ERR:b="INVALID_STATE_ERR";break;default:b="Unknown Error"}console.log("Error: "+b)},k=function(a,b){if(b[0]=="."||b[0]=="")b=b.slice(1);a.getDirectory(b[0],{create:!0},function(a){b.length&&k(a,b.slice(1))},d)},o=function(a,b,c,g,e){c.getFile(a,{create:!1},function(d){d.remove(function(){l(a,b,c,g,e)})},function(){l(a,b,c,g,e)})},l=function(a,b,c,g,e){c.getFile(a,{create:!0,exclusive:!1},
function(a){a.createWriter(function(a){var c;a.onwriteend=function(a){g(a)};a.onerror=function(a){e(a)};if(b instanceof Blob)a.write(b);else if(b.webkitRelativePath||b.relativePath){var d=new FileReader;d.onload=function(b){c=new WebKitBlobBuilder;c.append(b.target.result);a.write(c.getBlob())};d.readAsArrayBuffer(b)}else c=new WebKitBlobBuilder,typeof b==="string"?(c.append(b),a.write(c.getBlob("text/plain"))):(d=new Uint8Array(b),c.append(d.buffer),a.write(c.getBlob()))},e)},e)},m=function(a,b,
c,d,e){if(a[0]==="."||a[0]==="")a=a.slice(1);a.length===1?o(a[0],b,c,d,e):c.getDirectory(a[0],{create:!0},function(c){a=a.slice(1);m(a,b,c,d,e)},e)},h={writeFile:function(a,b,c,d){a=a.split("/");m(a,b,f.root,c,d)},getFileSystem:function(){return f},readEntry:function(a,b,c){a.file(function(d){var e=new FileReader;e.onloadend=function(){this.result?b(this.result,a):c&&c()};e.readAsText(d)},c||d)},readTextFile:function(a,b,c){var g=this;f.root.getFile(a,{},function(a){g.readEntry(a,b,c)},c||d)},rmdir:function(a){f.root.getDirectory(a,
{},function(a){a.removeRecursively(function(){console.log("Directory removed.")},d)},d)},getFsUri:function(a,b,c){f.root.getFile(a,{create:!0,exclusive:!1},function(a){b(a.toURL())},c||d)},mkdir:k,genericFsErrorHandler:d};return function(a){if(f)return a(h),h;webkitStorageInfo.queryUsageAndQuota(webkitStorageInfo.PERSITENT,function(b,c){c>0?j(a):n(function(){j(a)})})}}();
Readium.Models.ValidatedPackageMetaData=Backbone.Model.extend({initialize:function(a){this.file_path=a.file_path;this.uri_obj=new URI(a.root_url);this.set("package_doc_path",this.file_path)},validate:function(){},reset:function(a){this.set(this.parse(a))},defaults:{fixed_layout:!1,apple_fixed:!1,open_to_spread:!1,cover_href:"/images/library/missing-cover-image.png",created_at:new Date,updated_at:new Date,paginate_backwards:!1},parseIbooksDisplayOptions:function(a){this.set((new Readium.Models.IbooksOptionsParser).parse(a))},
parse:function(a){a=(new Readium.Models.PackageDocumentParser(this.uri_obj)).parse(a);this.manifest=a.manifest;return a.metadata},save:function(a,b){var c=this;this.set("updated_at",new Date);Lawnchair(function(){this.save(c.toJSON(),b.success)})},resolveUri:function(a){uri=new URI(a);return uri.resolve(this.uri_obj).toString()},resolvePath:function(a){var b=this.file_path,a=a.indexOf("../")===0?a.substr(3):a,c=b.lastIndexOf("/");return b.substr(0,c)+"/"+a}});
Readium.Models.IbooksOptionsParser=function(){};Readium.Models.IbooksOptionsParser.prototype.parseBool=function(a){return a.toLowerCase().trim()==="true"};
Readium.Models.IbooksOptionsParser.prototype.parse=function(a){var b,c;b=(new window.DOMParser).parseFromString(a,"text/xml");a=b.getElementsByName("fixed-layout")[0];b=b.getElementsByName("open-to-spread")[0];c={};c.open_to_spread=!!b&&this.parseBool(b.textContent);c.fixedLayout=!!a&&this.parseBool(a.textContent);c.apple_fixed=!!a&&this.parseBool(a.textContent);return c};
Readium.Models.BookExtractorBase=Backbone.Model.extend({MIMETYPE:"mimetype",CONTAINER:"META-INF/container.xml",EPUB3_MIMETYPE:"application/epub+zip",DISPLAY_OPTIONS:"META-INF/com.apple.ibooks.display-options.xml",defaults:{task_size:100,progress:1,extracting:!1,log_message:"Fetching epub file"},clean:function(){this.removeHandlers();this.fsApi&&this.fsApi.rmdir(this.base_dir_name)},parseContainerRoot:function(a){var b=this.get("root_file_path");this.packageDoc=new Readium.Models.ValidatedPackageMetaData({key:this.base_dir_name,
src_url:this.get("src"),file_path:this.base_dir_name+"/"+b,root_url:this.get("root_url")+"/"+b});this.packageDoc.reset(a);this.trigger("parsed:root_file")},writeFile:function(a,b,c){var d=this;this.fsApi.writeFile(this.base_dir_name+"/"+a,b,c,function(){d.set("error","ERROR: while writing to filesystem")})},parseMetaInfo:function(a){a=(new window.DOMParser).parseFromString(a,"text/xml").getElementsByTagName("rootfile");a.length<1?this.set("error","This epub is not valid. The rootfile could not be located."):
a[0].hasAttribute("full-path")?this.set("root_file_path",a[0].attributes["full-path"].value):this.set("error","Error: could not find package rootfile")},validateMimetype:function(a){$.trim(a)===this.EPUB3_MIMETYPE?this.trigger("validated:mime"):this.set("error","Invalid mimetype discovered. Progress cancelled.")},removeHandlers:function(){this.off()},extraction_complete:function(){this.set("extracting",!1)},finish_extraction:function(){var a=this;this.set("log_message","Unpacking process completed successfully!");
this.packageDoc.save({},{success:function(){a.trigger("extraction_success")},failure:function(){a.set("failure","ERROR: unknown problem during unpacking process")}})},correctURIs:function(){var a=this.get("root_url"),b=this.get("patch_position"),c=this.get("manifest"),d=this.packageDoc.get("id"),e=this;b>=c.length?(this.off("change:patch_position"),this.finish_extraction()):(this.set("log_message","monkey patching: "+c[b]),monkeyPatchUrls(a+"/"+c[b],function(){e.incPatchPos()},function(){e.set("failure",
"ERROR: unknown problem during unpacking process")},d))},incPatchPos:function(){var a=this.get("patch_position")||0;a+=1;this.set("patch_position",a)}});
Readium.Models.ZipBookExtractor=Readium.Models.BookExtractorBase.extend({initialize:function(){zip.workerScriptsPath="../lib/";var a=this.get("src_filename");if(this.get("file"))this.base_dir_name=Readium.Utils.MD5(a+(new Date).toString()),this.set("src",a);else throw"A zip file must be specified";},extractEntryByName:function(a,b){var c,d;if(d=_.find(this.entries,function(b){return b.filename===a}))c=new zip.TextWriter,d.getData(c,b);else throw"asked to extract non-existent zip-entry: "+a;},extractContainerRoot:function(){var a=
this,b=this.get("root_file_path");try{this.extractEntryByName(b,function(b){a.parseContainerRoot(b)})}catch(c){this.set("error",c)}},extractMetaInfo:function(){var a=this;try{this.extractEntryByName(this.CONTAINER,function(b){a.parseMetaInfo(b)})}catch(b){this.set("error",b)}},extractMimetype:function(){var a=this;this.set("log_message","Verifying mimetype");try{this.extractEntryByName(this.MIMETYPE,function(b){a.validateMimetype(b)})}catch(b){this.set("error",b)}},validateZip:function(){var a=this;
this.set("log_message","Validating zip file");var b=_.any(this.entries,function(b){return b.filename===a.MIMETYPE}),c=_.any(this.entries,function(b){return b.filename===a.CONTAINER});b&&c?this.trigger("validated:zip"):this.set("error","File does not appear to be a valid EPUB. Progress cancelled.")},extractEntry:function(a){var b=this,c=new zip.BlobWriter;a.getData(c,function(c){b.writeFile(a.filename,c,function(){b.available_workers+=1;b.set("zip_position",b.get("zip_position")+1)})})},extractBook:function(){var a;
if(this.get("zip_position")===0)this.available_workers=5,this.entry_position=0,this.on("change:zip_position",this.checkCompletion,this);for(;this.available_workers>0&&this.entry_position<this.entries.length;)a=this.entries[this.entry_position],a.filename.substr(-1)==="/"?(this.entry_position+=1,this.set("zip_position",this.get("zip_position")+1)):(this.available_workers-=1,this.entry_position+=1,this.extractEntry(a));for(a=0;a<this.entries.length;a++);},parseIbooksDisplayOptions:function(){var a=
this;try{this.extractEntryByName(this.DISPLAY_OPTIONS,function(b){a.packageDoc.parseIbooksDisplayOptions(b);a.trigger("parsed:ibooks_options")})}catch(b){this.trigger("parsed:ibooks_options")}},checkCompletion:function(){var a=this.get("zip_position");a===this.entries.length?(this.set("log_message","All files unzipped successfully!"),this.set("patch_position",0)):this.set("log_message","extracting: "+this.entries[a].filename)},beginUnpacking:function(){for(var a=[],b,c=0;c<this.entries.length;c++)b=
this.entries[c],b.filename.substr(-1)!=="/"&&a.push(b.name);this.set("manifest",a);this.set("zip_position",0)},extract:function(){this.on("initialized:zip",this.validateZip,this);this.on("validated:zip",this.extractMimetype,this);this.on("validated:mime",this.extractMetaInfo,this);this.on("change:root_file_path",this.extractContainerRoot,this);this.on("parsed:root_file",this.parseIbooksDisplayOptions,this);this.on("parsed:ibooks_options",this.beginUnpacking,this);this.on("change:zip_position",this.extractBook,
this);this.on("change:patch_position",this.correctURIs,this);this.on("change:failure",this.clean,this);this.on("change:failure",this.removeHandlers,this);this.on("change:task_size",this.update_progress,this);this.on("change:zip_position",this.update_progress,this);this.on("change:patch_position",this.update_progress,this);this.on("extraction_success",this.extraction_complete,this);this.set("extracting",!0);var a=this;Readium.FileSystemApi(function(b){a.fsApi=b;a.initializeZip()})},update_progress:function(){var a=
this.get("zip_position")||0,b=this.get("patch_position")||0;this.set("progress",Math.floor((a+b+3)*100/this.get("task_size")))},initializeZip:function(){var a=this;this.fsApi.getFileSystem().root.getDirectory(this.base_dir_name,{create:!0},function(b){a.set("root_url",b.toURL());zip.createReader(new zip.BlobReader(a.get("file")),function(b){b.getEntries(function(b){a.entries=b;a.set("task_size",b.length*2+3);a.trigger("initialized:zip")})},function(){a.set("error","File does not appear to be a valid EPUB. Progress cancelled.")})},
function(){console.log("In beginUnpacking error handler. Does the root dir already exist?")})}});
Readium.Models.UnpackedBookExtractor=Readium.Models.BookExtractorBase.extend({initialize:function(){var a=this.get("dir_picker"),b=[],c;this.fNameStartInd=a.files[0].webkitRelativePath.indexOf("/")+1;this.base_dir_name=Readium.Utils.MD5("Banana"+(new Date).toString());this.fileList=a.files;for(a=0;c=this.fileList[a];++a)c=c.webkitRelativePath,c.substr(-2)!=="/."&&b.push(this.getShortName(c));this.set("src","Local Directory: "+this.fileList[0].webkitRelativePath.substring(0,this.fNameStartInd));this.set("task_size",
b.length*2+3);this.set("manifest",b)},getShortName:function(a){return a.substr(this.fNameStartInd)},update_progress:function(){var a=this.get("write_position")||0,b=this.get("patch_position")||0;this.set("progress",3+a+b)},extract:function(){this.on("validated:dir",this.readMime,this);this.on("validated:mime",this.readMetaInfo,this);this.on("change:root_file_path",this.readContainerRoot,this);this.on("parsed:root_file",this.parseIbooksDisplayOptions,this);this.on("parsed:ibooks_options",this.beginWriting,
this);this.on("change:write_position",this.writeEntry,this);this.on("change:patch_position",this.correctURIs,this);this.on("change:failure",this.clean,this);this.on("change:failure",this.removeHandlers,this);this.on("change:task_size",this.update_progress,this);this.on("change:write_position",this.update_progress,this);this.on("change:patch_position",this.update_progress,this);this.on("extraction_success",this.extraction_complete,this);this.set("extracting",!0);var a=this;Readium.FileSystemApi(function(b){a.fsApi=
b;b.getFileSystem().root.getDirectory(a.base_dir_name,{create:!0},function(b){a.set("root_url",b.toURL());a.validateDir()})})},parseIbooksDisplayOptions:function(){this.trigger("parsed:ibooks_options");var a=this;try{this.readEntryByShortName(this.DISPLAY_OPTIONS,function(b){a.packageDoc.parseIbooksDisplayOptions(b);a.trigger("parsed:ibooks_options")})}catch(b){this.trigger("parsed:ibooks_options")}},validateDir:function(){var a=this.get("manifest");a.indexOf(this.MIMETYPE)>=0&&a.indexOf(this.CONTAINER)>=
0?this.trigger("validated:dir"):this.set("error","the directory you selected was not valid")},readMime:function(){var a=this;this.set("log_message","Verifying mimetype");try{this.readEntryByShortName(this.MIMETYPE,function(b){a.validateMimetype(b)})}catch(b){this.set("error",b)}},readMetaInfo:function(){var a=this;try{this.readEntryByShortName(this.CONTAINER,function(b){a.parseMetaInfo(b)})}catch(b){this.set("error",b)}},readContainerRoot:function(){var a=this,b=this.get("root_file_path");try{this.readEntryByShortName(b,
function(b){a.parseContainerRoot(b)})}catch(c){this.set("error",c)}},beginWriting:function(){this.set("write_position",0)},writeEntry:function(){var a=this,b=this.get("write_position");if(b===this.fileList.length)this.set("patch_position",0);else{var c=this.fileList[b],d=this.getShortName(c.webkitRelativePath);this.set("log_message","writing: "+d);d.substr(-2)==="/."?this.set("write_position",b+1):this.writeFile(d,c,function(){a.set("write_position",b+1)})}},readEntryByShortName:function(a,b){for(var c=
!1,d=this.get("dir_picker").files,e=0;e<d.length;e++)if(this.getShortName(d[e].webkitRelativePath)===a){var c=!0,f=new FileReader;f.onload=function(a){b(a.target.result)};f.readAsText(d[e]);break}if(!c)throw"asked to read non-existent file: "+a;}});
Readium.Routers.LibraryRouter=Backbone.Router.extend({initialize:function(a){this.picker=a.picker},routes:{options:"showOptions","/unpack/*url":"beginExtraction"},showOptions:function(){$("#readium-options-modal").modal("show")},beginExtraction:function(a){this.picker.beginExtraction(new Readium.Models.ZipBookExtractor({url:a,src_filename:a}))}});
Timer=function(){};Timer.prototype.start=function(){this.start=new Date};Timer.prototype.stop=function(){this.stop=new Date};Timer.prototype.report=function(){console.log("===================Timer Report======================");console.log(this.stop-this.start);console.log("===================Timer Report======================")};
Readium.Models.LibraryItem=Backbone.Model.extend({idAttribute:"key",getViewBookUrl:function(){return"/views/viewer.html?book="+this.get("key")},openInReader:function(){window.location=this.getViewBookUrl()},destroy:function(){var a=this.get("key");Lawnchair(function(){var b=this;this.get(a,function(c){c&&Readium.FileSystemApi(function(d){d.rmdir(c.key);b.remove(a)})});propertiesKey=a+"_epubViewProperties";this.get(propertiesKey,function(a){a&&Readium.FileSystemApi(function(d){d.rmdir(a.key);b.remove(propertiesKey)})})})}});
Readium.Collections.LibraryItems=Backbone.Collection.extend({model:Readium.Models.LibraryItem});
Readium.Views.LibraryItemView=Backbone.View.extend({tagName:"div",className:"book-item",initialize:function(){this.template=Handlebars.templates.library_item_template},render:function(){var a=this.template({data:this.model.toJSON()});$(this.el).html(a);return this},events:{"click .delete":function(a){a.preventDefault();var b="#details-modal-"+this.model.get("key"),a="Are you sure you want to permanently delete ";a+=this.model.get("title");a+="?";confirm(a)&&($(b).modal("hide"),this.model.destroy(),
this.remove())},"click .read":function(){this.model.openInReader()}}});
Readium.Views.LibraryItemsView=Backbone.View.extend({tagName:"div",id:"library-items-container",className:"row-view",initialize:function(){this.template=Handlebars.templates.library_items_template;this.collection.bind("reset",this.render,this);this.collection.bind("add",this.addOne,this)},render:function(){var a=this.collection,b=this.template({}),c=this.$el;c.html(b);this.$("#empty-message").toggle(a.isEmpty());a.each(function(b){b=new Readium.Views.LibraryItemView({model:b,collection:a,id:b.get("id")});
c.append(b.render().el)});this.restoreViewType();$("#library-books-list").html(this.el);return this},restoreViewType:function(){Readium.Utils.getCookie("lib_view")==="block"&&this.$el.addClass("block-view").removeClass("row-view")},addOne:function(a){a=new Readium.Views.LibraryItemView({model:a,collection:this.collection,id:a.get("id")});this.$("#empty-message").toggle(!1);$(this.el).append(a.render().el)},events:{}});
Readium.Views.ExtractItemView=Backbone.View.extend({el:"#progress-container",initialize:function(){this.template=Handlebars.templates.extracting_item_template;this.model.bind("change",this.render,this);this.model.bind("change:error",this.extractionFailed,this)},render:function(){var a=$(this.el);this.model.get("extracting")?(a.html(this.template(this.model.toJSON())),a.show("slow")):a.hide("slow");return this},extractionFailed:function(){alert(this.model.get("error"));this.model.set("extracting",
!1)}});
Readium.Views.ReadiumOptionsView=Backbone.View.extend({el:"#readium-options-modal",initialize:function(){this.model.on("change",this.render,this);this.render()},render:function(){var a=this.model;this.$("#paginate_everything").prop("checked",a.get("paginate_everything"));this.$("#verbose_unpacking").prop("checked",a.get("verbose_unpacking"));this.$("#hijack_epub_urls").prop("checked",a.get("hijack_epub_urls"))},events:{"change #verbose_unpacking":"updateSettings","change #hijack_epub_urls":"updateSettings","change #paginate_everything":"updateSettings",
"click #save-settings-btn":"save"},updateSettings:function(){var a=this.$("#hijack_epub_urls").prop("checked"),b=this.$("#verbose_unpacking").prop("checked"),c=this.$("#paginate_everything").prop("checked");this.model.set({verbose_unpacking:b,hijack_epub_urls:a,paginate_everything:c})},save:function(){this.model.save();this.$el.modal("hide")}});
Readium.Views.FilePickerView=Backbone.View.extend({el:"#add-book-modal",events:{"change #files":"handleFileSelect","change #dir_input":"handleDirSelect","click #url-button":"handleUrl"},show:function(){this.$el.modal("show")},hide:function(){this.$el.modal("hide")},resetForm:function(){this.$("input").val("")},handleUrl:function(){var a=document.getElementById("book-url");a.value===null||a.value.length<1?alert("invalid url, cannot process"):(a=a.value,this.beginExtraction(new Readium.Models.ZipBookExtractor({url:a,
src_filename:a})))},handleFileSelect:function(a){a=a.target.files;this.beginExtraction(new Readium.Models.ZipBookExtractor({file:a[0],src_filename:a[0].name}))},handleDirSelect:function(a){this.beginExtraction(new Readium.Models.UnpackedBookExtractor({dir_picker:a.target}))},beginExtraction:function(a){var b=this,c=new Timer;c.start();window._extract_view=new Readium.Views.ExtractItemView({model:a});a.on("extraction_success",function(){var d=a.packageDoc.toJSON();c.stop();c.report();b.collection.add(new Readium.Models.LibraryItem(d));
b.resetForm();setTimeout(function(){chrome.tabs.create({url:"/views/viewer.html?book="+d.key})},800)});a.on("change:failure",this.resetForm,this);a.extract();this.hide()}});
Readium.Models.AudioClipPlayer=function(){function n(){function b(){a.removeEventListener("canplay",b);if(e>a.duration)f("File is shorter than specified clipEnd time"),e=a.duration;f("Audio data loaded");a.playbackRate=i;k()}f("Loading file "+g);a.setAttribute("src",g);a.addEventListener("canplay",b);a.addEventListener("ended",function(){c!=null&&clearInterval(c);d!=null&&d()})}function k(){if(l==!1&&a.currentTime>h&&a.currentTime<e)j(),a.play();else{a.addEventListener("seeked",b);f("setting currentTime from "+
a.currentTime+"to "+h);a.currentTime=h;var b=function(){a.removeEventListener("seeked",b);j();a.play()}}}function j(){c!=null&&clearInterval(c);c=setInterval(function(){a.currentTime>=e&&(clearInterval(c),f("clip done"),d!=null&&d())},11)}function f(a){m&&console.log("AudioClipPlayer: "+a)}var g=null,h=null,e=null,l=!1,a=new Audio,d=null,m=!1,c=null,i=1;this.setNotifyClipDone=function(a){d=a};this.setConsoleTrace=function(a){m=a};this.play=function(b,c,d,j){g=b;h=c;e=d;l=j;f("playing "+g+" from "+
h+" to "+e);a==null||a.getAttribute("src")!=g?n():(a.playbackRate=i,k())};this.isPlaying=function(){return a==null?!1:!a.paused};this.resume=function(){a!=null&&a.play()};this.pause=function(){a!=null&&a.pause()};this.setNotifyOnPause=function(b){a.addEventListener("pause",function(){b()})};this.setNotifyOnPlay=function(b){a.addEventListener("play",function(){b()})};this.getCurrentTime=function(){return a!=null?a.currentTime:0};this.getCurrentSrc=function(){return g};this.setVolume=function(b){a.volume=
b<0?0:b>1?1:b};this.setRate=function(b){if(this.isPlaying())a.playbackRate=b;i=b};this.getVolume=function(){return a.volume};this.getRate=function(){return i}};
Readium.Models.SmilModel=function(){function h(a){m(a);a.childNodes.length>0&&$.each(a.childNodes,function(a,b){h(b)})}function m(a){a.toString=function(){for(var a="<"+this.nodeName,b=0;b<this.attributes.length;b++)a+=" "+this.attributes.item(b).nodeName+"="+this.attributes.item(b).nodeValue;a+=">";return a};if(g.hasOwnProperty(a.tagName))a.render=g[a.tagName];if(i.hasOwnProperty(a.tagName))a.notifyChildDone=i[a.tagName];n(a)}function n(a){a.tagName=="audio"&&($(a).attr("src")!=void 0&&$(a).attr("src",
o($(a).attr("src"),j)),$(a).attr("clipBegin")!=void 0?$(a).attr("clipBegin",k($(a).attr("clipBegin"))):$(a).attr("clipBegin",0),$(a).attr("clipEnd")!=void 0?$(a).attr("clipEnd",k($(a).attr("clipEnd"))):$(a).attr("clipEnd",9999999))}function o(a,c){if(a.indexOf("://")!=-1)return a;var b=c;c[c.length-1]!="/"&&(b=c.substr(0,c.lastIndexOf("/")+1));return b+a}function k(a){var c=0,b=0,d=0;a.indexOf("min")!=-1?b=parseFloat(a.substr(0,a.indexOf("min"))):a.indexOf("ms")!=-1?d=parseFloat(a.substr(0,a.indexOf("ms")))/
1E3:a.indexOf("s")!=-1?d=parseFloat(a.substr(0,a.indexOf("s"))):a.indexOf("h")!=-1?c=parseFloat(a.substr(0,a.indexOf("h"))):(arr=a.split(":"),d=parseFloat(arr.pop()),arr.length>0&&(b=parseFloat(arr.pop()),arr.length>0&&(c=parseFloat(arr.pop()))));return c*3600+b*60+d}NodeLogic={parRender:function(){$.each(this.childNodes,function(a,c){c.hasOwnProperty("render")&&c.render()})},seqRender:function(a){a==null?this.firstElementChild.render():a.render()},audioNotifyChildDone:function(){this.parentNode.notifyChildDone(this)},
parNotifyChildDone:function(a){a.tagName=="audio"&&this.parentNode.notifyChildDone(this)},seqNotifyChildDone:function(a){a.nextElementSibling==null?this==e?l():this.parentNode.notifyChildDone(this):this.render(a.nextElementSibling)}};var g={seq:NodeLogic.seqRender,par:NodeLogic.parRender,body:NodeLogic.seqRender},i={seq:NodeLogic.seqNotifyChildDone,par:NodeLogic.parNotifyChildDone,body:NodeLogic.seqNotifyChildDone,audio:NodeLogic.audioNotifyChildDone,text:function(){}},j=null,l=null,e=null;this.addRenderers=
function(a){g=$.extend(g,a)};this.setUrl=function(a){j=a};this.setNotifySmilDone=function(a){l=a};this.build=function(a){e=a;h(a)};this.render=function(a){a==null||a==void 0||a==e?e.render(null):(this.peekNextAudio(a).isJumpTarget=!0,a.parentNode.render(a))};this.findNodeByAttrValue=function(a,c,b){if(e==null)return null;var d=null,f=c;if(f=="src"||f=="epub:textref"){f=="epub:textref"&&(f="epub\\:textref");var g=b.substr(b.lastIndexOf("/")+1),a=$(e).find(a+"["+f+"]");b==""?d=a[0]:a.each(function(){var a=
$(this).attr(f);if(a!=void 0&&(a=a.substr(a.lastIndexOf("/")+1),a===g))return d=this,!1})}else f!=""&&(a+="["+f,b!=""&&(a+="='"+b+"'"),a+="]"),d=$(e).find(a),d=d.length==0?null:d[0];return d};this.peekNextAudio=function(a){if(a.tagName=="par")return $(a).find("audio")[0];if(a.tagName=="text")return $(a.parentNode).find("audio")[0];for(a=a.parentNode;a.nextElementSibling==null;)if(a=a.parentNode,a==e)return null;return $(a.nextElementSibling).find("audio")[0]}};
Readium.Models.MediaOverlay=Backbone.Model.extend({audioplayer:null,smilModel:null,consoleTrace:!1,url:null,defaults:{current_text_src:null,has_started_playback:!1,is_document_done:!1,is_playing:!1,is_ready:!1},initialize:function(){var a=this;this.audioplayer=new Readium.Models.AudioClipPlayer;this.audioplayer.setConsoleTrace(!1);this.audioplayer.setNotifyOnPause(function(){a.set({is_playing:a.audioplayer.isPlaying()})});this.audioplayer.setNotifyOnPlay(function(){a.set({is_playing:a.audioplayer.isPlaying()})})},
setUrl:function(a){this.url=a},fetch:function(a){this.set({is_ready:!1});a=a||{};a.dataType="xml";Backbone.Model.prototype.fetch.call(this,a)},parse:function(a){var b=this;this.smilModel=new Readium.Models.SmilModel;this.smilModel.setUrl(this.url);this.smilModel.setNotifySmilDone(function(){b.debugPrint("document done");b.set({is_document_done:!0})});this.smilModel.addRenderers({audio:function(){var a=this;b.audioplayer.setNotifyClipDone(function(){a.notifyChildDone()});var c=!1;if(this.hasOwnProperty("isJumpTarget"))c=
this.isJumpTarget,this.isJumpTarget=!1;b.audioplayer.play($(this).attr("src"),parseFloat($(this).attr("clipBegin")),parseFloat($(this).attr("clipEnd")),c)},text:function(){var a=$(this).attr("src");b.debugPrint("Text: "+a);b.set("current_text_src",a)}});this.smilModel.build($(a).find("body")[0]);this.set({is_ready:!0})},startPlayback:function(a){this.get("is_ready")==!1?this.debugPrint("document not ready"):(this.set({is_document_done:!1}),this.set({has_started_playback:!0}),this.smilModel.render(a))},
pause:function(){this.get("is_ready")==!1?this.debugPrint("document not ready"):this.get("has_started_playback")==!1?this.debugPrint("can't pause: playback not yet started"):this.audioplayer.pause()},resume:function(){this.get("is_ready")==!1?this.debugPrint("document not ready"):this.get("has_started_playback")==!1?this.debugPrint("can't resume: playback not yet started"):this.audioplayer.resume()},findNodeByTextSrc:function(a){if(this.get("is_ready")==!1)return this.debugPrint("document not ready"),
null;if(a==null||a==void 0||a=="")return null;var b=this.smilModel.findNodeByAttrValue("text","src",a);b==null&&(b=this.smilModel.findNodeByAttrValue("seq","epub:textref",a));return b},setVolume:function(a){this.audioplayer.setVolume(a)},setRate:function(a){this.audioplayer.setRate(a)},getVolume:function(){return this.audioplayer.getVolume()},getRate:function(){return this.audioplayer.getRate()},reset:function(){this.set("current_text_src",null);this.set("has_started_playback",!1)},setConsoleTrace:function(a){this.consoleTrace=
a},debugPrint:function(a){this.consoleTrace&&console.log("MediaOverlay: "+a)}});
Readium.Models.EPUB=Backbone.Model.extend({defaults:{can_two_up:!0},initialize:function(){this.packageDocument=new Readium.Models.PackageDocument({book:this,file_path:this.get("package_doc_path")})},getPackageDocument:function(){return this.packageDocument},toJSON:function(){return{apple_fixed:this.get("apple_fixed"),author:this.get("author"),cover_href:this.get("cover_href"),created_at:this.get("created_at"),description:this.get("description"),epub_version:this.get("epub_version"),fixed_layout:this.get("fixed_layout"),
id:this.get("id"),key:this.get("key"),language:this.get("language"),layout:this.get("layout"),modified_date:this.get("modified_date"),ncx:this.get("ncx"),open_to_spread:this.get("open_to_spread"),orientation:this.get("orientation"),package_doc_path:this.get("package_doc_path"),page_prog_dir:this.get("page_prog_dir"),paginate_backwards:this.get("paginate_backwards"),pubdate:this.get("pubdate"),publisher:this.get("publisher"),rights:this.get("rights"),spread:this.get("spread"),src_url:this.get("src_url"),
title:this.get("title")}},resolvePath:function(a){return this.packageDocument.resolvePath(a)},isFixedLayout:function(){return this.get("fixed_layout")||this.get("apple_fixed")}});
Readium.Models.PageNumberDisplayLogic=Backbone.Model.extend({initialize:function(){},getGotoPageNumsToDisplay:function(a,b,d,e){return b?d?e==="rtl"?this.displayedPageIsLeft(a)?[a-1,a]:this.displayedPageIsRight(a)?[a,a+1]:[a]:this.displayedPageIsLeft(a)?[a,a+1]:this.displayedPageIsRight(a)?[a-1,a]:[a]:a%2===1?[a,a+1]:[a-1,a]:[a]},getPrevPageNumsToDisplay:function(a,b,d){return b?d==="rtl"?this.displayedPageIsLeft(a)&&this.displayedPageIsRight(a-1)?[a-1,a]:[a]:this.displayedPageIsRight(a)&&this.displayedPageIsLeft(a-
1)?[a-1,a]:[a]:[a-1,a]},getNextPageNumsToDisplay:function(a,b,d){return b?d==="rtl"?this.displayedPageIsRight(a)&&this.displayedPageIsLeft(a+1)?[a,a+1]:[a]:this.displayedPageIsLeft(a)&&this.displayedPageIsRight(a+1)?[a,a+1]:[a]:[a,a+1]},getPageNumbersForTwoUp:function(a,b,d,e){var c=[];a?c[0]=b[0]===0?1:b[0]:e?d==="rtl"?this.displayedPageIsLeft(b[0])?(c[0]=b[0]-1,c[1]=b[0]):this.displayedPageIsRight(b[0])&&(c[0]=b[0],c[1]=b[0]+1):this.displayedPageIsLeft(b[0])?(c[0]=b[0],c[1]=b[0]+1):this.displayedPageIsRight(b[0])&&
(c[0]=b[0]-1,c[1]=b[0]):b[0]%2===1?(c[0]=b[0],c[1]=b[0]+1):(c[0]=b[0]-1,c[1]=b[0]);return c},displayedPageIsRight:function(a){return $("#page-"+a).hasClass("right_page")?!0:!1},displayedPageIsLeft:function(a){return $("#page-"+a).hasClass("left_page")?!0:!1},displayedPageIsCenter:function(a){return $("#page-"+a).hasClass("center_page")?!0:!1}});
Readium.Models.ReadiumPagination=Backbone.Model.extend({defaults:{num_pages:0},initialize:function(){this.epubController=this.get("model");this.set("current_page",[this.epubController.get("spine_position")+1]);this.pageNumberDisplayLogic=new Readium.Models.PageNumberDisplayLogic;this.on("change:num_pages",this.adjustCurrentPage,this)},toggleTwoUp:function(){this.epubController.get("can_two_up")&&this.set({current_page:this.pageNumberDisplayLogic.getPageNumbersForTwoUp(this.epubController.get("two_up"),
this.get("current_page"),this.epubController.epub.get("page_prog_dir"),this.epubController.getCurrentSection().isFixedLayout())})},goRight:function(){this.epubController.epub.get("page_prog_dir")==="rtl"?this.prevPage():this.nextPage()},goLeft:function(){this.epubController.epub.get("page_prog_dir")==="rtl"?this.nextPage():this.prevPage()},goToPage:function(a){this.set("current_page",this.pageNumberDisplayLogic.getGotoPageNumsToDisplay(a,this.epubController.get("two_up"),this.epubController.getCurrentSection().isFixedLayout(),
this.epubController.epub.get("page_prog_dir")))},isPageVisible:function(a){return this.get("current_page").indexOf(a)!==-1},prevPage:function(){var a=this.get("current_page"),b=a[0]-1;this.epubController.set("hash_fragment",void 0);a[0]<=1?this.epubController.goToPrevSection():this.epubController.paginator.shouldScroll()&&!this.epubController.getCurrentSection().isFixedLayout()?this.epubController.goToPrevSection():this.epubController.get("two_up")?(this.set("current_page",this.pageNumberDisplayLogic.getPrevPageNumsToDisplay(b,
this.epubController.getCurrentSection().isFixedLayout(),this.epubController.epub.get("page_prog_dir"))),this.epubController.get("rendered_spine_items").length>1&&(a=this.epubController.get("rendered_spine_items")[b>1?b-2:0],this.epubController.set("spine_position",a))):(this.set("current_page",[b]),this.epubController.get("rendered_spine_items").length>1&&(a=this.epubController.get("rendered_spine_items")[b-1],this.epubController.set("spine_position",a)))},nextPage:function(){var a=this.get("current_page"),
b=a[a.length-1]+1;this.epubController.set("hash_fragment",void 0);a[a.length-1]>=this.get("num_pages")?this.epubController.goToNextSection():(this.epubController.get("two_up")?this.set("current_page",this.pageNumberDisplayLogic.getNextPageNumsToDisplay(b,this.epubController.getCurrentSection().isFixedLayout(),this.epubController.epub.get("page_prog_dir"))):this.set("current_page",[b]),this.epubController.get("rendered_spine_items").length>1&&(a=this.epubController.get("rendered_spine_items")[b-1],
this.epubController.set("spine_position",a)))},adjustCurrentPage:function(){var a=this.get("current_page"),b=this.get("num_pages");this.epubController.get("two_up");a[a.length-1]>b&&this.goToLastPage()},goToLastPage:function(){this.goToPage(this.get("num_pages"))}});
(function(){var h=Handlebars.template,i=Handlebars.templates=Handlebars.templates||{};i.binding_template=h(function(){return'<iframe scrolling="no" \n\t\tframeborder="0" \n\t\tmarginwidth="0" \n\t\tmarginheight="0" \n\t\twidth="100%" \n\t\theight="100%" \n\t\tclass=\'binding-sandbox\'>\n</iframe>'});i.extracting_item_template=h(function(e,c,d){var d=d||e.helpers,e="",a,b=d.helperMissing,f=this.escapeExpression;e+="<h5>";a=(a=d.log_message)||c.log_message;typeof a==="function"?a=a.call(c,{hash:{}}):
a===void 0&&(a=b.call(c,"log_message",{hash:{}}));e+=f(a)+'</h5>\n<div class="progress progress-striped progress-success active ">\t\n\t\t<div role="status" aria-live="assertive" aria-relevant="all" class="bar" style="width: ';a=(a=d.progress)||c.progress;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=b.call(c,"progress",{hash:{}}));e+=f(a)+'%;"></div>\n</div>';return e});i.fixed_page_template=h(function(e,c,d){var d=d||e.helpers,e="",a,b=d.helperMissing,f=this.escapeExpression;e+='<div class="fixed-page-margin">\n\t<iframe scrolling="no" \n\t\t\tframeborder="0" \n\t\t\tmarginwidth="0" \n\t\t\tmarginheight="0" \n\t\t\twidth="';
a=(a=d.width)||c.width;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=b.call(c,"width",{hash:{}}));e+=f(a)+'px" \n\t\t\theight="';a=(a=d.height)||c.height;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=b.call(c,"height",{hash:{}}));e+=f(a)+'px" \n\t\t\tsrc="';a=(a=d.uri)||c.uri;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=b.call(c,"uri",{hash:{}}));e+=f(a)+"\"\n\t\t\tclass='content-sandbox'>\n\t</iframe>\n</div>";return e});i.image_page_template=h(function(e,
c,d){var d=d||e.helpers,e="",a=d.helperMissing,b=this.escapeExpression;e+='<div class="fixed-page-margin">\n\t<img src="';d=d.uri||c.uri;typeof d==="function"?d=d.call(c,{hash:{}}):d===void 0&&(d=a.call(c,"uri",{hash:{}}));e+=b(d)+'" >\n</div>';return e});i.library_item_template=h(function(e,c,d){var d=d||e.helpers,e="",a,b,f=d.helperMissing,g=this.escapeExpression;e+="<div class='info-wrap'>\n\t<div class='caption book-info'>\n\t\t<h2 class='green info-item title'>";a=(b=d.data)||c.data;a=a===null||
a===void 0||a===!1?a:a.title;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.title",{hash:{}}));e+=g(a)+"</h2>\n\t\t<div class='info-item author'>";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.author;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='info-item epub-version'>ePUB ";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.epub_version;b=(b=d.orUnknown)||
c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t\n\t</div>\n\t\n\t<img class='cover-image read' src='";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.cover_href;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.cover_href",{hash:{}}));e+=g(a)+"' width='150' height='220' alt='Open ePUB ";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.title;typeof a==="function"?a=a.call(c,{hash:{}}):
a===void 0&&(a=f.call(c,"data.title",{hash:{}}));e+=g(a)+"'>\n\t\n\t<a href=\"#details-modal-";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.key;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.key",{hash:{}}));e+=g(a)+'" class="info-icon" data-toggle="modal" role="button">\n\t\t<img class=\'info-icon pull-right\' src=\'/images/library/info-icon.png\' height="39px" width="39px" alt=\'';a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.title;typeof a==="function"?
a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.title",{hash:{}}));e+=g(a)+' information\'>\n\t</a>\n</div>\n\n<div class="caption buttons">\n\t<a href="#todo" class="btn read" data-book=\'';a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.key;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.key",{hash:{}}));e+=g(a)+"' role='button'>";a="i18n_read";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",
a,{hash:{}}):b;e+=g(a)+'</a>\n\t<a href="#details-modal-';a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.key;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.key",{hash:{}}));e+=g(a)+'" class="btn details" data-toggle="modal" role="button">\n\t\t';a="i18n_details";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a)+"\n\t</a>\n</div>\n\n<div id='details-modal-";a=(b=d.data)||
c.data;a=a===null||a===void 0||a===!1?a:a.key;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.key",{hash:{}}));e+=g(a)+"' class='modal fade details-modal'>\n\t<div class=\"pull-left modal-cover-wrap\">\n\t\t<img class='details-cover-image' src='";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.cover_href;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.cover_href",{hash:{}}));e+=g(a)+"' width='150' height='220' alt='ePUB cover'>\n\t\t<div class=\"caption modal-buttons\">\n\t\t\t<a href=\"#\" class=\"btn read\" data-book='<%= data.key %>' role='button'>";
a="i18n_read";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a)+"</a>\n\t\t\t<a class=\"btn btn-danger delete pull-right\" role='button'>";a="i18n_delete";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a)+"</a>\n\t\t</div>\n\t</div>\n\t<div class='caption modal-book-info'>\n\t\t<h3 class='green modal-title'>";
a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.title;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.title",{hash:{}}));e+=g(a)+"</h3>\n\t\t<div class='modal-detail gap'>";a="i18n_author";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.author;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,
{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='modal-detail'>";a="i18n_publisher";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.publisher;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='modal-detail'>";
a="i18n_pub_date";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.pubdate;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='modal-detail'>";a="i18n_modified_date";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,
a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.modified_date;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='modal-detail gap'>";a="i18n_id";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;
a=a===null||a===void 0||a===!1?a:a.id;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='modal-detail green'>";a="i18n_epub_version";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.epub_version;b=(b=d.orUnknown)||c.orUnknown;a=typeof b===
"function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='modal-detail'>";a="i18n_created_at";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.created_at;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t</div>\n\t<div class='modal-detail source'>\n\t<span class='green' style=\"padding-right: 10px\">";
a="i18n_source";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a)+"</span>\n\t\t";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.src_url;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"\n\t</div>\n</div>\t\t\t";return e});i.library_items_template=h(function(e,c,d){var d=d||e.helpers,e="",a,b=d.helperMissing,
f=this.escapeExpression;e+="<div id='empty-message'>\n\t<p id='empty-message-text' class='green'>\n\t\t";a="i18n_add_items";d=d.fetchInzMessage||c.fetchInzMessage;a=typeof d==="function"?d.call(c,a,{hash:{}}):d===void 0?b.call(c,"fetchInzMessage",a,{hash:{}}):d;e+=f(a)+"\n\t</p>\n\t<img id='empty-arrow' src='/images/library/empty_library_arrow.png' alt='' />\n</div>";return e});i.ncx_nav_template=h(function(e,c,d){var d=d||e.helpers,e="",a,b=d.helperMissing,f=this.escapeExpression;e+='<li class="nav-elem">\n\t<a href="';
a=(a=d.href)||c.href;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=b.call(c,"href",{hash:{}}));e+=f(a)+'">';a=(a=d.text)||c.text;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=b.call(c,"text",{hash:{}}));e+=f(a)+"</a>\n</li>";return e});i.reflowing_template=h(function(e,c,d){var d=d||e.helpers,e="",a=d.helperMissing,b=this.escapeExpression;e+='<div id="flowing-wrapper">\n\t<iframe scrolling="no" \n\t\t\tframeborder="0" \n\t\t\tmarginwidth="0" \n\t\t\tmarginheight="0" \n\t\t\twidth="50%" \n\t\t\theight="100%" \n\t\t\tsrc="';
d=d.uri||c.uri;typeof d==="function"?d=d.call(c,{hash:{}}):d===void 0&&(d=a.call(c,"uri",{hash:{}}));e+=b(d)+'"\n\t\t\tid="readium-flowing-content">\n\t</iframe>\n</div>';return e});i.scrolling_page_template=h(function(e,c,d){var d=d||e.helpers,e="",a=d.helperMissing,b=this.escapeExpression;e+='<div id="scrolling-content" class="scrolling-page-wrap">\n\t<div class="scrolling-page-margin">\n\n\t\t<iframe scrolling="yes" \n\t\t\t\tframeborder="0" \n\t\t\t\tmarginwidth="0" \n\t\t\t\tmarginheight="0" \n\t\t\t\twidth="100%" \n\t\t\t\theight="100%" \n\t\t\t\tsrc="';
d=d.uri||c.uri;typeof d==="function"?d=d.call(c,{hash:{}}):d===void 0&&(d=a.call(c,"uri",{hash:{}}));e+=b(d)+"\"\n\t\t\t\tclass='content-sandbox'>\n\t\t</iframe>\n\t</div>\n</div>";return e})})();
Readium.Models.MediaOverlayController=Backbone.Model.extend({defaults:{active_mo:null,mo_text_id:null,rate:1,volume:1},initialize:function(){this.currentSection=this.mo=null;this.processingMoTextSrc=this.autoplayNextSpineItem=!1;this.moTargetNode=null;this.savedVolume=0;this.currentView=this.pages=null;this.epubController=this.get("epubController");this.epubController.on("change:spine_position",this.handleSpineChanged,this);this.on("change:rate",this.rateChanged,this);this.on("change:volume",this.volumeChanged,
this)},setPages:function(a){this.pages!=null&&this.pages.off();this.pages=a},setView:function(a){this.currentView=a},playMo:function(){if(this.mo==null)alert("Sorry, there is no audio for this section.");else{this.set("active_mo",this.mo);this.mo.on("change:current_text_src",this.handleMoTextSrc,this);this.mo.on("change:is_document_done",this.handleMoDocumentDone,this);var a=this.moTargetNode;this.moTargetNode=null;if(this.currentSection.isFixedLayout())this.mo.get("has_started_playback")?this.resumeMo():
this.mo.startPlayback(null);else{var b=-1,c=this.get("mo_text_id");c!=null&&c!=void 0&&c!=""&&(b=this.currentView.getElemPageNumberById(c));this.pages.get("current_page").indexOf(b)!=-1?this.resumeMo():this.mo.startPlayback(a)}}},pauseMo:function(){this.mo&&(this.mo.off(),this.mo.pause(),this.set("active_mo",null))},mute:function(){if(this.mo)this.mo.getVolume()==0?this.set("volume",this.savedVolume):(this.savedVolume=this.mo.getVolume(),this.set("volume",0))},volumeChanged:function(){this.mo&&this.mo.setVolume(this.get("volume"))},
rateChanged:function(){this.mo&&this.mo.setRate(this.get("rate"))},reflowPageChanged:function(){if(!this.processingMoTextSrc&&!this.autoplayNextSpineItem){var a=this.get("active_mo")!=null;a&&this.pauseMo();this.setMoTarget();a&&this.playMo()}},pagesLoaded:function(){if(!this.currentSection.isFixedLayout()&&this.autoplayNextSpineItem==!0)this.autoplayNextSpineItem=!1,this.playMo()},resumeMo:function(){this.set("mo_text_id",null);this.handleMoTextSrc();this.mo.resume()},handleMoTextSrc:function(){var a=
this.mo.get("current_text_src");if(a==null)this.set("mo_text_id",null);else{this.processingMoTextSrc=!0;this.epubController.goToHref(a);var b="";a.indexOf("#")!=-1&&a.indexOf("#")<a.length-1&&(b=a.substr(a.indexOf("#")+1));this.set("mo_text_id",b);this.processingMoTextSrc=!1}},handleMoDocumentDone:function(){if(!(this.mo!=null&&this.mo!=void 0&&this.mo.get("is_document_done")==!1)&&(this.moTargetNode=null,this.pauseMo(),this.epubController.hasNextSection()))this.autoplayNextSpineItem=!0,this.epubController.goToNextSection()},
handleSpineChanged:function(){this.set("mo_text_id",null);if(this.epubController.getCurrentSection()!=this.currentSection){if(this.get("active_mo")!=null)this.autoplayNextSpineItem=!0,this.pauseMo();this.currentSection=this.epubController.getCurrentSection();this.mo=this.currentSection.getMediaOverlay();if(this.mo!=null&&(this.mo.setVolume(this.get("volume")),this.mo.setRate(this.get("rate")),this.mo.reset(),this.currentSection.isFixedLayout()&&this.autoplayNextSpineItem))this.autoplayNextSpineItem=
!1,this.playMo()}},setMoTarget:function(){var a,b;if(this.mo!=null)if(this.currentSection.isFixedLayout())this.moTargetNode=null;else{a=this.currentView.findVisiblePageElements();var c=this.currentSection.get("href");b=null;for(var d=0;d<a.length;d++)if(b=$(a[d]).attr("id"),b=this.mo.findNodeByTextSrc(c+"#"+b))break;this.moTargetNode=b}}});
Readium.Models.MediaOverlayViewHelper=Backbone.Model.extend({initialize:function(){this.epubController=this.get("epubController")},addActiveClass:function(a){var c=this.getActiveClass();a.toggleClass(c,!0)},removeActiveClass:function(a){if(a!=null&&a!=void 0){var c=this.getActiveClass(),a=$(a).find("."+c);a.toggleClass(c,!1);return a}return null},renderFixedLayoutMoFragHighlight:function(a,c,b){var d=this;$.each(a,function(){var a=b.getPageBody(this);d.removeActiveClass(a)});c&&$.each(a,function(){var a=
b.getPageBody(this);(a=$(a).find("#"+c))&&d.addActiveClass(a)})},renderFixedMoPlaying:function(a,c,b){var d=this;this.authorActiveClassExists()&&(c||$.each(a,function(){var a=b.getPageBody(this);d.removeActiveClass(a)}))},renderReflowableMoFragHighlight:function(a,c,b){a==="default"&&(a="default-theme");var d=c.getBody(),e=this.removeActiveClass(d);this.authorActiveClassExists()==!1&&e&&$(e).css("color","");if(b&&(b=$(d).find("#"+b)))this.addActiveClass(b),this.authorActiveClassExists()==!1&&$(b).css("color",
c.themes[a].color)},renderReflowableMoPlaying:function(a,c,b){if(this.authorActiveClassExists()){if(!c)var d=b.getBody(),a=this.removeActiveClass(d)}else a==="default"&&(a="default-theme"),d=b.getBody(),c?$(d).css("color",b.themes[a]["mo-color"]):($(d).css("color",b.themes[a].color),(a=this.removeActiveClass(b.getBody()))&&$(a).css("color",""))},getActiveClass:function(){var a=this.epubController.packageDocument.get("metadata").active_class;a==""&&(a="-readium-epub-media-overlay-active");return a},
authorActiveClassExists:function(){return this.epubController.packageDocument.get("metadata").active_class==""?!1:!0}});
for(var elems=document.getElementsByTagName("span"),i=0;i<elems.length;i++)if(elems[i].id!=null)if(elems[i].id.indexOf("i18n_html_",0)==0){var msg=chrome.i18n.getMessage(elems[i].id);if(msg!="")elems[i].innerHTML=msg}else if(elems[i].id.indexOf("i18n_",0)==0&&(msg=chrome.i18n.getMessage(elems[i].id),msg!=""))elems[i].innerText=msg;
(function(global) {
    
    var EPUBcfi = {};

    EPUBcfi.Parser = (function(){
  /*
   * Generated by PEG.js 0.7.0.
   *
   * http://pegjs.majda.cz/
   */
  
  function quote(s) {
    /*
     * ECMA-262, 5th ed., 7.8.4: All characters may appear literally in a
     * string literal except for the closing quote character, backslash,
     * carriage return, line separator, paragraph separator, and line feed.
     * Any character may appear in the form of an escape sequence.
     *
     * For portability, we also escape escape all control and non-ASCII
     * characters. Note that "\0" and "\v" escape sequences are not used
     * because JSHint does not like the first and IE the second.
     */
     return '"' + s
      .replace(/\\/g, '\\\\')  // backslash
      .replace(/"/g, '\\"')    // closing quote character
      .replace(/\x08/g, '\\b') // backspace
      .replace(/\t/g, '\\t')   // horizontal tab
      .replace(/\n/g, '\\n')   // line feed
      .replace(/\f/g, '\\f')   // form feed
      .replace(/\r/g, '\\r')   // carriage return
      .replace(/[\x00-\x07\x0B\x0E-\x1F\x80-\uFFFF]/g, escape)
      + '"';
  }
  
  var result = {
    /*
     * Parses the input with a generated parser. If the parsing is successfull,
     * returns a value explicitly or implicitly specified by the grammar from
     * which the parser was generated (see |PEG.buildParser|). If the parsing is
     * unsuccessful, throws |PEG.parser.SyntaxError| describing the error.
     */
    parse: function(input, startRule) {
      var parseFunctions = {
        "fragment": parse_fragment,
        "path": parse_path,
        "local_path": parse_local_path,
        "indexStep": parse_indexStep,
        "indirectionStep": parse_indirectionStep,
        "terminus": parse_terminus,
        "idAssertion": parse_idAssertion,
        "textLocationAssertion": parse_textLocationAssertion,
        "parameter": parse_parameter,
        "csv": parse_csv,
        "valueNoSpace": parse_valueNoSpace,
        "value": parse_value,
        "escapedSpecialChars": parse_escapedSpecialChars,
        "number": parse_number,
        "integer": parse_integer,
        "space": parse_space,
        "circumflex": parse_circumflex,
        "doubleQuote": parse_doubleQuote,
        "squareBracket": parse_squareBracket,
        "parentheses": parse_parentheses,
        "comma": parse_comma,
        "semicolon": parse_semicolon,
        "equal": parse_equal,
        "character": parse_character
      };
      
      if (startRule !== undefined) {
        if (parseFunctions[startRule] === undefined) {
          throw new Error("Invalid rule name: " + quote(startRule) + ".");
        }
      } else {
        startRule = "fragment";
      }
      
      var pos = 0;
      var reportFailures = 0;
      var rightmostFailuresPos = 0;
      var rightmostFailuresExpected = [];
      
      function padLeft(input, padding, length) {
        var result = input;
        
        var padLength = length - input.length;
        for (var i = 0; i < padLength; i++) {
          result = padding + result;
        }
        
        return result;
      }
      
      function escape(ch) {
        var charCode = ch.charCodeAt(0);
        var escapeChar;
        var length;
        
        if (charCode <= 0xFF) {
          escapeChar = 'x';
          length = 2;
        } else {
          escapeChar = 'u';
          length = 4;
        }
        
        return '\\' + escapeChar + padLeft(charCode.toString(16).toUpperCase(), '0', length);
      }
      
      function matchFailed(failure) {
        if (pos < rightmostFailuresPos) {
          return;
        }
        
        if (pos > rightmostFailuresPos) {
          rightmostFailuresPos = pos;
          rightmostFailuresExpected = [];
        }
        
        rightmostFailuresExpected.push(failure);
      }
      
      function parse_fragment() {
        var result0, result1, result2;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        if (input.substr(pos, 8) === "epubcfi(") {
          result0 = "epubcfi(";
          pos += 8;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"epubcfi(\"");
          }
        }
        if (result0 !== null) {
          result1 = parse_path();
          if (result1 !== null) {
            if (input.charCodeAt(pos) === 41) {
              result2 = ")";
              pos++;
            } else {
              result2 = null;
              if (reportFailures === 0) {
                matchFailed("\")\"");
              }
            }
            if (result2 !== null) {
              result0 = [result0, result1, result2];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, pathVal) { 
                
                return { type:"CFIAST", cfiString:pathVal }; 
            })(pos0, result0[1]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_path() {
        var result0, result1;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        result0 = parse_indexStep();
        if (result0 !== null) {
          result1 = parse_local_path();
          if (result1 !== null) {
            result0 = [result0, result1];
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, stepVal, localPathVal) { 
        
                return { type:"cfiString", path:stepVal, localPath:localPathVal }; 
            })(pos0, result0[0], result0[1]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_local_path() {
        var result0, result1;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        result1 = parse_indexStep();
        if (result1 === null) {
          result1 = parse_indirectionStep();
        }
        if (result1 !== null) {
          result0 = [];
          while (result1 !== null) {
            result0.push(result1);
            result1 = parse_indexStep();
            if (result1 === null) {
              result1 = parse_indirectionStep();
            }
          }
        } else {
          result0 = null;
        }
        if (result0 !== null) {
          result1 = parse_terminus();
          result1 = result1 !== null ? result1 : "";
          if (result1 !== null) {
            result0 = [result0, result1];
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, localPathStepVal, termStepVal) { 
        
                return { steps:localPathStepVal, termStep:termStepVal }; 
            })(pos0, result0[0], result0[1]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_indexStep() {
        var result0, result1, result2, result3, result4;
        var pos0, pos1, pos2;
        
        pos0 = pos;
        pos1 = pos;
        if (input.charCodeAt(pos) === 47) {
          result0 = "/";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"/\"");
          }
        }
        if (result0 !== null) {
          result1 = parse_integer();
          if (result1 !== null) {
            pos2 = pos;
            if (input.charCodeAt(pos) === 91) {
              result2 = "[";
              pos++;
            } else {
              result2 = null;
              if (reportFailures === 0) {
                matchFailed("\"[\"");
              }
            }
            if (result2 !== null) {
              result3 = parse_idAssertion();
              if (result3 !== null) {
                if (input.charCodeAt(pos) === 93) {
                  result4 = "]";
                  pos++;
                } else {
                  result4 = null;
                  if (reportFailures === 0) {
                    matchFailed("\"]\"");
                  }
                }
                if (result4 !== null) {
                  result2 = [result2, result3, result4];
                } else {
                  result2 = null;
                  pos = pos2;
                }
              } else {
                result2 = null;
                pos = pos2;
              }
            } else {
              result2 = null;
              pos = pos2;
            }
            result2 = result2 !== null ? result2 : "";
            if (result2 !== null) {
              result0 = [result0, result1, result2];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, stepLengthVal, assertVal) { 
        
                return { type:"indexStep", stepLength:stepLengthVal, idAssertion:assertVal[1] };
            })(pos0, result0[1], result0[2]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_indirectionStep() {
        var result0, result1, result2, result3, result4;
        var pos0, pos1, pos2;
        
        pos0 = pos;
        pos1 = pos;
        if (input.substr(pos, 2) === "!/") {
          result0 = "!/";
          pos += 2;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"!/\"");
          }
        }
        if (result0 !== null) {
          result1 = parse_integer();
          if (result1 !== null) {
            pos2 = pos;
            if (input.charCodeAt(pos) === 91) {
              result2 = "[";
              pos++;
            } else {
              result2 = null;
              if (reportFailures === 0) {
                matchFailed("\"[\"");
              }
            }
            if (result2 !== null) {
              result3 = parse_idAssertion();
              if (result3 !== null) {
                if (input.charCodeAt(pos) === 93) {
                  result4 = "]";
                  pos++;
                } else {
                  result4 = null;
                  if (reportFailures === 0) {
                    matchFailed("\"]\"");
                  }
                }
                if (result4 !== null) {
                  result2 = [result2, result3, result4];
                } else {
                  result2 = null;
                  pos = pos2;
                }
              } else {
                result2 = null;
                pos = pos2;
              }
            } else {
              result2 = null;
              pos = pos2;
            }
            result2 = result2 !== null ? result2 : "";
            if (result2 !== null) {
              result0 = [result0, result1, result2];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, stepLengthVal, assertVal) { 
        
                return { type:"indirectionStep", stepLength:stepLengthVal, idAssertion:assertVal[1] };
            })(pos0, result0[1], result0[2]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_terminus() {
        var result0, result1, result2, result3, result4;
        var pos0, pos1, pos2;
        
        pos0 = pos;
        pos1 = pos;
        if (input.charCodeAt(pos) === 58) {
          result0 = ":";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\":\"");
          }
        }
        if (result0 !== null) {
          result1 = parse_integer();
          if (result1 !== null) {
            pos2 = pos;
            if (input.charCodeAt(pos) === 91) {
              result2 = "[";
              pos++;
            } else {
              result2 = null;
              if (reportFailures === 0) {
                matchFailed("\"[\"");
              }
            }
            if (result2 !== null) {
              result3 = parse_textLocationAssertion();
              if (result3 !== null) {
                if (input.charCodeAt(pos) === 93) {
                  result4 = "]";
                  pos++;
                } else {
                  result4 = null;
                  if (reportFailures === 0) {
                    matchFailed("\"]\"");
                  }
                }
                if (result4 !== null) {
                  result2 = [result2, result3, result4];
                } else {
                  result2 = null;
                  pos = pos2;
                }
              } else {
                result2 = null;
                pos = pos2;
              }
            } else {
              result2 = null;
              pos = pos2;
            }
            result2 = result2 !== null ? result2 : "";
            if (result2 !== null) {
              result0 = [result0, result1, result2];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, textOffsetValue, textLocAssertVal) { 
        
                return { type:"textTerminus", offsetValue:textOffsetValue, textAssertion:textLocAssertVal[1] };
            })(pos0, result0[1], result0[2]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_idAssertion() {
        var result0;
        var pos0;
        
        pos0 = pos;
        result0 = parse_value();
        if (result0 !== null) {
          result0 = (function(offset, idVal) { 
        
                return idVal; 
            })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_textLocationAssertion() {
        var result0, result1;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        result0 = parse_csv();
        result0 = result0 !== null ? result0 : "";
        if (result0 !== null) {
          result1 = parse_parameter();
          result1 = result1 !== null ? result1 : "";
          if (result1 !== null) {
            result0 = [result0, result1];
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, csvVal, paramVal) { 
        
                return { type:"textLocationAssertion", csv:csvVal, parameter:paramVal }; 
            })(pos0, result0[0], result0[1]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_parameter() {
        var result0, result1, result2, result3;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        if (input.charCodeAt(pos) === 59) {
          result0 = ";";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\";\"");
          }
        }
        if (result0 !== null) {
          result1 = parse_valueNoSpace();
          if (result1 !== null) {
            if (input.charCodeAt(pos) === 61) {
              result2 = "=";
              pos++;
            } else {
              result2 = null;
              if (reportFailures === 0) {
                matchFailed("\"=\"");
              }
            }
            if (result2 !== null) {
              result3 = parse_valueNoSpace();
              if (result3 !== null) {
                result0 = [result0, result1, result2, result3];
              } else {
                result0 = null;
                pos = pos1;
              }
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, paramLHSVal, paramRHSVal) { 
        
                return { type:"parameter", LHSValue:paramLHSVal, RHSValue:paramRHSVal }; 
            })(pos0, result0[1], result0[3]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_csv() {
        var result0, result1, result2;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        result0 = parse_value();
        result0 = result0 !== null ? result0 : "";
        if (result0 !== null) {
          if (input.charCodeAt(pos) === 44) {
            result1 = ",";
            pos++;
          } else {
            result1 = null;
            if (reportFailures === 0) {
              matchFailed("\",\"");
            }
          }
          if (result1 !== null) {
            result2 = parse_value();
            result2 = result2 !== null ? result2 : "";
            if (result2 !== null) {
              result0 = [result0, result1, result2];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, preAssertionVal, postAssertionVal) { 
        
                return { type:"csv", preAssertion:preAssertionVal, postAssertion:postAssertionVal }; 
            })(pos0, result0[0], result0[2]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_valueNoSpace() {
        var result0, result1;
        var pos0;
        
        pos0 = pos;
        result1 = parse_escapedSpecialChars();
        if (result1 === null) {
          result1 = parse_character();
        }
        if (result1 !== null) {
          result0 = [];
          while (result1 !== null) {
            result0.push(result1);
            result1 = parse_escapedSpecialChars();
            if (result1 === null) {
              result1 = parse_character();
            }
          }
        } else {
          result0 = null;
        }
        if (result0 !== null) {
          result0 = (function(offset, stringVal) { 
        
                return stringVal.join(''); 
            })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_value() {
        var result0, result1;
        var pos0;
        
        pos0 = pos;
        result1 = parse_escapedSpecialChars();
        if (result1 === null) {
          result1 = parse_character();
          if (result1 === null) {
            result1 = parse_space();
          }
        }
        if (result1 !== null) {
          result0 = [];
          while (result1 !== null) {
            result0.push(result1);
            result1 = parse_escapedSpecialChars();
            if (result1 === null) {
              result1 = parse_character();
              if (result1 === null) {
                result1 = parse_space();
              }
            }
          }
        } else {
          result0 = null;
        }
        if (result0 !== null) {
          result0 = (function(offset, stringVal) { 
        
                return stringVal.join(''); 
            })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_escapedSpecialChars() {
        var result0, result1;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        result0 = parse_circumflex();
        if (result0 !== null) {
          result1 = parse_circumflex();
          if (result1 !== null) {
            result0 = [result0, result1];
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 === null) {
          pos1 = pos;
          result0 = parse_circumflex();
          if (result0 !== null) {
            result1 = parse_squareBracket();
            if (result1 !== null) {
              result0 = [result0, result1];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
          if (result0 === null) {
            pos1 = pos;
            result0 = parse_circumflex();
            if (result0 !== null) {
              result1 = parse_parentheses();
              if (result1 !== null) {
                result0 = [result0, result1];
              } else {
                result0 = null;
                pos = pos1;
              }
            } else {
              result0 = null;
              pos = pos1;
            }
            if (result0 === null) {
              pos1 = pos;
              result0 = parse_circumflex();
              if (result0 !== null) {
                result1 = parse_comma();
                if (result1 !== null) {
                  result0 = [result0, result1];
                } else {
                  result0 = null;
                  pos = pos1;
                }
              } else {
                result0 = null;
                pos = pos1;
              }
              if (result0 === null) {
                pos1 = pos;
                result0 = parse_circumflex();
                if (result0 !== null) {
                  result1 = parse_semicolon();
                  if (result1 !== null) {
                    result0 = [result0, result1];
                  } else {
                    result0 = null;
                    pos = pos1;
                  }
                } else {
                  result0 = null;
                  pos = pos1;
                }
                if (result0 === null) {
                  pos1 = pos;
                  result0 = parse_circumflex();
                  if (result0 !== null) {
                    result1 = parse_equal();
                    if (result1 !== null) {
                      result0 = [result0, result1];
                    } else {
                      result0 = null;
                      pos = pos1;
                    }
                  } else {
                    result0 = null;
                    pos = pos1;
                  }
                }
              }
            }
          }
        }
        if (result0 !== null) {
          result0 = (function(offset, escSpecCharVal) { 
                
                return escSpecCharVal[1]; 
            })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_number() {
        var result0, result1, result2, result3;
        var pos0, pos1, pos2;
        
        pos0 = pos;
        pos1 = pos;
        pos2 = pos;
        if (/^[1-9]/.test(input.charAt(pos))) {
          result0 = input.charAt(pos);
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("[1-9]");
          }
        }
        if (result0 !== null) {
          if (/^[0-9]/.test(input.charAt(pos))) {
            result2 = input.charAt(pos);
            pos++;
          } else {
            result2 = null;
            if (reportFailures === 0) {
              matchFailed("[0-9]");
            }
          }
          if (result2 !== null) {
            result1 = [];
            while (result2 !== null) {
              result1.push(result2);
              if (/^[0-9]/.test(input.charAt(pos))) {
                result2 = input.charAt(pos);
                pos++;
              } else {
                result2 = null;
                if (reportFailures === 0) {
                  matchFailed("[0-9]");
                }
              }
            }
          } else {
            result1 = null;
          }
          if (result1 !== null) {
            result0 = [result0, result1];
          } else {
            result0 = null;
            pos = pos2;
          }
        } else {
          result0 = null;
          pos = pos2;
        }
        if (result0 !== null) {
          if (input.charCodeAt(pos) === 46) {
            result1 = ".";
            pos++;
          } else {
            result1 = null;
            if (reportFailures === 0) {
              matchFailed("\".\"");
            }
          }
          if (result1 !== null) {
            pos2 = pos;
            result2 = [];
            if (/^[0-9]/.test(input.charAt(pos))) {
              result3 = input.charAt(pos);
              pos++;
            } else {
              result3 = null;
              if (reportFailures === 0) {
                matchFailed("[0-9]");
              }
            }
            while (result3 !== null) {
              result2.push(result3);
              if (/^[0-9]/.test(input.charAt(pos))) {
                result3 = input.charAt(pos);
                pos++;
              } else {
                result3 = null;
                if (reportFailures === 0) {
                  matchFailed("[0-9]");
                }
              }
            }
            if (result2 !== null) {
              if (/^[1-9]/.test(input.charAt(pos))) {
                result3 = input.charAt(pos);
                pos++;
              } else {
                result3 = null;
                if (reportFailures === 0) {
                  matchFailed("[1-9]");
                }
              }
              if (result3 !== null) {
                result2 = [result2, result3];
              } else {
                result2 = null;
                pos = pos2;
              }
            } else {
              result2 = null;
              pos = pos2;
            }
            if (result2 !== null) {
              result0 = [result0, result1, result2];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, intPartVal, fracPartVal) { 
        
                return intPartVal.join('') + "." + fracPartVal.join(''); 
            })(pos0, result0[0], result0[2]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_integer() {
        var result0, result1, result2;
        var pos0, pos1;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 48) {
          result0 = "0";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"0\"");
          }
        }
        if (result0 === null) {
          pos1 = pos;
          if (/^[1-9]/.test(input.charAt(pos))) {
            result0 = input.charAt(pos);
            pos++;
          } else {
            result0 = null;
            if (reportFailures === 0) {
              matchFailed("[1-9]");
            }
          }
          if (result0 !== null) {
            result1 = [];
            if (/^[0-9]/.test(input.charAt(pos))) {
              result2 = input.charAt(pos);
              pos++;
            } else {
              result2 = null;
              if (reportFailures === 0) {
                matchFailed("[0-9]");
              }
            }
            while (result2 !== null) {
              result1.push(result2);
              if (/^[0-9]/.test(input.charAt(pos))) {
                result2 = input.charAt(pos);
                pos++;
              } else {
                result2 = null;
                if (reportFailures === 0) {
                  matchFailed("[0-9]");
                }
              }
            }
            if (result1 !== null) {
              result0 = [result0, result1];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        }
        if (result0 !== null) {
          result0 = (function(offset, integerVal) { 
        
                if (integerVal === "0") { 
                  return "0";
                } 
                else { 
                  return integerVal[0].concat(integerVal[1].join(''));
                }
            })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_space() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 32) {
          result0 = " ";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\" \"");
          }
        }
        if (result0 !== null) {
          result0 = (function(offset) { return " "; })(pos0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_circumflex() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 94) {
          result0 = "^";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"^\"");
          }
        }
        if (result0 !== null) {
          result0 = (function(offset) { return "^"; })(pos0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_doubleQuote() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 34) {
          result0 = "\"";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"\\\"\"");
          }
        }
        if (result0 !== null) {
          result0 = (function(offset) { return '"'; })(pos0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_squareBracket() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 91) {
          result0 = "[";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"[\"");
          }
        }
        if (result0 === null) {
          if (input.charCodeAt(pos) === 93) {
            result0 = "]";
            pos++;
          } else {
            result0 = null;
            if (reportFailures === 0) {
              matchFailed("\"]\"");
            }
          }
        }
        if (result0 !== null) {
          result0 = (function(offset, bracketVal) { return bracketVal; })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_parentheses() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 40) {
          result0 = "(";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"(\"");
          }
        }
        if (result0 === null) {
          if (input.charCodeAt(pos) === 41) {
            result0 = ")";
            pos++;
          } else {
            result0 = null;
            if (reportFailures === 0) {
              matchFailed("\")\"");
            }
          }
        }
        if (result0 !== null) {
          result0 = (function(offset, paraVal) { return paraVal; })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_comma() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 44) {
          result0 = ",";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\",\"");
          }
        }
        if (result0 !== null) {
          result0 = (function(offset) { return ","; })(pos0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_semicolon() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 59) {
          result0 = ";";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\";\"");
          }
        }
        if (result0 !== null) {
          result0 = (function(offset) { return ";"; })(pos0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_equal() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 61) {
          result0 = "=";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"=\"");
          }
        }
        if (result0 !== null) {
          result0 = (function(offset) { return "="; })(pos0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_character() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (/^[a-z]/.test(input.charAt(pos))) {
          result0 = input.charAt(pos);
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("[a-z]");
          }
        }
        if (result0 === null) {
          if (/^[A-Z]/.test(input.charAt(pos))) {
            result0 = input.charAt(pos);
            pos++;
          } else {
            result0 = null;
            if (reportFailures === 0) {
              matchFailed("[A-Z]");
            }
          }
          if (result0 === null) {
            if (/^[0-9]/.test(input.charAt(pos))) {
              result0 = input.charAt(pos);
              pos++;
            } else {
              result0 = null;
              if (reportFailures === 0) {
                matchFailed("[0-9]");
              }
            }
            if (result0 === null) {
              if (input.charCodeAt(pos) === 45) {
                result0 = "-";
                pos++;
              } else {
                result0 = null;
                if (reportFailures === 0) {
                  matchFailed("\"-\"");
                }
              }
              if (result0 === null) {
                if (input.charCodeAt(pos) === 95) {
                  result0 = "_";
                  pos++;
                } else {
                  result0 = null;
                  if (reportFailures === 0) {
                    matchFailed("\"_\"");
                  }
                }
              }
            }
          }
        }
        if (result0 !== null) {
          result0 = (function(offset, charVal) { return charVal; })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      
      function cleanupExpected(expected) {
        expected.sort();
        
        var lastExpected = null;
        var cleanExpected = [];
        for (var i = 0; i < expected.length; i++) {
          if (expected[i] !== lastExpected) {
            cleanExpected.push(expected[i]);
            lastExpected = expected[i];
          }
        }
        return cleanExpected;
      }
      
      function computeErrorPosition() {
        /*
         * The first idea was to use |String.split| to break the input up to the
         * error position along newlines and derive the line and column from
         * there. However IE's |split| implementation is so broken that it was
         * enough to prevent it.
         */
        
        var line = 1;
        var column = 1;
        var seenCR = false;
        
        for (var i = 0; i < Math.max(pos, rightmostFailuresPos); i++) {
          var ch = input.charAt(i);
          if (ch === "\n") {
            if (!seenCR) { line++; }
            column = 1;
            seenCR = false;
          } else if (ch === "\r" || ch === "\u2028" || ch === "\u2029") {
            line++;
            column = 1;
            seenCR = true;
          } else {
            column++;
            seenCR = false;
          }
        }
        
        return { line: line, column: column };
      }
      
      
      var result = parseFunctions[startRule]();
      
      /*
       * The parser is now in one of the following three states:
       *
       * 1. The parser successfully parsed the whole input.
       *
       *    - |result !== null|
       *    - |pos === input.length|
       *    - |rightmostFailuresExpected| may or may not contain something
       *
       * 2. The parser successfully parsed only a part of the input.
       *
       *    - |result !== null|
       *    - |pos < input.length|
       *    - |rightmostFailuresExpected| may or may not contain something
       *
       * 3. The parser did not successfully parse any part of the input.
       *
       *   - |result === null|
       *   - |pos === 0|
       *   - |rightmostFailuresExpected| contains at least one failure
       *
       * All code following this comment (including called functions) must
       * handle these states.
       */
      if (result === null || pos !== input.length) {
        var offset = Math.max(pos, rightmostFailuresPos);
        var found = offset < input.length ? input.charAt(offset) : null;
        var errorPosition = computeErrorPosition();
        
        throw new this.SyntaxError(
          cleanupExpected(rightmostFailuresExpected),
          found,
          offset,
          errorPosition.line,
          errorPosition.column
        );
      }
      
      return result;
    },
    
    /* Returns the parser source code. */
    toSource: function() { return this._source; }
  };
  
  /* Thrown when a parser encounters a syntax error. */
  
  result.SyntaxError = function(expected, found, offset, line, column) {
    function buildMessage(expected, found) {
      var expectedHumanized, foundHumanized;
      
      switch (expected.length) {
        case 0:
          expectedHumanized = "end of input";
          break;
        case 1:
          expectedHumanized = expected[0];
          break;
        default:
          expectedHumanized = expected.slice(0, expected.length - 1).join(", ")
            + " or "
            + expected[expected.length - 1];
      }
      
      foundHumanized = found ? quote(found) : "end of input";
      
      return "Expected " + expectedHumanized + " but " + foundHumanized + " found.";
    }
    
    this.name = "SyntaxError";
    this.expected = expected;
    this.found = found;
    this.message = buildMessage(expected, found);
    this.offset = offset;
    this.line = line;
    this.column = column;
  };
  
  result.SyntaxError.prototype = Error.prototype;
  
  return result;
})();
 

    // Description: This model contains the implementation for "instructions" included in the EPUB CFI domain specific language (DSL). 
//   Lexing and parsing a CFI produces a set of executable instructions for processing a CFI (represented in the AST). 
//   This object contains a set of functions that implement each of the executable instructions in the AST. 

EPUBcfi.CFIInstructions = {

	// ------------------------------------------------------------------------------------ //
	//  "PUBLIC" METHODS (THE API)                                                          //
	// ------------------------------------------------------------------------------------ //

	// Description: Follows a step
	// Rationale: The use of children() is important here, as this jQuery method returns a tree of xml nodes, EXCLUDING
	//   CDATA and text nodes. When we index into the set of child elements, we are assuming that text nodes have been 
	//   excluded.
	// REFACTORING CANDIDATE: This should be called "followIndexStep"
	getNextNode : function (CFIStepValue, $currNode, classBlacklist, elementBlacklist, idBlacklist) {

		// Find the jquery index for the current node
		var $targetNode;
		if (CFIStepValue % 2 == 0) {

			$targetNode = this.elementNodeStep(CFIStepValue, $currNode, classBlacklist, elementBlacklist, idBlacklist);
		}
		else {

			$targetNode = this.inferTargetTextNode(CFIStepValue, $currNode, classBlacklist, elementBlacklist, idBlacklist);
		}

		return $targetNode;
	},

	// Description: This instruction executes an indirection step, where a resource is retrieved using a 
	//   link contained on a attribute of the target element. The attribute that contains the link differs
	//   depending on the target. 
	// Note: Iframe indirection will (should) fail if the iframe is not from the same domain as its containing script due to 
	//   the cross origin security policy
	followIndirectionStep : function (CFIStepValue, $currNode, $packageDocument, classBlacklist, elementBlacklist, idBlacklist) {

		var that = this;
		var $contentDocument; 
		var $blacklistExcluded;
		var $startElement;
		var $targetNode;

		// TODO: This check must be expanded to all the different types of indirection step
		// Only expects iframes, at the moment
		if ($currNode === undefined || !$currNode.is("iframe")) {

			throw EPUBcfi.NodeTypeError($currNode, "expected an iframe element");
		}

		// Check node type; only iframe indirection is handled, at the moment
		if ($currNode.is("iframe")) {

			// Get content
			$contentDocument = $currNode.contents();

			// Go to the first XHTML element, which will be the first child of the top-level document object
			$blacklistExcluded = this.applyBlacklist($contentDocument.children(), classBlacklist, elementBlacklist, idBlacklist);
			$startElement = $($blacklistExcluded[0]);

			// Follow an index step
			$targetNode = this.getNextNode(CFIStepValue, $startElement, classBlacklist, elementBlacklist, idBlacklist);

			// Return that shit!
			return $targetNode; 
		}

		// TODO: Other types of indirection
		// TODO: $targetNode.is("embed")) : src
		// TODO: ($targetNode.is("object")) : data
		// TODO: ($targetNode.is("image") || $targetNode.is("xlink:href")) : xlink:href
	},

	// Description: Injects an element at the specified text node
	// Arguments: a cfi text termination string, a jquery object to the current node
	textTermination : function ($currNode, textOffset, elementToInject) {

		// Get the first node, this should be a text node
		if ($currNode === undefined) {

			throw EPUBcfi.NodeTypeError($currNode, "expected a terminating node, or node list");
		} 
		else if ($currNode.length === 0) {

			throw EPUBcfi.TerminusError("Text", "Text offset:" + textOffset, "no nodes found for termination condition");
		}

		$currNode = this.injectCFIMarkerIntoText($currNode, textOffset, elementToInject);
		return $currNode;
	},

	// Description: Checks that the id assertion for the node target matches that on 
	//   the found node. 
	targetIdMatchesIdAssertion : function ($foundNode, idAssertion) {

		if ($foundNode.attr("id") === idAssertion) {

			return true;
		}
		else {

			return false;
		}
	},

	// ------------------------------------------------------------------------------------ //
	//  "PRIVATE" HELPERS                                                                   //
	// ------------------------------------------------------------------------------------ //

	// Description: Step reference for xml element node. Expected that CFIStepValue is an even integer
	elementNodeStep : function (CFIStepValue, $currNode, classBlacklist, elementBlacklist, idBlacklist) {

		var $targetNode;
		var $blacklistExcluded;
		var numElements;
		var jqueryTargetNodeIndex = (CFIStepValue / 2) - 1;

		$blacklistExcluded = this.applyBlacklist($currNode.children(), classBlacklist, elementBlacklist, idBlacklist);
		numElements = $blacklistExcluded.length;

		if (this.indexOutOfRange(jqueryTargetNodeIndex, numElements)) {

			throw EPUBcfi.OutOfRangeError(jqueryTargetNodeIndex, numElements - 1, "");
		}

	    $targetNode = $($blacklistExcluded[jqueryTargetNodeIndex]);
		return $targetNode;
	},

	retrieveItemRefHref : function ($itemRefElement, $packageDocument) {

		return $("#" + $itemRefElement.attr("idref"), $packageDocument).attr("href");
	},

	indexOutOfRange : function (targetIndex, numChildElements) {

		return (targetIndex > numChildElements - 1) ? true : false;
	},

	// Rationale: In order to inject an element into a specific position, access to the parent object 
	//   is required. This is obtained with the jquery parent() method. An alternative would be to 
	//   pass in the parent with a filtered list containing only children that are part of the target text node.
	injectCFIMarkerIntoText : function ($textNodeList, textOffset, elementToInject) {

		var nodeNum;
		var currNodeLength;
		var currTextPosition = 0;
		var nodeOffset;
		var originalText;
		var $injectedNode;
		var $newTextNode;
		// The iteration counter may be incorrect here (should be $textNodeList.length - 1 ??)
		for (nodeNum = 0; nodeNum <= $textNodeList.length; nodeNum++) {

			if ($textNodeList[nodeNum].nodeType === 3) {

				currNodeMaxIndex = ($textNodeList[nodeNum].nodeValue.length - 1) + currTextPosition;
				nodeOffset = textOffset - currTextPosition;

				if (currNodeMaxIndex >= textOffset) {

					// This node is going to be split and the components re-inserted
					originalText = $textNodeList[nodeNum].nodeValue;	

					// Before part
				 	$textNodeList[nodeNum].nodeValue = originalText.slice(0, nodeOffset);

					// Injected element
					$injectedNode = $(elementToInject).insertAfter($textNodeList.eq(nodeNum));

					// After part
					$newTextNode = $(document.createTextNode(originalText.slice(nodeOffset, originalText.length)));
					$($newTextNode).insertAfter($injectedNode);

					return $textNodeList.parent();
				}
				else {

					currTextPosition = currTextPosition + currNodeMaxIndex;
				}
			}
		}

		throw EPUBcfi.TerminusError("Text", "Text offset:" + textOffset, "The offset exceeded the length of the text");
	},

	// Description: This method finds a target text node and then injects an element into the appropriate node
	// Arguments: A step value that is an odd integer. A current node with a set of child elements.
	// Rationale: The possibility that cfi marker elements have been injected into a text node at some point previous to 
	//   this method being called (and thus splitting the original text node into two separate text nodes) necessitates that
	//   the set of nodes that compromised the original target text node are inferred and returned.
	// Notes: Passed a current node. This node should have a set of elements under it. This will include at least one text node, 
	//   element nodes (maybe), or possibly a mix. 
	// REFACTORING CANDIDATE: This method is pretty long. Worth investigating to see if it can be refactored into something clearer.
	inferTargetTextNode : function (CFIStepValue, $currNode, classBlacklist, elementBlacklist, idBlacklist) {
		
		var $elementsWithoutMarkers;
		var currTextNodePosition;
		var logicalTargetPosition;
		var nodeNum;
		var $targetTextNodeList;

		// Remove any cfi marker elements from the set of elements. 
		// Rationale: A filtering function is used, as simply using a class selector with jquery appears to 
		//   result in behaviour where text nodes are also filtered out, along with the class element being filtered.
		$elementsWithoutMarkers = this.applyBlacklist($currNode.contents(), classBlacklist, elementBlacklist, idBlacklist);

		// Convert CFIStepValue to logical index; assumes odd integer for the step value
		logicalTargetPosition = (parseInt(CFIStepValue) + 1) / 2;

		// Set text node position counter
		currTextNodePosition = 1;
		$targetTextNodeList = $elementsWithoutMarkers.filter(
			function () {

				if (currTextNodePosition === logicalTargetPosition) {

					// If it's a text node
					if (this.nodeType === 3) {
						return true; 
					}
					// Any other type of node, move onto the next text node
					else {
						currTextNodePosition++; 
						return false;
					}
				}
				// In this case, don't return any elements
				else {

					// If its the last child and it's not a text node, there are no text nodes after it
					// and the currTextNodePosition shouldn't be incremented
					if (this.nodeType !== 3 && this !== $elementsWithoutMarkers.lastChild) {
						currTextNodePosition++;
					}

					return false;
				}
			}
		);

		// The filtering above should have counted the number of "logical" text nodes; this can be used to 
		// detect out of range errors
		if ($targetTextNodeList.length === 0) {

			throw EPUBcfi.OutOfRangeError(logicalTargetPosition, currTextNodePosition - 1, "Index out of range");
		}

		// return the text node list
		return $targetTextNodeList;
	},

	applyBlacklist : function ($elements, classBlacklist, elementBlacklist, idBlacklist) {

        var $filteredElements;

        $filteredElements = $elements.filter(
            function () {

                var $currElement = $(this);
                var includeInList = true;

                if (classBlacklist) {

                	// Filter each element with the class type
                	$.each(classBlacklist, function (index, value) {

	                    if ($currElement.hasClass(value)) {
	                    	includeInList = false;

	                    	// Break this loop
	                        return false;
	                    }
                	});
                }

                if (elementBlacklist) {
                	
	                // For each type of element
	                $.each(elementBlacklist, function (index, value) {

	                    if ($currElement.is(value)) {
	                    	includeInList = false;

	                    	// Break this loop
	                        return false;
	                    }
	                });
				}

				if (idBlacklist) {
                	
	                // For each type of element
	                $.each(idBlacklist, function (index, value) {

	                    if ($currElement.attr("id") === value) {
	                    	includeInList = false;

	                    	// Break this loop
	                        return false;
	                    }
	                });
				}

                return includeInList;
            }
        );

        return $filteredElements;
    }
};




    // Description: This is an interpreter that inteprets an Abstract Syntax Tree (AST) for a CFI. The result of executing the interpreter
//   is to inject an element, or set of elements, into an EPUB content document (which is just an XHTML document). These element(s) will
//   represent the position or area in the EPUB referenced by a CFI.
// Rationale: The AST is a clean and readable expression of the step-terminus structure of a CFI. Although building an interpreter adds to the
//   CFI infrastructure, it provides a number of benefits. First, it emphasizes a clear separation of concerns between lexing/parsing a
//   CFI, which involves some complexity related to escaped and special characters, and the execution of the underlying set of steps 
//   represented by the CFI. Second, it will be easier to extend the interpreter to account for new/altered CFI steps (say for references
//   to vector objects or multiple CFIs) than if lexing, parsing and interpretation were all handled in a single step. Finally, Readium's objective is 
//   to demonstrate implementation of the EPUB 3.0 spec. An implementation with a strong separation of concerns that conforms to 
//   well-understood patterns for DSL processing should be easier to communicate, analyze and understand. 
// REFACTORING CANDIDATE: node type errors shouldn't really be possible if the CFI syntax is correct and the parser is error free. 
//   Might want to make the script die in those instances, once the grammar and interpreter are more stable. 
// REFACTORING CANDIDATE: The use of the 'nodeType' property is confusing as this is a DOM node property and the two are unrelated. 
//   Whoops. There shouldn't be any interference, however, I think this should be changed. 

EPUBcfi.Interpreter = {

    // ------------------------------------------------------------------------------------ //
    //  "PUBLIC" METHODS (THE API)                                                          //
    // ------------------------------------------------------------------------------------ //

    // Description: Find the content document referenced by the spine item. This should be the spine item 
    //   referenced by the first indirection step in the CFI.
    // Rationale: This method is a part of the API so that the reading system can "interact" the content document 
    //   pointed to by a CFI. If this is not a separate step, the processing of the CFI must be tightly coupled with 
    //   the reading system, as it stands now. 
    getContentDocHref : function (CFI, packageDocument, classBlacklist, elementBlacklist, idBlacklist) {

        // Decode for URI/IRI escape characters
        var $packageDocument = $(packageDocument);
        var decodedCFI = decodeURI(CFI);
        var CFIAST = EPUBcfi.Parser.parse(decodedCFI);

        // Check node type; throw error if wrong type
        if (CFIAST === undefined || CFIAST.type !== "CFIAST") { 

            throw EPUBcfi.NodeTypeError(CFIAST, "expected CFI AST root node");
        }

        var $packageElement = $($("package", $packageDocument)[0]);

        // Interpet the path node (the package document step)
        var $currElement = this.interpretIndexStepNode(CFIAST.cfiString.path, $packageElement, classBlacklist, elementBlacklist, idBlacklist);

        // Interpret the local_path node, which is a set of steps and and a terminus condition
        var stepNum = 0;
        var nextStepNode;
        for (stepNum = 0 ; stepNum <= CFIAST.cfiString.localPath.steps.length - 1 ; stepNum++) {
        
            nextStepNode = CFIAST.cfiString.localPath.steps[stepNum];
            if (nextStepNode.type === "indexStep") {

                $currElement = this.interpretIndexStepNode(nextStepNode, $currElement, classBlacklist, elementBlacklist, idBlacklist);
            }
            else if (nextStepNode.type === "indirectionStep") {

                $currElement = this.interpretIndirectionStepNode(nextStepNode, $currElement, $packageDocument, classBlacklist, elementBlacklist, idBlacklist);
            }

            // Found the content document href referenced by the spine item 
            if ($currElement.is("itemref")) {

                return EPUBcfi.CFIInstructions.retrieveItemRefHref($currElement, $packageDocument);
            }
        }

        // TODO: If you get to here, an itemref element was never found - a runtime error. The cfi is misspecified or 
        //   the package document is messed up.
    },

    // Description: Inject an arbirtary html element into a position in a content document referenced by a CFI
    injectElement : function (CFI, contentDocument, elementToInject, classBlacklist, elementBlacklist, idBlacklist) {

        var decodedCFI = decodeURI(CFI);
        var CFIAST = EPUBcfi.Parser.parse(decodedCFI);

        // Find the first indirection step in the local path; follow it like a regular step, as the content document it 
        //   references is already loaded and has been passed to this method
        var stepNum = 0;
        var nextStepNode;
        for (stepNum; stepNum <= CFIAST.cfiString.localPath.steps.length - 1 ; stepNum++) {
        
            nextStepNode = CFIAST.cfiString.localPath.steps[stepNum];
            if (nextStepNode.type === "indirectionStep") {

                // This is now assuming that indirection steps and index steps conform to an interface: an object with stepLength, idAssertion
                nextStepNode.type = "indexStep";
                // Getting the html element and creating a jquery object for it; excluding cfiMarkers
                $currElement = this.interpretIndexStepNode(nextStepNode, $("html", contentDocument), classBlacklist, elementBlacklist, idBlacklist);
                stepNum++ // Increment the step num as this will be passed as the starting point for continuing interpretation
                break;
            }
        }

        // Interpret the rest of the steps
        $currElement = this.interpretLocalPath(CFIAST.cfiString, stepNum, $currElement, classBlacklist, elementBlacklist, idBlacklist);

        // TODO: detect what kind of terminus; for now, text node termini are the only kind implemented
        $currElement = this.interpretTextTerminusNode(CFIAST.cfiString.localPath.termStep, $currElement, elementToInject);

        // Return the element that was injected into
        return $currElement;
    },

    // ------------------------------------------------------------------------------------ //
    //  "PRIVATE" HELPERS                                                                   //
    // ------------------------------------------------------------------------------------ //

    interpretLocalPath : function (cfiStringNode, startStepNum, $currElement, classBlacklist, elementBlacklist, idBlacklist) {

        var stepNum = startStepNum;
        var nextStepNode;
        for (stepNum; stepNum <= cfiStringNode.localPath.steps.length - 1 ; stepNum++) {
        
            nextStepNode = cfiStringNode.localPath.steps[stepNum];
            if (nextStepNode.type === "indexStep") {

                $currElement = this.interpretIndexStepNode(nextStepNode, $currElement, classBlacklist, elementBlacklist, idBlacklist);
            }
            else if (nextStepNode.type === "indirectionStep") {

                $currElement = this.interpretIndirectionStepNode(nextStepNode, $currElement, $packageDocument, classBlacklist, elementBlacklist, idBlacklist);
            }
        }

        return $currElement;
    },

    interpretIndexStepNode : function (indexStepNode, $currElement, classBlacklist, elementBlacklist, idBlacklist) {

        // Check node type; throw error if wrong type
        if (indexStepNode === undefined || indexStepNode.type !== "indexStep") {

            throw EPUBcfi.NodeTypeError(indexStepNode, "expected index step node");
        }

        // Index step
        var $stepTarget = EPUBcfi.CFIInstructions.getNextNode(indexStepNode.stepLength, $currElement, classBlacklist, elementBlacklist, idBlacklist);

        // Check the id assertion, if it exists
        if (indexStepNode.idAssertion) {

            if (!EPUBcfi.CFIInstructions.targetIdMatchesIdAssertion($stepTarget, indexStepNode.idAssertion)) {

                throw EPUBcfi.CFIAssertionError(indexStepNode.idAssertion, $stepTarget.attr('id'), "Id assertion failed");
            }
        }

        return $stepTarget;
    },

    interpretIndirectionStepNode : function (indirectionStepNode, $currElement, $packageDocument, classBlacklist, elementBlacklist, idBlacklist) {

        // Check node type; throw error if wrong type
        if (indirectionStepNode === undefined || indirectionStepNode.type !== "indirectionStep") {

            throw EPUBcfi.NodeTypeError(indirectionStepNode, "expected indirection step node");
        }

        // Indirection step
        var $stepTarget = EPUBcfi.CFIInstructions.followIndirectionStep(
            indirectionStepNode.stepLength, 
            $currElement,
            $packageDocument, 
            classBlacklist, 
            elementBlacklist);

        // Check the id assertion, if it exists
        if (indirectionStepNode.idAssertion) {

            if (!EPUBcfi.CFIInstructions.targetIdMatchesIdAssertion($stepTarget, indirectionStepNode.idAssertion)) {

                throw EPUBcfi.CFIAssertionError(indirectionStepNode.idAssertion, $stepTarget.attr('id'), "Id assertion failed");
            }
        }

        return $stepTarget;
    },

    interpretTextTerminusNode : function (terminusNode, $currElement, elementToInject) {

        if (terminusNode === undefined || terminusNode.type !== "textTerminus") {

            throw EPUBcfi.NodeTypeError(terminusNode, "expected text terminus node");
        }

        var $elementInjectedInto = EPUBcfi.CFIInstructions.textTermination(
            $currElement, 
            terminusNode.offsetValue, 
            elementToInject);

        return $elementInjectedInto;
    }
};

    // Description: This is a set of runtime errors that the CFI interpreter can throw. 
// Rationale: These error types extend the basic javascript error object so error things like the stack trace are 
//   included with the runtime errors. 

// REFACTORING CANDIDATE: This type of error may not be required in the long run. The parser should catch any syntax errors, 
//   provided it is error-free, and as such, the AST should never really have any node type errors, which are essentially errors
//   in the structure of the AST. This error should probably be refactored out when the grammar and interpreter are more stable.
EPUBcfi.NodeTypeError = function (node, message) {

    function NodeTypeError () {

        this.node = node;
    }

    NodeTypeError.prototype = new Error(message);
    NodeTypeError.constructor = NodeTypeError;

    return new NodeTypeError();
};

// REFACTORING CANDIDATE: Might make sense to include some more specifics about the out-of-rangeyness.
EPUBcfi.OutOfRangeError = function (targetIndex, maxIndex, message) {

    function OutOfRangeError () {

        this.targetIndex = targetIndex;
        this.maxIndex = maxIndex;
    }

    OutOfRangeError.prototype = new Error(message);
    OutOfRangeError.constructor = OutOfRangeError()

    return new OutOfRangeError();
};

// REFACTORING CANDIDATE: This is a bit too general to be useful. When I have a better understanding of the type of errors
//   that can occur with the various terminus conditions, it'll make more sense to revisit this. 
EPUBcfi.TerminusError = function (terminusType, terminusCondition, message) {

    function TerminusError () {

        this.terminusType = terminusType;
        this.terminusCondition = terminusCondition;
    }

    TerminusError.prototype = new Error(message);
    TerminusError.constructor = TerminusError();

    return new TerminusError();
};

EPUBcfi.CFIAssertionError = function (expectedAssertion, targetElementAssertion, message) {

    function CFIAssertionError () {

        this.expectedAssertion = expectedAssertion;
        this.targetElementAssertion = targetElementAssertion;
    }

    CFIAssertionError.prototype = new Error(message);
    CFIAssertionError.constructor = CFIAssertionError();

    return new CFIAssertionError();
};


    EPUBcfi.Generator = {

    // Description: Generates a character offset CFI 
    // Arguments: The text node that contains the offset referenced by the cfi, the offset value, the name of the 
    //   content document that contains the text node, the package document for this EPUB.
    generateCharacterOffsetCFI : function (startTextNode, characterOffset, contentDocumentName, packageDocument, classBlacklist, elementBlacklist, idBlacklist) {

        // ------------------------------------------------------------------------------------ //
        //  "PUBLIC" METHODS (THE API)                                                          //
        // ------------------------------------------------------------------------------------ //

        var contentDocCFI;
        var $itemRefStartNode;
        var packageDocCFI;

        // Check that the text node to start from IS a text node
        if (!startTextNode) {
            throw new EPUBcfi.NodeTypeError(startTextNode, "Cannot generate a character offset from a starting point that is not a text node");
        } else if (startTextNode.nodeType != 3) {
            throw new EPUBcfi.NodeTypeError(startTextNode, "Cannot generate a character offset from a starting point that is not a text node");
        }

        // Check that the character offset is within a valid range for the text node supplied
        if (characterOffset < 0) {
            throw new EPUBcfi.OutOfRangeError(characterOffset, 0, "Character offset cannot be less than 0");
        }
        else if (characterOffset > startTextNode.nodeValue.length) {
            throw new EPUBcfi.OutOfRangeError(characterOffset, startTextNode.nodeValue.length - 1, "character offset cannot be greater than the length of the text node");
        }

        // Check that the idref for the content document has been provided
        if (!contentDocumentName) {
            throw new Error("The idref for the content document, as found in the spine, must be supplied");
        }

        // Check that the package document is non-empty and contains an itemref element for the supplied idref
        if (!packageDocument) {
            throw new Error("A package document must be supplied to generate a CFI");
        }
        else if ($($("itemref[idref='" + contentDocumentName + "']", packageDocument)[0]).length === 0) {
            throw new Error("The idref of the content document could not be found in the spine");
        }

        // Call the recursive method to create all the steps up to the head element of the content document (the "html" element)
        contentDocCFI = this.createCFIElementSteps($(startTextNode), characterOffset, "html", classBlacklist, elementBlacklist, idBlacklist);

        // Get the start node (itemref element) that references the content document
        $itemRefStartNode = $("itemref[idref='" + contentDocumentName + "']", $(packageDocument));

        // Create the steps up to the top element of the package document (the "package" element)
        packageDocCFI = this.createCFIElementSteps($itemRefStartNode, characterOffset, "package", classBlacklist, elementBlacklist, idBlacklist);

        // Return the CFI wrapped with "epubcfi()"
        return "epubcfi(" + packageDocCFI + contentDocCFI + ")";
    },

    // ------------------------------------------------------------------------------------ //
    //  "PRIVATE" HELPERS                                                                   //
    // ------------------------------------------------------------------------------------ //

    // Description: Creates a CFI terminating step, to a text node, with a character offset
    // Arguments:
    // Rationale:
    // Notes:
    // REFACTORING CANDIDATE: Some of the parts of this method could be refactored into their own methods
    createCFITextNodeStep : function ($startTextNode, characterOffset, classBlacklist, elementBlacklist, idBlacklist) {

        var $parentNode;
        var $contentsExcludingMarkers;
        var CFIIndex;
        var indexOfTextNode;
        var preAssertion;
        var preAssertionStartIndex;
        var textLength;
        var postAssertion;
        var postAssertionEndIndex;

        // Find text node position in the set of child elements, ignoring any blacklisted elements 
        $parentNode = $startTextNode.parent();
        $contentsExcludingMarkers = EPUBcfi.CFIInstructions.applyBlacklist($parentNode.contents(), classBlacklist, elementBlacklist, idBlacklist);

        // Find the text node index in the parent list, inferring nodes that were originally a single text node
        var prevNodeWasTextNode;
        var indexOfFirstInSequence;
        $.each($contentsExcludingMarkers, 
            function (index) {

                // If this is a text node, check if it matches and return the current index
                if (this.nodeType === 3) {

                    if (this === $startTextNode[0]) {

                        // Set index as the first in the adjacent sequence of text nodes, or as the index of the current node if this 
                        //   node is a standard one sandwiched between two element nodes. 
                        if (prevNodeWasTextNode) {
                            indexOfTextNode = indexOfFirstInSequence;
                        }
                        else {
                            indexOfTextNode = index;
                        }
                        
                        // Break out of .each loop
                        return false; 
                    }

                    // Save this index as the first in sequence of adjacent text nodes, if it is not already set by this point
                    prevNodeWasTextNode = true;
                    if (!indexOfFirstInSequence) {
                        indexOfFirstInSequence = index;
                    }
                }
                // This node is not a text node
                else {
                    prevNodeWasTextNode = false;
                    indexOfFirstInSequence = undefined;
                }
            }
        );

        // Convert the text node index to a CFI odd-integer representation
        CFIIndex = (indexOfTextNode * 2) + 1;

        // TODO: text assertions are not in the grammar yet, I think, or they're just causing problems. This has
        //   been temporarily removed. 

        // Add pre- and post- text assertions
        // preAssertionStartIndex = (characterOffset - 3 >= 0) ? characterOffset - 3 : 0;
        // preAssertion = $startTextNode[0].nodeValue.substring(preAssertionStartIndex, characterOffset);

        // textLength = $startTextNode[0].nodeValue.length;
        // postAssertionEndIndex = (characterOffset + 3 <= textLength) ? characterOffset + 3 : textLength;
        // postAssertion = $startTextNode[0].nodeValue.substring(characterOffset, postAssertionEndIndex);

        // Gotta infer the correct character offset, as well

        // Return the constructed CFI text node step
        return "/" + CFIIndex + ":" + characterOffset;
         // + "[" + preAssertion + "," + postAssertion + "]";
    },

    // Description: A set of adjacent text nodes can be inferred to have been a single text node in the original document. As such, 
    //   if the character offset is specified for one of the adjacent text nodes, the true offset for the original node must be
    //   inferred.
    findOriginalTextNodeCharOffset : function ($startTextNode, specifiedCharacterOffset, classBlacklist, elementBlacklist, idBlacklist) {

        var $parentNode;
        var $contentsExcludingMarkers;
        var textLength;
        
        // Find text node position in the set of child elements, ignoring any cfi markers 
        $parentNode = $startTextNode.parent();
        $contentsExcludingMarkers = EPUBcfi.CFIInstructions.applyBlacklist($parentNode.contents(), classBlacklist, elementBlacklist, idBlacklist);

        // Find the text node number in the list, inferring nodes that were originally a single text node
        var prevNodeWasTextNode;
        var originalCharOffset = -1; // So the character offset is a 0-based index; we'll be adding lengths of text nodes to this number
        $.each($contentsExcludingMarkers, 
            function (index) {

                // If this is a text node, check if it matches and return the current index
                if (this.nodeType === 3) {

                    if (this === $startTextNode[0]) {

                        if (prevNodeWasTextNode) {
                            originalCharOffset = originalCharOffset + specifiedCharacterOffset;
                        }
                        else {
                            originalCharOffset = specifiedCharacterOffset;
                        }

                        return false; // Break out of .each loop
                    }
                    else {

                        originalCharOffset = originalCharOffset + this.length;
                    }

                    // save this index as the first in sequence of adjacent text nodes, if not set
                    prevNodeWasTextNode = true;
                }
                // This node is not a text node
                else {
                    prevNodeWasTextNode = false;
                }
            }
        );

        return originalCharOffset;
    },

    // REFACTORING CANDIDATE: Consider putting the handling of the starting text node into the body of the 
    //   generateCharacterOffsetCfi() method; this way the characterOffset argument could be removed, which 
    //   would clarify the abstraction
    createCFIElementSteps : function ($currNode, characterOffset, topLevelElement, classBlacklist, elementBlacklist, idBlacklist) {

        var textNodeStep;
        var $blacklistExcluded;
        var $parentNode;
        var currNodePosition;
        var CFIPosition;
        var idAssertion;
        var elementStep; 

        if ($currNode[0].nodeType === 3) {

            textNodeStep = this.createCFITextNodeStep($currNode, characterOffset, classBlacklist, elementBlacklist, idBlacklist);
            return this.createCFIElementSteps($currNode.parent(), characterOffset, topLevelElement, classBlacklist, elementBlacklist, idBlacklist) + textNodeStep; 
        }

        // Find position of current node in parent list
        $blacklistExcluded = EPUBcfi.CFIInstructions.applyBlacklist($currNode.parent().children(), classBlacklist, elementBlacklist, idBlacklist);
        $.each($blacklistExcluded, 
            function (index, value) {

                if (this === $currNode[0]) {

                    currNodePosition = index;

                    // Break loop
                    return false;
                }
        });

        // Convert position to the CFI even-integer representation
        CFIPosition = (currNodePosition + 1) * 2;

        // Create CFI step with id assertion, if the element has an id
        if ($currNode.attr("id")) {
            elementStep = "/" + CFIPosition + "[" + $currNode.attr("id") + "]";
        }
        else {
            elementStep = "/" + CFIPosition;
        }

        // If a parent is an html element return the (last) step for this content document, otherwise, continue
        $parentNode = $currNode.parent();
        if ($parentNode.is(topLevelElement)) {
            
            // If the top level node is a type from which an indirection step, add an indirection step character (!)
            // REFACTORING CANDIDATE: It is possible that this should be changed to if (topLevelElement = 'package') do
            //   not return an indirection character. Every other type of top-level element may require an indirection
            //   step to navigate to, thus requiring that ! is always prepended. 
            if (topLevelElement === 'html') {
                return "!" + elementStep;
            }
            else {
                return elementStep;
            }
        }
        else {
            return this.createCFIElementSteps($parentNode, characterOffset, topLevelElement, classBlacklist, elementBlacklist, idBlacklist) + elementStep;
        }
    }
};

    if (global.EPUBcfi) {

        throw new Error('The EPUB cfi library has already been defined');
    }
    else {

        global.EPUBcfi = EPUBcfi;
    }
}) (typeof window === 'undefined' ? this : window);
