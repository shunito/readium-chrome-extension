window.Readium={Models:{},Collections:{},Views:{},Routers:{},Utils:{},Init:function(){_router=new Readium.Routers.ViewerRouter;Backbone.history.start({pushState:!0})}};$(function(){window.Readium.Init()});
Readium.FileSystemApi=function(){var f,i=83886080,j=function(a){window.webkitRequestFileSystem(window.PERSITENT,i,function(b){f=b;a&&a(h)},d)},n=function(a){window.webkitStorageInfo.requestQuota(PERSISTENT,i,function(b){i=b;a(h)},function(b){console.log("Error",b);console.log("Exectution will not continue")})},d=function(a){var b="";switch(a.code){case FileError.QUOTA_EXCEEDED_ERR:b="QUOTA_EXCEEDED_ERR";break;case FileError.NOT_FOUND_ERR:b="NOT_FOUND_ERR";break;case FileError.SECURITY_ERR:b="SECURITY_ERR";
break;case FileError.INVALID_MODIFICATION_ERR:b="INVALID_MODIFICATION_ERR";break;case FileError.INVALID_STATE_ERR:b="INVALID_STATE_ERR";break;default:b="Unknown Error"}console.log("Error: "+b)},k=function(a,b){if(b[0]=="."||b[0]=="")b=b.slice(1);a.getDirectory(b[0],{create:!0},function(a){b.length&&k(a,b.slice(1))},d)},o=function(a,b,c,g,e){c.getFile(a,{create:!1},function(d){d.remove(function(){l(a,b,c,g,e)})},function(){l(a,b,c,g,e)})},l=function(a,b,c,g,e){c.getFile(a,{create:!0,exclusive:!1},
function(a){a.createWriter(function(a){var c;a.onwriteend=function(a){g(a)};a.onerror=function(a){e(a)};if(b instanceof Blob)a.write(b);else if(b.webkitRelativePath||b.relativePath){var d=new FileReader;d.onload=function(b){c=new WebKitBlobBuilder;c.append(b.target.result);a.write(c.getBlob())};d.readAsArrayBuffer(b)}else c=new WebKitBlobBuilder,typeof b==="string"?(c.append(b),a.write(c.getBlob("text/plain"))):(d=new Uint8Array(b),c.append(d.buffer),a.write(c.getBlob()))},e)},e)},m=function(a,b,
c,d,e){if(a[0]==="."||a[0]==="")a=a.slice(1);a.length===1?o(a[0],b,c,d,e):c.getDirectory(a[0],{create:!0},function(c){a=a.slice(1);m(a,b,c,d,e)},e)},h={writeFile:function(a,b,c,d){a=a.split("/");m(a,b,f.root,c,d)},getFileSystem:function(){return f},readEntry:function(a,b,c){a.file(function(d){var e=new FileReader;e.onloadend=function(){this.result?b(this.result,a):c&&c()};e.readAsText(d)},c||d)},readTextFile:function(a,b,c){var g=this;f.root.getFile(a,{},function(a){g.readEntry(a,b,c)},c||d)},rmdir:function(a){f.root.getDirectory(a,
{},function(a){a.removeRecursively(function(){console.log("Directory removed.")},d)},d)},getFsUri:function(a,b,c){f.root.getFile(a,{create:!0,exclusive:!1},function(a){b(a.toURL())},c||d)},mkdir:k,genericFsErrorHandler:d};return function(a){if(f)return a(h),h;webkitStorageInfo.queryUsageAndQuota(webkitStorageInfo.PERSITENT,function(b,c){c>0?j(a):n(function(){j(a)})})}}();
Readium.Utils.setCookie=function(d,a,b){var c=new Date;c.setDate(c.getDate()+b);a=escape(a)+(b==null?"":"; expires="+c.toUTCString());document.cookie=d+"="+a};Readium.Utils.getCookie=function(d){var a,b,c,e=document.cookie.split(";");for(a=0;a<e.length;a++)if(b=e[a].substr(0,e[a].indexOf("=")),c=e[a].substr(e[a].indexOf("=")+1),b=b.replace(/^\s+|\s+$/g,""),b==d)return unescape(c)};Readium.Utils.trimString=function(d){return d.replace(/^\s+|\s+$/g,"")};
BBFileSystemSync=function(a,b,c){if(!b.file_path)throw"Cannot sync the model to the fs without a path";switch(a){case "read":Readium.FileSystemApi(function(a){a.readTextFile(b.file_path,function(a){c.success(a)},function(a){c.error(a)})});break;case "create":throw"Not yet implemented";case "update":throw"Not yet implemented";case "delete":throw"Not yet implemented";}return null};
Readium.Models.AlternateStyleTagSelector=Backbone.Model.extend({initialize:function(){},activateAlternateStyleSet:function(b,a){var d,c=[];if(b.length===0)return a;d=$("link[rel*='stylesheet']",a);if(d.length===0)return a;d=this._storeOriginalAttributes(d);c=this._getStyleSetTitles(d);c=this._getStyleSetTitleToActivate(d,c,b);if(c===null)return a;this._activateStyleSet(d,c);return a},_activateStyleSet:function(b,a){b.each(function(){$styleSheet=$(this);$styleSheet.attr("rel","stylesheet");$styleSheet.attr("title")===
void 0?$styleSheet[0].disabled=!1:$.trim($styleSheet.attr("title"))===a?($styleSheet[0].disabled=!0,$styleSheet[0].disabled=!1):$styleSheet[0].disabled=!0});return b},_storeOriginalAttributes:function(b){var a;b.each(function(){a=$(this);a.data("orig-rel")===void 0&&a.attr("data-orig-rel",a.attr("rel"))});return b},_getStyleSetTitleToActivate:function(b,a,d){var c=[],g,e,h,f=[];for(g=0;g<a.length;g+=1)e=b.filter("link[title='"+a[g]+"']"),e=this._removeMutuallyExclusiveAltTags(e),c.push({numAltTagMatches:this._getNumAltStyleTagMatches(e,
d),styleSetTitle:a[g]});h=_.max(c,function(a){return a.numAltTagMatches}).numAltTagMatches;if(h===0)return null;_.each(c,function(a){a.numAltTagMatches===h&&f.push(a.styleSetTitle)});if(f!==1)for(a=0;a<f.length;a++)if(e=b.filter("link[title='"+f[a]+"']"),$.trim($(e[0]).attr("data-orig-rel"))==="stylesheet")return f[a];return f[0]},_getStyleSetTitles:function(b){var a=[];b.each(function(){var b=$(this).attr("title");_.include(a,b)||a.push(b)});return a},_getNumAltStyleTagMatches:function(b,a){var d=
0,c;for(c=0;c<a.length;c+=1)b.filter("link[class*='"+a[c]+"']").length>0&&d++;return d},_removeMutuallyExclusiveAltTags:function(b){var a;b.filter("link[class*='night']").length>0&&b.filter("link[class*='day']").length>0&&b.each(function(){a=$(this);a.filter(".night").length>0&&a.toggleClass("night");a.filter(".day").length>0&&a.toggleClass("day")});b.filter("link[class*='vertical']").length>0&&b.filter("link[class*='horizontal']").length>0&&b.each(function(){a=$(this);a.filter(".vertical").length>
0&&a.toggleClass("vertical");a.filter(".horizontal").length>0&&a.toggleClass("horizontal")});return b}});
Readium.Utils.Guid=function(){return"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,function(d){var b=Math.random()*16|0;return(d=="x"?b:b&3|8).toString(16)})};
Readium.Utils.LocalStorageAdaptor=function(d){var b,f=function(){localStorage.setItem(d,JSON.stringify(b))};return function(h,a,e){var c,g=localStorage.getItem(d);b=g&&JSON.parse(g)||{};switch(h){case "read":c=a.id?b[a.id]:_.values(b);break;case "create":if(!a.id)a.id=a.attributes.id=guid();b[a.id]=a;f();c=a;break;case "update":b[a.id]=a;f();c=a;break;case "delete":delete b[a.id],f(),c=a}c?e.success&&e.success(c):e.error&&e.error("Record not found")}};
Readium.Models.AlternateStyleTagSelector=Backbone.Model.extend({initialize:function(){},activateAlternateStyleSet:function(b,a){var d,c=[];if(b.length===0)return a;d=$("link[rel*='stylesheet']",a);if(d.length===0)return a;d=this._storeOriginalAttributes(d);c=this._getStyleSetTitles(d);c=this._getStyleSetTitleToActivate(d,c,b);if(c===null)return a;this._activateStyleSet(d,c);return a},_activateStyleSet:function(b,a){b.each(function(){$styleSheet=$(this);$styleSheet.attr("rel","stylesheet");$styleSheet.attr("title")===
void 0?$styleSheet[0].disabled=!1:$.trim($styleSheet.attr("title"))===a?($styleSheet[0].disabled=!0,$styleSheet[0].disabled=!1):$styleSheet[0].disabled=!0});return b},_storeOriginalAttributes:function(b){var a;b.each(function(){a=$(this);a.data("orig-rel")===void 0&&a.attr("data-orig-rel",a.attr("rel"))});return b},_getStyleSetTitleToActivate:function(b,a,d){var c=[],g,e,h,f=[];for(g=0;g<a.length;g+=1)e=b.filter("link[title='"+a[g]+"']"),e=this._removeMutuallyExclusiveAltTags(e),c.push({numAltTagMatches:this._getNumAltStyleTagMatches(e,
d),styleSetTitle:a[g]});h=_.max(c,function(a){return a.numAltTagMatches}).numAltTagMatches;if(h===0)return null;_.each(c,function(a){a.numAltTagMatches===h&&f.push(a.styleSetTitle)});if(f!==1)for(a=0;a<f.length;a++)if(e=b.filter("link[title='"+f[a]+"']"),$.trim($(e[0]).attr("data-orig-rel"))==="stylesheet")return f[a];return f[0]},_getStyleSetTitles:function(b){var a=[];b.each(function(){var b=$(this).attr("title");_.include(a,b)||a.push(b)});return a},_getNumAltStyleTagMatches:function(b,a){var d=
0,c;for(c=0;c<a.length;c+=1)b.filter("link[class*='"+a[c]+"']").length>0&&d++;return d},_removeMutuallyExclusiveAltTags:function(b){var a;b.filter("link[class*='night']").length>0&&b.filter("link[class*='day']").length>0&&b.each(function(){a=$(this);a.filter(".night").length>0&&a.toggleClass("night");a.filter(".day").length>0&&a.toggleClass("day")});b.filter("link[class*='vertical']").length>0&&b.filter("link[class*='horizontal']").length>0&&b.each(function(){a=$(this);a.filter(".vertical").length>
0&&a.toggleClass("vertical");a.filter(".horizontal").length>0&&a.toggleClass("horizontal")});return b}});
Readium.Models.ManifestItem=Backbone.Model.extend({parseMetaTags:function(){var a;typeof this.get("meta_width")==="undefined"&&(this.isSvg()?a=this.parseViewboxTag():this.isImage()||(a=this.parseViewportTag()),a&&this.set({meta_width:a.width,meta_height:a.height}))},getContentDom:function(){var a=this.get("content");if(a)return(new window.DOMParser).parseFromString(a,"text/xml")},parseViewportTag:function(){var a=this.getContentDom();if(a){a=a.getElementsByName("viewport")[0];if(!a)return null;for(var a=
a.getAttribute("content"),a=a.replace(/\s/g,""),a=a.split(","),b={},c,d=0;d<a.length;d++)c=a[d].split("="),c.length===2&&(b[c[0]]=c[1]);b.width=parseFloat(b.width,10);b.height=parseFloat(b.height,10);return b}},parseViewboxTag:function(){var a=this.getContentDom();if(a){var a=a.documentElement.getAttribute("viewBox").split(/,?\s+|,/),b={};b.width=parseFloat(a[2],10);b.height=parseFloat(a[3],10);return b}},resolvePath:function(a){return this.collection.packageDocument.resolvePath(a)},resolveUri:function(a){return this.collection.packageDocument.resolveUri(a)},
isSvg:function(){return this.get("media_type")==="image/svg+xml"},isImage:function(){var a=this.get("media_type");return a&&a.indexOf("image/")>-1?a!=="image/svg+xml":!1},loadContent:function(){var a=this,b=this.resolvePath(this.get("href"));Readium.FileSystemApi(function(c){c.readTextFile(b,function(b){a.set({content:b})},function(){console.log("Failed to load file: "+b)})})}});
Readium.Models.SpineItem=Readium.Models.ManifestItem.extend({initialize:function(){this.isFixedLayout()&&(this.on("change:content",this.parseMetaTags,this),this.loadContent())},buildSectionJSON:function(a,b){if(!a)return null;var c=Object.create(null);c.width=this.get("meta_width")||0;c.height=this.get("meta_height")||0;c.uri=this.packageDocument.resolveUri(a.get("href"));c.page_class=this.getPageSpreadClass(a,b);return c},toJSON:function(){this.isFixedLayout()&&this.parseMetaTags();var a={};a.width=
this.get("meta_width")||0;a.height=this.get("meta_height")||0;a.uri=this.resolveUri(this.get("href"));a.page_class=this.getPageSpreadClass();return a},getPageSpreadClass:function(){var a=this.collection.packageDocument.get("book"),b=this.get("spine_index");return a.get("apple_fixed")?b===0?"center_page":b%2===1&&b===this.collection.length?"center_page":b%2===0?"right_page":"left_page":this.get("page_spread")?(a=this.get("page_spread"),a==="left"?"left_page":a==="right"?"right_page":"center_page"):
this.get("page_prog_dir")==="rtl"?b%2===0?"right_page":"left_page":b%2===0?"left_page":"right_page"},isFixedLayout:function(){return this.isSvg()||this.isImage()?!0:typeof this.get("fixed_flow")!=="undefined"?this.get("fixed_flow"):this.collection.isBookFixedLayout()},getPageView:function(){if(!this.view)this.view=this.isImage()?new Readium.Views.ImagePageView({model:this}):new Readium.Views.FixedPageView({model:this});return this.view},hasMediaOverlay:function(){return!!this.get("media_overlay")&&
!!this.getMediaOverlay()},getMediaOverlay:function(){return this.collection.getMediaOverlay(this.get("media_overlay"))}});Readium.Collections.ManifestItems=Backbone.Collection.extend({model:Readium.Models.ManifestItem,initialize:function(a,b){this.packageDocument=b.packageDocument}});
Readium.Collections.Spine=Backbone.Collection.extend({model:Readium.Models.SpineItem,initialize:function(a,b){this.packageDocument=b.packageDocument},isBookFixedLayout:function(){return this.packageDocument.get("book").isFixedLayout()},getMediaOverlay:function(a){return this.packageDocument.getMediaOverlayItem(a)}});
Readium.Models.PackageDocumentParser=function(a){this.uri_obj=a};
Readium.Models.PackageDocumentParser.JathTemplate={metadata:{id:"//def:metadata/dc:identifier",epub_version:"//def:package/@version",title:"//def:metadata/dc:title",author:"//def:metadata/dc:creator",publisher:"//def:metadata/dc:publisher",description:"//def:metadata/dc:description",rights:"//def:metadata/dc:rights",language:"//def:metadata/dc:language",pubdate:"//def:metadata/dc:date",modified_date:"//def:metadata/def:meta[@property='dcterms:modified']",layout:"//def:metadata/def:meta[@property='rendition:layout']",
spread:"//def:metadata/def:meta[@property='rendition:spread']",orientation:"//def:metadata/def:meta[@property='rendition:orientation']",ncx:"//def:spine/@toc",page_prog_dir:"//def:spine/@page-progression-direction",active_class:"//def:metadata/def:meta[@property='media:active-class']"},manifest:["//def:item",{id:"@id",href:"@href",media_type:"@media-type",properties:"@properties",media_overlay:"@media-overlay"}],spine:["//def:itemref",{idref:"@idref",properties:"@properties",linear:"@linear"}],bindings:["//def:bindings/def:mediaType",
{handler:"@handler",media_type:"@media-type"}]};
Readium.Models.PackageDocumentParser.prototype.parse=function(a){var c;c=typeof a==="string"?(new window.DOMParser).parseFromString(a,"text/xml"):a;Jath.resolver=function(a){return{def:"http://www.idpf.org/2007/opf",dc:"http://purl.org/dc/elements/1.1/"}[a]};a=Jath.parse(Readium.Models.PackageDocumentParser.JathTemplate,c);a.paginate_backwards=this.paginateBackwards(c);if(c=this.getCoverHref(c))a.metadata.cover_href=this.resolveUri(c);if(a.metadata.layout==="pre-paginated")a.metadata.fixed_layout=
!0;a.manifest=new Readium.Collections.ManifestItems(a.manifest,{packageDocument:this});a.mo_map=this.resolveMediaOverlays(a.manifest);a.spine=this.parseSpineProperties(a.spine);return a};
Readium.Models.PackageDocumentParser.prototype.getCoverHref=function(a){var c,b;c=a.getElementsByTagName("manifest")[0];b=$('item[properties~="cover-image"]',c);if(b.length===1&&b.attr("href"))return b.attr("href");a=$('meta[name="cover"]',a);b=a.attr("content");if(a.length===1&&b&&(b=$('item[id="'+b+'"]',c),b.length===1&&b.attr("href")))return b.attr("href");b=$("#cover",c);return b.length===1&&b.attr("href")?b.attr("href"):null};
Readium.Models.PackageDocumentParser.prototype.parseSpineProperties=function(a){for(var c=function(a){for(var b={},a=a.split(" "),c=0;c<a.length;c++){if(a[c]==="rendition:page-spread-center")b.page_spread="center";if(a[c]==="page-spread-left")b.page_spread="left";if(a[c]==="page-spread-right")b.page_spread="right";if(a[c]==="page-spread-right")b.page_spread="right";if(a[c]==="rendition:layout-reflowable")b.fixed_flow=!1;if(a[c]==="rendition:layout-pre-paginated")b.fixed_flow=!0}return b},b=0;b<a.length;b++){var e=
c(a[b].properties);_.extend(a[b],e)}return a};Readium.Models.PackageDocumentParser.prototype.resolveMediaOverlays=function(a){var c=this,b={};a.forEach(function(a){if(a.get("media_type")==="application/smil+xml"){var d=c.resolveUri(a.get("href")),f=new Readium.Models.MediaOverlay;f.setUrl(d);f.fetch();b[a.id]=f}});return b};Readium.Models.PackageDocumentParser.prototype.paginateBackwards=function(a){return $("spine",a).attr("page-progression-direction")==="ltr"};
Readium.Models.PackageDocumentParser.prototype.crunchSpine=function(a,c){var b=this,e=-1,d=_.map(a,function(a){e+=1;var d=c.find(function(b){if(b.get("id")===a.idref)return b}),g=b.get("book");return _.extend({},a,d.attributes,{spine_index:e},{page_prog_dir:g.get("page_prog_dir")})});return new Readium.Collections.Spine(d,{packageDocument:this})};Readium.Models.PackageDocumentParser.prototype.resolveUri=function(a){uri=new URI(a);return uri.resolve(this.uri_obj).toString()};
Readium.Models.PackageDocument=Backbone.Model.extend({initialize:function(a){var b=this;if(a.file_path)this.file_path=a.file_path,Readium.FileSystemApi(function(a){a.getFsUri(b.file_path,function(a){b.uri_obj=new URI(a)})});else throw"This class cannot be synced without a file path";this.on("change:spine_position",this.onSpinePosChanged)},onSpinePosChanged:function(){this.get("spine_position")>=this.previous("spine_position")?this.trigger("increased:spine_position"):this.trigger("decreased:spine_position")},
validate:function(a){if(!a.manifest&&!this.get("manifest"))return"ERROR: All ePUBs must have a manifest";var b=a.spine||this.get("spine");if(!b)return"ERROR: All ePUBs must have a spine";if(a.spine_position<0||a.spine_position>=b.length)return"ERROR: invalid spine position"},sync:BBFileSystemSync,defaults:{spine_position:0},getManifestItemById:function(a){return this.get("manifest").find(function(b){if(b.get("id")===a)return b})},getSpineItem:function(a){return this.get("res_spine").at(a)},spineLength:function(){return this.get("res_spine").length},
getNextLinearSpinePostition:function(a){var b=this.get("res_spine");if(a===void 0||a<-1)a=-1;for(;a<b.length-1;)if(a+=1,b.at(a).get("linear")!=="no")return a;return-1},getPrevLinearSpinePostition:function(a){var b=this.get("res_spine");if(a===void 0||a>b.length)a=b.length;for(;a>0;)if(a-=1,b.at(a).get("linear")!=="no")return a;return-1},goToNextSection:function(){this.set({spine_position:this.get("spine_position")+1})},goToPrevSection:function(){this.set({spine_position:this.get("spine_position")-
1})},spineIndexFromHref:function(a){for(var b=this.get("res_spine"),a=this.resolveUri(a).replace(/#.*$/,""),c=0;c<b.length;c++){var d=b.at(c).get("href"),d=this.resolveUri(d).replace(/#.*$/,"");if(d===a)return c}return-1},goToHref:function(a){var b=this.get("spine"),c=this.get("manifest"),d=this,a=d.resolveUri(a).replace(/#.*$/,""),c=c.find(function(b){var c=d.resolveUri(b.get("href")).replace(/#.*$/,"");if(a==c)return b});if(!c)return null;for(var c=c.get("id"),e=0;e<b.length;++e)if(b[e].idref===
c){this.set({spine_position:e},{silent:!0});this._previousAttributes.spine_position=0;this.trigger("change:spine_position");break}},getTocItem:function(){var a=this.get("manifest"),b=this.get("metadata").ncx,c=a.find(function(a){return a.get("properties")==="nav"});return c?c:b&&b.length>0?a.find(function(a){return a.get("id")===b}):null},getMediaOverlayItem:function(a){var b=this.get("mo_map");return b&&b[a]},crunchSpine:function(a,b){var c=this,d=-1,e=_.map(a,function(a){d+=1;var e=b.find(function(b){if(b.get("id")===
a.idref)return b}),f=c.get("book");return _.extend({},a,e.attributes,{spine_index:d},{page_prog_dir:f.get("page_prog_dir")})});$.each(e,function(){this.id+=this.spine_index});return new Readium.Collections.Spine(e,{packageDocument:this})},parse:function(a){a=(new Readium.Models.PackageDocumentParser(this.uri_obj)).parse(a);a.res_spine=this.crunchSpine(a.spine,a.manifest);return a},resolveUri:function(a){uri=new URI(a);return uri.resolve(this.uri_obj).toString()},resolvePath:function(a){var b=this.file_path,
a=a.indexOf("../")===0?a.substr(3):a,c=b.lastIndexOf("/");return b.substr(0,c)+"/"+a}});
Readium.Models.EPUBController=Backbone.Model.extend({initialize:function(){var a=this;this.epub=this.get("epub");this.set("media_overlay_controller",new Readium.Models.MediaOverlayController({epubController:this}));this.paginator=new Readium.Models.PaginationStrategySelector({book:this});this.packageDocument=this.epub.getPackageDocument();this.packageDocument.fetch({success:function(){var b=a.restorePosition();a.set("spine_position",b);b=a.paginator.renderSpineItems(!1);a.set("rendered_spine_items",
b);a.set("has_toc",!!a.packageDocument.getTocItem())}});this.on("change:spine_position",this.savePosition,this);this.on("change:spine_position",this.setMetaSize,this)},save:function(a,b){var d={success:function(){}};_.extend(d,b);var c=this;this.set("updated_at",new Date);this.set("key",this.epub.get("key")+"_epubViewProperties");Lawnchair(function(){this.save(c.toJSON(),d.success)})},defaults:{font_size:10,two_up:!1,full_screen:!1,toolbar_visible:!0,toc_visible:!1,rendered_spine_items:[],current_theme:"default-theme",
current_margin:3,epubCFIs:{}},toJSON:function(){return{updated_at:this.get("updated_at"),current_theme:this.get("current_theme"),current_margin:this.get("current_margin"),two_up:this.get("two_up"),font_size:this.get("font_size"),key:this.get("key"),epubCFIs:this.get("epubCFIs")}},toggleFullScreen:function(){this.set({full_screen:!this.get("full_screen")})},increaseFont:function(){this.set({font_size:this.get("font_size")+1})},decreaseFont:function(){this.set({font_size:this.get("font_size")-1})},
toggleToc:function(){this.set("toc_visible",!this.get("toc_visible"))},goToHref:function(a){a=a.match(/([^#]*)(?:#(.*))?/);a[2]&&a[2].match(/epubcfi/)?this.handleCFIReference(a[2]):a[1]&&(this.setSpinePos(this.packageDocument.spineIndexFromHref(a[1]),!1,!1,a[2]),this.set("hash_fragment",a[2]))},getToc:function(){var a=this.packageDocument.getTocItem();return a?Readium.Models.Toc.getToc(a,{file_path:this.resolvePath(a.get("href")),book:this}):null},getCurrentSection:function(a){a||(a=0);return this.packageDocument.getSpineItem(this.get("spine_position")+
a)},isFixedLayout:function(){return this.epub.isFixedLayout()},handleCFIReference:function(a){var b,d,c;$.ajax({type:"GET",url:this.epub.get("root_url"),dataType:"xml",async:!1,success:function(a){b=a}});d=this.packageDocument.spineIndexFromHref(EPUBcfi.Interpreter.getContentDocHref(a,b));c=Crypto.SHA1(a);this.addCFIwithPayload(a,d,"<span id='"+c+"' class='cfi_marker' data-cfi='"+a+"'></span>");this.setSpinePos(d,!1,!0,c);this.set("hash_fragment",c)},restorePosition:function(){var a=Readium.Utils.getCookie(this.epub.get("key"));
return parseInt(a,10)||this.packageDocument.getNextLinearSpinePostition()},savePosition:function(){Readium.Utils.setCookie(this.epub.get("key"),this.get("spine_position"),365)},resolvePath:function(a){return this.packageDocument.resolvePath(a)},hasNextSection:function(){return this.packageDocument.getPrevLinearSpinePostition(this.get("spine_position"))>-1},hasPrevSection:function(){return this.packageDocument.getNextLinearSpinePostition(this.get("spine_position"))>-1},goToNextSection:function(){var a=
this.packageDocument.getNextLinearSpinePostition(this.get("spine_position"));a>-1&&this.setSpinePos(a,!1,!1)},goToPrevSection:function(){var a=this.packageDocument.getPrevLinearSpinePostition(this.get("spine_position"));a>-1&&this.setSpinePos(a,!0,!1)},setSpinePos:function(a,b,d,c){if(!(a<0||a>=this.packageDocument.spineLength())){var e=this.get("rendered_spine_items").indexOf(a)>=0?!0:!1;this.set("spine_position",a);this.trigger("FXL_goToPage");e?d?(a=this.paginator.renderSpineItems(b,c),this.set("rendered_spine_items",
a)):!this.isFixedLayout()&&c&&this.paginator.v.goToHashFragment(c):(a=this.paginator.renderSpineItems(b,c),this.set("rendered_spine_items",a))}},setMetaSize:function(){this.meta_section&&this.meta_section.off("change:meta_height",this.setMetaSize);this.meta_section=this.getCurrentSection();this.meta_section.get("meta_height")&&this.set("meta_size",{width:this.meta_section.get("meta_width"),height:this.meta_section.get("meta_height")});this.meta_section.on("change:meta_height",this.setMetaSize,this)},
addCFIwithPayload:function(a,b,d,c){b={contentDocSpinePos:b,payload:d,type:c};this.get("epubCFIs")[a]=b},addLastPageCFI:function(a,b){var d="<span id='"+Crypto.SHA1(a)+"' data-last-page-cfi='"+a+"' class='cfi-marker last-page'></span>",d={contentDocSpinePos:b,payload:d,type:"last-page"},c=this.get("epubCFIs");$.each(c,function(a){this.type==="last-page"&&delete c[a]});this.get("epubCFIs")[a]=d}});
Readium.Models.OptionsPresenter=Backbone.Model.extend({initialize:function(){var a=this.get("book");if(!a)throw"ebook must be set in the constructor";this.resetOptions();a.on("change:font_size",this.resetOptions,this);a.on("change:two_up",this.resetOptions,this);a.on("change:current_theme",this.resetOptions,this);a.on("change:current_margin",this.resetOptions,this)},applyOptions:function(){var a=this.get("book");a.set({font_size:this.get("font_size"),current_theme:this.get("current_theme"),current_margin:this.get("current_margin")});
this.get("two_up")!==a.get("two_up")&&a.set("two_up",!a.get("two_up"));a.save()},resetOptions:function(){var a=this.get("book");this.set({font_size:a.get("font_size"),two_up:a.get("two_up"),current_theme:a.get("current_theme"),current_margin:a.get("current_margin")})}});
Readium.Models.Toc=Backbone.Model.extend({sync:BBFileSystemSync,initialize:function(a){this.file_path=a.file_path;this.book=a.book;this.book.on("change:toc_visible",this.setVisibility,this);this.book.on("change:toolbar_visible",this.setTocVis,this)},handleLink:function(a){var b=this.book.packageDocument.getTocItem().get("href");b.indexOf("/")!==-1&&(b=new URI(b),a=(new URI(a)).resolve(b).toString());this.book.goToHref(a)},setVisibility:function(){this.set("visible",this.book.get("toc_visible"))},
hide:function(){this.book.set("toc_visible",!1)},setTocVis:function(){this.book.get("toolbar_visible")||this.book.set("toc_visible",!1)},defaults:{visible:!1}},{XHTML_MIME:"application/xhtml+xml",XML_MIME:"text/xml",NCX_MIME:"application/x-dtbncx+xml",getToc:function(a,b){var c=a.get("media_type");if(c===Readium.Models.Toc.XHTML_MIME||c===Readium.Models.Toc.XML_MIME)return new Readium.Models.XhtmlToc(b);else if(c===Readium.Models.Toc.NCX_MIME)return new Readium.Models.NcxToc(b)}});
Readium.Models.NcxToc=Readium.Models.Toc.extend({jath_template:{title:"//ncx:docTitle/ncx:text",navs:["//ncx:navMap/ncx:navPoint",{text:"ncx:navLabel/ncx:text",href:"ncx:content/@src"}]},parse:function(a){var b={},c=this;typeof a==="string"&&(a=(new window.DOMParser).parseFromString(a,"text/xml"));b.title=$($("text",$("docTitle",a)[0])[0]).text();b.navs=[];a=$("navMap",a);$.each(a.children(),function(){$(this).is("navPoint")&&b.navs.push(c.createNavPointObject($(this)))});return b},createNavPointObject:function(a){var b=
{},c=this;b.navs=[];$.each(a.children(),function(){$currElement=$(this);$currElement.is("content")?b.href=$currElement.attr("src"):$currElement.is("navLabel")?b.text=$($("text",$currElement)[0]).text():$currElement.is("navPoint")&&b.navs.push(c.createNavPointObject($currElement))});return b},TocView:function(){return new Readium.Views.NcxTocView({model:this})}});
Readium.Models.XhtmlToc=Readium.Models.Toc.extend({parse:function(a){var b={};typeof a==="string"&&(a=(new window.DOMParser).parseFromString(a,"text/xml"));b.title=$("title",a).text();b.body=$("body",a);return b},TocView:function(){return new Readium.Views.XhtmlTocView({model:this})}});
Readium.Models.SmilModel=function(){function h(a){m(a);a.childNodes.length>0&&$.each(a.childNodes,function(a,b){h(b)})}function m(a){a.toString=function(){for(var a="<"+this.nodeName,b=0;b<this.attributes.length;b++)a+=" "+this.attributes.item(b).nodeName+"="+this.attributes.item(b).nodeValue;a+=">";return a};if(g.hasOwnProperty(a.tagName))a.render=g[a.tagName];if(i.hasOwnProperty(a.tagName))a.notifyChildDone=i[a.tagName];n(a)}function n(a){a.tagName=="audio"&&($(a).attr("src")!=void 0&&$(a).attr("src",
o($(a).attr("src"),j)),$(a).attr("clipBegin")!=void 0?$(a).attr("clipBegin",k($(a).attr("clipBegin"))):$(a).attr("clipBegin",0),$(a).attr("clipEnd")!=void 0?$(a).attr("clipEnd",k($(a).attr("clipEnd"))):$(a).attr("clipEnd",9999999))}function o(a,c){if(a.indexOf("://")!=-1)return a;var b=c;c[c.length-1]!="/"&&(b=c.substr(0,c.lastIndexOf("/")+1));return b+a}function k(a){var c=0,b=0,d=0;a.indexOf("min")!=-1?b=parseFloat(a.substr(0,a.indexOf("min"))):a.indexOf("ms")!=-1?d=parseFloat(a.substr(0,a.indexOf("ms")))/
1E3:a.indexOf("s")!=-1?d=parseFloat(a.substr(0,a.indexOf("s"))):a.indexOf("h")!=-1?c=parseFloat(a.substr(0,a.indexOf("h"))):(arr=a.split(":"),d=parseFloat(arr.pop()),arr.length>0&&(b=parseFloat(arr.pop()),arr.length>0&&(c=parseFloat(arr.pop()))));return c*3600+b*60+d}NodeLogic={parRender:function(){$.each(this.childNodes,function(a,c){c.hasOwnProperty("render")&&c.render()})},seqRender:function(a){a==null?this.firstElementChild.render():a.render()},audioNotifyChildDone:function(){this.parentNode.notifyChildDone(this)},
parNotifyChildDone:function(a){a.tagName=="audio"&&this.parentNode.notifyChildDone(this)},seqNotifyChildDone:function(a){a.nextElementSibling==null?this==e?l():this.parentNode.notifyChildDone(this):this.render(a.nextElementSibling)}};var g={seq:NodeLogic.seqRender,par:NodeLogic.parRender,body:NodeLogic.seqRender},i={seq:NodeLogic.seqNotifyChildDone,par:NodeLogic.parNotifyChildDone,body:NodeLogic.seqNotifyChildDone,audio:NodeLogic.audioNotifyChildDone,text:function(){}},j=null,l=null,e=null;this.addRenderers=
function(a){g=$.extend(g,a)};this.setUrl=function(a){j=a};this.setNotifySmilDone=function(a){l=a};this.build=function(a){e=a;h(a)};this.render=function(a){a==null||a==void 0||a==e?e.render(null):(this.peekNextAudio(a).isJumpTarget=!0,a.parentNode.render(a))};this.findNodeByAttrValue=function(a,c,b){if(e==null)return null;var d=null,f=c;if(f=="src"||f=="epub:textref"){f=="epub:textref"&&(f="epub\\:textref");var g=b.substr(b.lastIndexOf("/")+1),a=$(e).find(a+"["+f+"]");b==""?d=a[0]:a.each(function(){var a=
$(this).attr(f);if(a!=void 0&&(a=a.substr(a.lastIndexOf("/")+1),a===g))return d=this,!1})}else f!=""&&(a+="["+f,b!=""&&(a+="='"+b+"'"),a+="]"),d=$(e).find(a),d=d.length==0?null:d[0];return d};this.peekNextAudio=function(a){if(a.tagName=="par")return $(a).find("audio")[0];if(a.tagName=="text")return $(a.parentNode).find("audio")[0];for(a=a.parentNode;a.nextElementSibling==null;)if(a=a.parentNode,a==e)return null;return $(a.nextElementSibling).find("audio")[0]}};
Readium.Models.MediaOverlay=Backbone.Model.extend({audioplayer:null,smilModel:null,consoleTrace:!1,url:null,defaults:{current_text_src:null,has_started_playback:!1,is_document_done:!1,is_playing:!1,is_ready:!1},initialize:function(){var a=this;this.audioplayer=new Readium.Models.AudioClipPlayer;this.audioplayer.setConsoleTrace(!1);this.audioplayer.setNotifyOnPause(function(){a.set({is_playing:a.audioplayer.isPlaying()})});this.audioplayer.setNotifyOnPlay(function(){a.set({is_playing:a.audioplayer.isPlaying()})})},
setUrl:function(a){this.url=a},fetch:function(a){this.set({is_ready:!1});a=a||{};a.dataType="xml";Backbone.Model.prototype.fetch.call(this,a)},parse:function(a){var b=this;this.smilModel=new Readium.Models.SmilModel;this.smilModel.setUrl(this.url);this.smilModel.setNotifySmilDone(function(){b.debugPrint("document done");b.set({is_document_done:!0})});this.smilModel.addRenderers({audio:function(){var a=this;b.audioplayer.setNotifyClipDone(function(){a.notifyChildDone()});var c=!1;if(this.hasOwnProperty("isJumpTarget"))c=
this.isJumpTarget,this.isJumpTarget=!1;b.audioplayer.play($(this).attr("src"),parseFloat($(this).attr("clipBegin")),parseFloat($(this).attr("clipEnd")),c)},text:function(){var a=$(this).attr("src");b.debugPrint("Text: "+a);b.set("current_text_src",a)}});this.smilModel.build($(a).find("body")[0]);this.set({is_ready:!0})},startPlayback:function(a){this.get("is_ready")==!1?this.debugPrint("document not ready"):(this.set({is_document_done:!1}),this.set({has_started_playback:!0}),this.smilModel.render(a))},
pause:function(){this.get("is_ready")==!1?this.debugPrint("document not ready"):this.get("has_started_playback")==!1?this.debugPrint("can't pause: playback not yet started"):this.audioplayer.pause()},resume:function(){this.get("is_ready")==!1?this.debugPrint("document not ready"):this.get("has_started_playback")==!1?this.debugPrint("can't resume: playback not yet started"):this.audioplayer.resume()},findNodeByTextSrc:function(a){if(this.get("is_ready")==!1)return this.debugPrint("document not ready"),
null;if(a==null||a==void 0||a=="")return null;var b=this.smilModel.findNodeByAttrValue("text","src",a);b==null&&(b=this.smilModel.findNodeByAttrValue("seq","epub:textref",a));return b},setVolume:function(a){this.audioplayer.setVolume(a)},setRate:function(a){this.audioplayer.setRate(a)},getVolume:function(){return this.audioplayer.getVolume()},getRate:function(){return this.audioplayer.getRate()},reset:function(){this.set("current_text_src",null);this.set("has_started_playback",!1)},setConsoleTrace:function(a){this.consoleTrace=
a},debugPrint:function(a){this.consoleTrace&&console.log("MediaOverlay: "+a)}});
Readium.Models.AudioClipPlayer=function(){function n(){function b(){a.removeEventListener("canplay",b);if(e>a.duration)f("File is shorter than specified clipEnd time"),e=a.duration;f("Audio data loaded");a.playbackRate=i;k()}f("Loading file "+g);a.setAttribute("src",g);a.addEventListener("canplay",b);a.addEventListener("ended",function(){c!=null&&clearInterval(c);d!=null&&d()})}function k(){if(l==!1&&a.currentTime>h&&a.currentTime<e)j(),a.play();else{a.addEventListener("seeked",b);f("setting currentTime from "+
a.currentTime+"to "+h);a.currentTime=h;var b=function(){a.removeEventListener("seeked",b);j();a.play()}}}function j(){c!=null&&clearInterval(c);c=setInterval(function(){a.currentTime>=e&&(clearInterval(c),f("clip done"),d!=null&&d())},11)}function f(a){m&&console.log("AudioClipPlayer: "+a)}var g=null,h=null,e=null,l=!1,a=new Audio,d=null,m=!1,c=null,i=1;this.setNotifyClipDone=function(a){d=a};this.setConsoleTrace=function(a){m=a};this.play=function(b,c,d,j){g=b;h=c;e=d;l=j;f("playing "+g+" from "+
h+" to "+e);a==null||a.getAttribute("src")!=g?n():(a.playbackRate=i,k())};this.isPlaying=function(){return a==null?!1:!a.paused};this.resume=function(){a!=null&&a.play()};this.pause=function(){a!=null&&a.pause()};this.setNotifyOnPause=function(b){a.addEventListener("pause",function(){b()})};this.setNotifyOnPlay=function(b){a.addEventListener("play",function(){b()})};this.getCurrentTime=function(){return a!=null?a.currentTime:0};this.getCurrentSrc=function(){return g};this.setVolume=function(b){a.volume=
b<0?0:b>1?1:b};this.setRate=function(b){if(this.isPlaying())a.playbackRate=b;i=b};this.getVolume=function(){return a.volume};this.getRate=function(){return i}};
Readium.Models.PaginationStrategySelector=Backbone.Model.extend({renderToLastPage:!1,initialize:function(){this.model=this.get("book");this.zoomer=new Readium.Views.FixedLayoutBookZoomer},renderSpineItems:function(a,c){var b=this.model;this.v&&this.v.destruct();this.v=b.getCurrentSection().isFixedLayout()?new Readium.Views.FixedPaginationView({model:b,zoomer:this.zoomer}):this.shouldScroll()?new Readium.Views.ScrollingPaginationView({model:b,zoomer:this.zoomer}):new Readium.Views.ReflowablePaginationView({model:b,
zoomer:this.zoomer});return this.rendered_spine_positions=this.v.render(!!a,c)},shouldScroll:function(){var a=localStorage.READIUM_OPTIONS;return!(a&&JSON.parse(a)||{singleton:{}}).singleton.paginate_everything}});
Readium.Models.Trigger=function(a){a=$(a);this.action=a.attr("action");this.ref=a.attr("ref");this.event=a.attr("ev:event");this.observer=a.attr("ev:observer");this.ref=a.attr("ref")};Readium.Models.Trigger.prototype.subscribe=function(a){var b=this;$("#"+this.observer,a).on(this.event,function(){b.execute(a)})};
Readium.Models.Trigger.prototype.execute=function(a){a=$("#"+this.ref,a);switch(this.action){case "show":a.css("visibility","visible");break;case "hide":a.css("visibility","hidden");break;case "play":a[0].currentTime=0;a[0].play();break;case "pause":a[0].pause();break;case "resume":a[0].play();break;case "mute":a[0].muted=!0;break;case "unmute":a[0].muted=!1;break;default:console.log("do not no how to handle trigger "+this.action)}};
Readium.Views.PaginationViewBase=Backbone.View.extend({el:"#readium-book-view-el",initialize:function(a){this.zoomer=a.zoomer;this.pages=new Readium.Models.ReadiumPagination({model:this.model});this.mediaOverlayController=this.model.get("media_overlay_controller");this.mediaOverlayController.setPages(this.pages);this.mediaOverlayController.setView(this);this.pages.on("change:current_page",this.showCurrentPages,this);this.model.on("change:font_size",this.setFontSize,this);this.model.on("change:two_up",
this.pages.toggleTwoUp,this.pages);this.mediaOverlayController.on("change:mo_text_id",this.highlightText,this);this.mediaOverlayController.on("change:active_mo",this.indicateMoIsPlaying,this);this.bindingTemplate=Handlebars.templates.binding_template},iframeLoadCallback:function(a){this.applyBindings($(a.srcElement).contents());this.applySwitches($(a.srcElement).contents());this.addSwipeHandlers($(a.srcElement).contents());this.injectMathJax(a.srcElement);this.injectLinkHandler(a.srcElement);var b=
this.parseTriggers(a.srcElement.contentDocument);this.applyTriggers(a.srcElement.contentDocument,b);this.mediaOverlayController.pagesLoaded()},activateEPubStyle:function(a){var b;this.model.get("current_theme")==="night-theme"?(b=new Readium.Models.AlternateStyleTagSelector,b.activateAlternateStyleSet(["night"],a)):(b=new Readium.Models.AlternateStyleTagSelector,b.activateAlternateStyleSet([""],a))},setUpMode:function(){var a=this.model.get("two_up");this.$el.toggleClass("two-up",a);this.$("#spine-divider").toggle(a)},
showCurrentPages:function(){var a=this,b=this.model.get("two_up");this.$(".page-wrap").each(function(c){b||(c+=1);$(this).toggleClass("hidden-page",!a.pages.isPageVisible(c))})},destruct:function(){this.pages.off("change:current_page",this.showCurrentPages);this.model.off("change:font_size",this.setFontSize);this.mediaOverlayController.off("change:mo_text_id",this.highlightText);this.mediaOverlayController.off("change:active_mo",this.indicateMoIsPlaying);this.resetEl()},getBindings:function(){var a=
this.model.epub.getPackageDocument();return a.get("bindings").map(function(b){b.selector='object[type="'+b.media_type+'"]';b.url=a.getManifestItemById(b.handler).get("href");b.url=a.resolveUri(b.url);return b})},applyBindings:function(a){for(var b=this,c=this.getBindings(),d=0,d=0;d<c.length;d++)$(c[d].selector,a).each(function(){var a=[],f=$(this),e=f.attr("data");a.push("src="+b.model.packageDocument.resolveUri(e));a.push("type="+c[d].media_type);a=c[d].url+"?"+a.join("&");e=$(b.bindingTemplate({}));
e.attr("src",a);f.html(e)})},applyTriggers:function(a,b){for(var c=0;c<b.length;c++)b[c].subscribe(a)},parseTriggers:function(a){var b=[];$("trigger",a).each(function(){b.push(new Readium.Models.Trigger(this))});return b},applySwitches:function(a){$("switch",a).each(function(){var a=!1;$("case",this).each(function(){var c;if(c=!a)(c=this.attributes["required-namespace"])?c=_.include(["http://www.w3.org/1998/Math/MathML"],c):(console.log("Encountered a case statement with no required-namespace"),c=
!1);c?a=!0:$(this).remove()});a&&$("default",this).remove()})},addSwipeHandlers:function(a){var b=this;$(a).on("swipeleft",function(a){a.preventDefault();b.pages.goRight()});$(a).on("swiperight",function(a){a.preventDefault();b.pages.goLeft()})},injectMathJax:function(a){var b;b=a.contentDocument;if(a=b.getElementsByTagName("head")[0])b=b.createElement("script"),b.type="text/javascript",b.src=MathJax.Hub.config.root+"/MathJax.js?config=readium-iframe",a.appendChild(b)},injectLinkHandler:function(a){var b=
this;$("a",a.contentDocument).click(function(a){b.linkClickHandler(a)})},resetEl:function(){$("body").removeClass("apple-fixed-layout");$("#readium-book-view-el").attr("style","");this.$el.toggleClass("two-up",!1);this.$("#spine-divider").toggle(!1);this.zoomer.reset();$("#page-wrap").css({position:"relative",right:"0px",top:"0px","-webkit-transform":"scale(1.0) translate(0px, 0px)"})}});
Readium.Views.FixedPaginationView=Readium.Views.PaginationViewBase.extend({initialize:function(a){Readium.Views.PaginationViewBase.prototype.initialize.call(this,a);this.model.get("spine_position");this.model.on("FXL_goToPage",this.spinePositionChangeHandler,this);this.model.on("change:two_up",this.setUpMode,this);this.model.on("change:meta_size",this.setContainerSize,this)},render:function(){$("body").addClass("apple-fixed-layout");this.$("#container").html("");this.setContainerSize();this.setUpMode();
for(var a=this,b=1,c=this.findPrerenderStart(),d=[],e=this.model.get("spine_position");this.shouldPreRender(this.model.getCurrentSection(c));)this.addPage(this.model.getCurrentSection(c),b),d.push(e+c),b+=1,c+=1;c=d.indexOf(e)+1;this.pages.set("num_pages",b-1);this.pages.goToPage(c);setTimeout(function(){a.setContainerSize()},15);this.showCurrentPages();return d},getPageBody:function(a){a=$("#page-"+a.toString()+" iframe");return a.length>0?(a=a.contents()[0].documentElement,$(a).find("body")):null},
indicateMoIsPlaying:function(){(new Readium.Models.MediaOverlayViewHelper({epubController:this.model})).renderFixedMoPlaying(this.pages.get("current_page"),this.mediaOverlayController.get("active_mo"),this)},highlightText:function(){(new Readium.Models.MediaOverlayViewHelper({epubController:this.model})).renderFixedLayoutMoFragHighlight(this.pages.get("current_page"),this.mediaOverlayController.get("mo_text_id"),this)},destruct:function(){Readium.Views.PaginationViewBase.prototype.destruct.call(this);
this.model.off("change:two_up",this.setUpMode);this.model.off("change:meta_size",this.setUpMode)},linkClickHandler:function(a){a.preventDefault();a=a.currentTarget.attributes["xlink:href"]?a.currentTarget.attributes["xlink:href"].value:a.currentTarget.attributes.href.value;a=this.resolveRelativeURI(a);a.match(/^http(s)?:/)?window.open(a):this.model.goToHref(a)},resolveRelativeURI:function(a){var b,c,d;b=this.model.getCurrentSection().get("href");indexOfFilenameStart=b.lastIndexOf("/")+1;c=b.substr(indexOfFilenameStart,
a.length);$(".fixed-page-wrap").each(function(){var a=$(".content-sandbox",this).attr("src"),b=a.lastIndexOf("/")+1;if(a.substr(b,a.length)===c)return d=a,!1});a=new URI(a);b=new URI(d);return a.resolve(b).toString()},spinePositionChangeHandler:function(){this.pages.goToPage(this.model.get("spine_position")+1)},addPage:function(a,b){var c=this,d=a.getPageView();d.on("iframe_loaded",function(){this.iframeLoadCallback({srcElement:d.iframe()});c.applyKeydownHandler($(d.iframe()))},this);var e=a.getPageView().render().el;
$(e).attr("id","page-"+b.toString());this.$("#container").append(e);this.showCurrentPages();return this},setContainerSize:function(){var a=this.model.get("meta_size");if(a&&(this.$el.width(a.width*2),this.$el.height(a.height),this.zoomer.fitToBest(),!this.zoomed))this.zoomed=!0},findPrerenderStart:function(){for(var a=0;this.shouldPreRender(this.model.getCurrentSection(a));)a-=1;return a+1},shouldPreRender:function(a){return a&&a.isFixedLayout()},showCurrentPages:function(){var a=this,b=new Readium.Models.MediaOverlayViewHelper({epubController:this.model});
this.$(".fixed-page-wrap").each(function(b){$(this).toggle(a.pages.isPageVisible(b+1))});$.each(this.pages.get("current_page"),function(){b.removeActiveClass(a.getPageBody(this.toString()))})},setFontSize:function(){var a=this.model.get("font_size")/10;$("#readium-content-container").css("font-size",a+"em");this.showCurrentPages()},applyKeydownHandler:function(a){var b=this;a.contents().keydown(function(a){a.which==39&&b.model.paginator.v.pages.goRight();a.which==37&&b.model.paginator.v.pages.goLeft()})}});
Readium.Views.FixedPageView=Backbone.View.extend({className:"fixed-page-wrap",initialize:function(){this.template=Handlebars.templates.fixed_page_template;this.model.on("change",this.render,this)},destruct:function(){this.model.off("change",this.render)},render:function(){var a=this;this.$el.html(this.template(this.model.toJSON()));this.$el.addClass(this.model.getPageSpreadClass());this.$(".content-sandbox").on("load",function(){a.trigger("iframe_loaded")});return this},iframe:function(){return this.$(".content-sandbox")[0]}});
Readium.Views.ImagePageView=Backbone.View.extend({className:"fixed-page-wrap",initialize:function(){this.template=Handlebars.templates.image_page_template;this.model.on("change",this.render,this)},render:function(){var a=this;this.$el.html(this.template(this.model.toJSON()));this.$el.addClass(this.model.getPageSpreadClass());this.$("img").on("load",function(){a.setSize()});return this},setSize:function(){var a=this.$("img"),b=a.width(),a=a.height();b>0&&this.model.set({meta_width:b,meta_height:a})}});
Readium.Views.ReflowablePaginationView=Readium.Views.PaginationViewBase.extend({initialize:function(a){Readium.Views.PaginationViewBase.prototype.initialize.call(this,a);this.page_template=Handlebars.templates.reflowing_template;this.stashModernizrPrefixedProps();this.offset_dir=this.model.epub.get("page_prog_dir")==="rtl"?"right":"left";this.pages.on("change:current_page",this.pageChangeHandler,this);this.model.on("change:toc_visible",this.windowSizeChangeHandler,this);this.model.on("repagination_event",
this.windowSizeChangeHandler,this);this.model.on("change:current_theme",this.injectTheme,this);this.model.on("change:two_up",this.setUpMode,this);this.model.on("change:two_up",this.adjustIframeColumns,this);this.model.on("change:current_margin",this.marginCallback,this);this.model.on("save_position",this.savePosition,this)},render:function(a,b){var c=this,d=this.model.getCurrentSection().toJSON();this.setUpMode();this.$("#container").html(this.page_template(d));this.$("#readium-flowing-content").on("load",
function(d){var e=c.injectCFIElements();c.adjustIframeColumns();c.iframeLoadCallback(d);c.setFontSize();c.injectTheme();c.setNumPages();c.applyKeydownHandler();b?c.goToHashFragment(b):e?c.goToHashFragment(e):a?c.pages.goToLastPage():c.pages.goToPage(1)});return[this.model.get("spine_position")]},findVisiblePageElements:function(){var a=$(this.getBody()).find("[id]"),b=$("#readium-flowing-content").contents()[0].documentElement,c=0+$(b).width(),b=0+$(b).height();return this.filterElementsByPosition(a,
0,b,0,c)},indicateMoIsPlaying:function(){(new Readium.Models.MediaOverlayViewHelper({epubController:this.model})).renderReflowableMoPlaying(this.model.get("current_theme"),this.mediaOverlayController.get("active_mo"),this)},highlightText:function(){(new Readium.Models.MediaOverlayViewHelper({epubController:this.model})).renderReflowableMoFragHighlight(this.model.get("current_theme"),this,this.mediaOverlayController.get("mo_text_id"))},goToHashFragment:function(a){if(a&&(a=$("#"+a,this.getBody())[0])){for(;a.children.length>
0;)a=a.children[0];a=this.getElemPageNumber(a);a>0&&this.pages.goToPage(a)}},destruct:function(){this.pages.off("change:current_page",this.pageChangeHandler);this.model.off("change:toc_visible",this.windowSizeChangeHandler);this.model.off("repagination_event",this.windowSizeChangeHandler);this.model.off("change:current_theme",this.windowSizeChangeHandler);this.model.off("change:two_up",this.setUpMode);this.model.off("change:two_up",this.adjustIframeColumns);this.model.off("change:current_margin",
this.marginCallback);Readium.Views.PaginationViewBase.prototype.destruct.call(this)},findVisibleTextNode:function(){var a,b,c,d,f;d=$("body",this.getBody()).find(":not(iframe)").contents().filter(function(){return this.nodeType===3?!0:!1});c=$("#readium-flowing-content").contents()[0].documentElement;this.model.get("two_up")?(b=parseInt($(c).css("-webkit-column-gap").replace("px","")),c=parseInt($(c).css("-webkit-column-width").replace("px","")),a=0+b+c*2):a=0+$(c).width();$.each(d,function(){var b=
$(this).parent(),c=b.position().left,b=c+b.width(),d,c=Math.abs(c)<5?0:c,b=Math.abs(b-a)<5?a:b;d=this.nodeValue.replace(/\n/g,"");d=d.replace(/ /g,"");if(c<=a&&b>=0&&d.length>10)return f=$(this),!1});return f},findVisibleCharacterOffset:function(a){var b,c,d,f,e;b=a.parent();c=$($("#readium-flowing-content").contents()[0].documentElement);d=c.position().top;f=d+c.height();c=b.offset().top;b.height();c<d?(b=Math.abs(c-d)/b.height(),characterOffsetByPercent=Math.ceil(b*a[0].length),e=Math.ceil(0.5*
(a[0].length-characterOffsetByPercent))+characterOffsetByPercent):c>=d&&c<=f?e=1:c<f&&(e=1);return e},filterElementsByPosition:function(a,b,c,d,f){return a.filter(function(){var a=$(this).offset().top,g=$(this).offset().left,h=g+$(this).width(),i=a+$(this).height(),a=a>=b&&i<=c;return g>=d&&h<=f&&a})},linkClickHandler:function(a){a.preventDefault();a=a.currentTarget.attributes["xlink:href"]?a.currentTarget.attributes["xlink:href"].value:a.currentTarget.attributes.href.value;a=this.resolveRelativeURI(a);
a.match(/^http(s)?:/)?window.open(a):this.model.goToHref(a)},resolveRelativeURI:function(a){var a=new URI(a),b=new URI($("#readium-flowing-content").attr("src"));return a.resolve(b).toString()},applyKeydownHandler:function(){var a=this;this.$("#readium-flowing-content").contents().keydown(function(b){b.which==39&&a.model.paginator.v.pages.goRight();b.which==37&&a.model.paginator.v.pages.goLeft()})},goToPage:function(a){if(!(this.model.get("current_page")!=void 0&&this.model.get("current_page").indexOf(a)!=
-1)){var b=this.calcPageOffset(a).toString()+"px";$(this.getBody()).css(this.offset_dir,"-"+b);this.showContent();(this.model.get("two_up")==!1||this.model.get("two_up")&&a%2===1)&&this.mediaOverlayController.reflowPageChanged()}},setFontSize:function(){var a=this.model.get("font_size")/10;$(this.getBody()).css("font-size",a+"em");this.setNumPages()},stashModernizrPrefixedProps:function(){var a=function(a){return a.replace(/([A-Z])/g,function(a,b){return"-"+b.toLowerCase()}).replace(/^ms-/,"-ms-")};
this.columAxis=Modernizr.prefixed("columnAxis")||"columnAxis";this.columGap=Modernizr.prefixed("columnGap")||"columnGap";this.columWidth=Modernizr.prefixed("columnWidth")||"columnWidth";this.cssColumAxis=a(this.columAxis);this.cssColumGap=a(this.columGap);this.cssColumWidth=a(this.columWidth)},getBodyColumnCss:function(){var a={};a[this.cssColumAxis]="horizontal";a[this.cssColumGap]=this.gap_width.toString()+"px";a[this.cssColumWidth]=this.page_width.toString()+"px";a.padding="0px";a.margin="0px";
a.position="absolute";a.width=this.page_width.toString()+"px";a.height=this.frame_height.toString()+"px";return a},injectCFIElements:function(){var a=this,b,c,d;b=$("#readium-flowing-content").contents()[0];c=this.model.get("epubCFIs");_.each(c,function(c,e){if(c.contentDocSpinePos===a.model.get("spine_position"))try{EPUBcfi.Interpreter.injectElement(e,b,c.payload,["cfi-marker"],[],["MathJax_Message"]),c.type==="last-page"&&(d=$(c.payload).attr("id"))}catch(g){console.log("Could not inject CFI")}});
return d},savePosition:function(){var a,b,c=!1,d,f,e;a=this.findVisibleTextNode();try{$.each(a.parent().contents(),function(){if($(this).hasClass("last-page"))return c=!0,b=$(this).attr("data-last-page-cfi"),!1})}catch(g){console.log("Could not generate CFI for non-text node as first visible element on page");return}c?this.model.addLastPageCFI(b,this.model.get("spine_position")):(d=this.findVisibleCharacterOffset(a),f=this.model.getCurrentSection().get("idref"),$.ajax({type:"GET",url:this.model.epub.get("root_url"),
dataType:"xml",async:!1,success:function(a){e=a}}),this.model.addLastPageCFI(EPUBcfi.Generator.generateCharacterOffsetCFI(a[0],d,f,e,["cfi-marker"],[],["MathJax_Message"]),this.model.get("spine_position")));this.model.save()},adjustIframeColumns:function(){var a=this.$("#readium-flowing-content");this.setFrameSize();this.frame_width=parseInt(a.width(),10);this.frame_height=parseInt(a.height(),10);this.gap_width=Math.floor(this.frame_width/7);this.page_width=this.model.get("two_up")?Math.floor((this.frame_width-
this.gap_width)/2):this.frame_width;$(this.getBody()).css(this.getBodyColumnCss());this.setNumPages();this.goToPage(this.pages.get("current_page")[0]||1)},getBody:function(){return this.$("#readium-flowing-content").contents()[0].documentElement},hideContent:function(){$("#flowing-wrapper").css("opacity","0")},showContent:function(){$("#flowing-wrapper").css("opacity","1")},calcPageOffset:function(a){return(a-1)*(this.page_width+this.gap_width)},setFrameSize:function(){var a=this.getFrameWidth().toString()+
"px",b=this.getFrameHeight().toString()+"px";this.$("#readium-flowing-content").attr("width",a);this.$("#readium-flowing-content").attr("height",b);this.$("#readium-flowing-content").css("width",a);this.$("#readium-flowing-content").css("height",b)},getFrameWidth:function(){var a,b=this.model.get("current_margin");b===1?this.model.get("two_up")?a=0.95:a=0.9:b===2?this.model.get("two_up")?a=0.89:a=0.8:b===3?this.model.get("two_up")?a=0.83:a=0.7:b===4?this.model.get("two_up")?a=0.77:a=0.6:this.model.get("two_up")?
a=0.7:a=0.5;return Math.floor($("#flowing-wrapper").width()*a)},getFrameHeight:function(){return $("#flowing-wrapper").height()},calcNumPages:function(){var a,b,c;a=this.getBody();b=a.style[this.offset_dir];a.style[this.offset_dir]="0px";c=this.getBody().scrollWidth;a.style[this.offset_dir]=b;a=Math.floor((c+this.gap_width)/(this.gap_width+this.page_width));a%2===0&&this.model.get("two_up");return a},getElemPageNumber:function(a){var b,c=!1,d;b=$(a);b.attr("epub:type")==="pagebreak"&&!b.is(":visible")&&
(c=!0,b.show());a=a.getClientRects();if(!a||a.length<1)return-1;d=a[0][this.offset_dir];d+=Math.abs(a[0].left-a[0].right);c&&b.hide();this.offset_dir==="right"&&(d=this.page_width-d);d-=parseInt(this.getBody().style[this.offset_dir],10);return Math.ceil(d/(this.page_width+this.gap_width))},getElemPageNumberById:function(a){var b=$("#readium-flowing-content").contents()[0].documentElement,a=$(b).find("#"+a);return a.length==0?-1:this.getElemPageNumber(a[0])},pageChangeHandler:function(){var a=this;
this.hideContent();setTimeout(function(){a.goToPage(a.pages.get("current_page")[0]);a.model.paginator.v.savePosition()},150)},windowSizeChangeHandler:function(){this.adjustIframeColumns();this.goToHashFragment(this.model.get("hash_fragment"))},marginCallback:function(){this.adjustIframeColumns()},themes:{"default-theme":{"background-color":"white",color:"black","mo-color":"#777"},"vancouver-theme":{"background-color":"#DDD",color:"#576b96","mo-color":"#777"},"ballard-theme":{"background-color":"#576b96",
color:"#DDD","mo-color":"#888"},"parchment-theme":{"background-color":"#f7f1cf",color:"#774c27","mo-color":"#eebb22"},"night-theme":{"background-color":"#141414",color:"white","mo-color":"#666"}},injectTheme:function(){var a=this.model.get("current_theme");a==="default"&&(a="default-theme");$(this.getBody()).css({color:this.themes[a].color,"background-color":this.themes[a]["background-color"]});$("#flowing-wrapper").css("visibility","hidden");this.activateEPubStyle(this.getBody());setTimeout(function(){$("#flowing-wrapper").css("visibility",
"visible")},100)},setNumPages:function(){this.pages.set("num_pages",this.calcNumPages())}});
Readium.Views.ScrollingPaginationView=Readium.Views.PaginationViewBase.extend({initialize:function(a){Readium.Views.PaginationViewBase.prototype.initialize.call(this,a);this.page_template=Handlebars.templates.scrolling_page_template},render:function(){var a=this,b=this.model.getCurrentSection().toJSON();this.$("#container").html(this.page_template(b));this.$(".content-sandbox").on("load",function(b){a.iframeLoadCallback(b)});return[this.model.get("spine_position")]},destruct:function(){Readium.Views.PaginationViewBase.prototype.destruct.call(this)}});
Readium.Views.ToolbarView=Backbone.View.extend({el:"#toolbar-el",initialize:function(){this.model.on("change:toolbar_visible",this.renderBarVisibility,this);this.model.on("change:full_screen",this.renderFullScreen,this);this.model.on("change:current_theme",this.renderThemeButton,this);this.model.on("change:spine_position",this.renderMoButtons,this);var a=this.model.get("media_overlay_controller");a.on("change:volume",this.renderVolumeButton,this);a.on("change:rate",this.renderRateButton,this)},render:function(){this.renderBarVisibility();
this.renderFullScreen();this.renderThemeButton();this.renderTitle();return this},renderBarVisibility:function(){var a=this.model.get("toolbar_visible");this.$("#show-toolbar-button").toggle(!a);this.$("#toolbar-title").toggle(!a);this.$("#top-bar").toggle(a);return this},renderFullScreen:function(){var a=this.model.get("full_screen");this.$("#go-to-fs-ico").toggle(!a);this.$("#leave-fs-ico").toggle(a);return this},renderThemeButton:function(){var a=this.model.get("current_theme")==="night-theme";
this.$("#night-to-day-ico").toggle(a);this.$("#day-to-night-ico").toggle(!a);return this},renderTitle:function(){var a=this.model.epub.get("title");this.$("#toolbar-title").html(a);return this},renderMoButtons:function(){this.model.getCurrentSection().hasMediaOverlay()?($("#play-mo-btn").show(),$("#mo-volume-btn-group").show(),$("#mo-rate-btn-group").show(),this.renderVolumeButton(),this.renderRateButton()):($("#play-mo-btn").hide(),$("#mo-volume-btn-group").hide(),$("#mo-rate-btn-group").hide())},
renderVolumeButton:function(){var a=this.model.get("media_overlay_controller"),b=a.get("volume");$("#mo-volume-slider").val(b);a=a.get("volume")==0;this.$("#mo-volume-btn").toggle(!a);this.$("#mo-volume-muted-btn").toggle(a)},renderRateButton:function(){var a=this.model.get("media_overlay_controller").get("rate");$("#mo-rate-slider").val(a)},events:{"click #hide-toolbar-button":"hide_toolbar","click #show-toolbar-button":"show_toolbar","click #fs-toggle-btn":"toggle_fs","click #toggle-toc-btn":"toggle_toc",
"click #nightmode-btn":"toggle_night_mode","click #play-mo-btn":"play_mo","change #mo-volume-slider":"set_mo_volume","click #mo-volume-btn":"mute_mo","click #mo-volume-muted-btn":"mute_mo","change #mo-rate-slider":"set_mo_rate","click #mo-rate-btn":"reset_mo_rate"},show_toolbar:function(a){a.preventDefault();this.model.set("toolbar_visible",!0)},hide_toolbar:function(a){a.preventDefault();this.model.set("toolbar_visible",!1)},toggle_fs:function(a){a.preventDefault();this.model.toggleFullScreen()},
toggle_toc:function(a){a.preventDefault();this.model.toggleToc()},toggle_night_mode:function(){this.model.get("current_theme")==="night-theme"?this.model.set("current_theme","default-theme"):this.model.set("current_theme","night-theme");this.model.save()},play_mo:function(){var a=this.model.get("media_overlay_controller");a.get("active_mo")?a.pauseMo():a.playMo()},set_mo_volume:function(){var a=$("#mo-volume-slider"),a=parseFloat(a.val()).toFixed(1);this.model.get("media_overlay_controller").set("volume",
a)},mute_mo:function(){this.model.get("media_overlay_controller").mute()},set_mo_rate:function(){var a=$("#mo-rate-slider"),a=parseFloat(a.val()).toFixed(1);this.model.get("media_overlay_controller").set("rate",a)},reset_mo_rate:function(){this.model.get("media_overlay_controller").set("rate",1)}});
Readium.Views.TocViewBase=Backbone.View.extend({el:"#readium-toc",initialize:function(){this.model.on("change",this.render,this);this.model.on("change:visible",this.setVisibility,this)},events:{"click a":"handleClick","click #close-toc-button":"closeToc"},setVisibility:function(){this.$el.toggle(this.model.get("visible"))},handleClick:function(a){a.preventDefault();href=$(a.currentTarget).attr("href");this.model.handleLink(href)},handleSelect:function(a){this.model.handleLink(a.val)},closeToc:function(a){a.preventDefault();
this.model.hide()}});
Readium.Views.NcxTocView=Readium.Views.TocViewBase.extend({initialize:function(){Readium.Views.TocViewBase.prototype.initialize.call(this);this.nav_template=Handlebars.templates.ncx_nav_template},render:function(){var a;this.setVisibility();a=this.addNavPointElements(this.model.get("navs"));this.$("#toc-body").html("<h2>"+(this.model.get("title")||"Contents")+"</h2>");this.$("#toc-body").append(a);this.$("#toc-body").append("<div id='toc-end-spacer'>");return this},addNavPointElements:function(a){var b=$("<ol></ol>"),
d=this;$.each(a,function(c){b.append(d.nav_template(a[c]));if(a[c].navs.length>0){var e=$("<li></li>");e.append(d.addNavPointElements(a[c].navs));b.append(e)}});return b}});
Readium.Views.XhtmlTocView=Readium.Views.TocViewBase.extend({events:{"click a":"handleClick","click #close-toc-button":"closeToc","change #toc-body":"handleSelect"},render:function(){this.$("#toc-body").html(this.model.get("body").html());this.formatPageListNavigation();this.$("#toc-body").append("<div id='toc-end-spacer'>");return this},formatPageListNavigation:function(){var a,b=[];a=this.$("nav").filter(function(){if($(this).attr("epub:type")==="page-list")return $(this).attr("id","page-list-select"),
$(this).hide(),!0});$.each($("a",a),function(){var a=$(this);b.push({id:a.attr("href"),text:"Page-"+a.text()})});$("#page-list-select").select2({placeholder:"Select a page",data:b});this.$("[onclick]").removeAttr("onclick")}});
Readium.Views.OptionsView=Backbone.View.extend({el:"#viewer-settings-modal",initialize:function(){this.model.on("change:current_theme",this.renderTheme,this);this.model.on("change:two_up",this.renderUpMode,this);this.model.on("change:current_margin",this.renderMarginRadio,this);this.model.on("change:font_size",this.renderFontSize,this)},render:function(){this.renderTheme();this.renderUpMode();this.renderMarginRadio();this.renderFontSize();return this},renderTheme:function(){this.$("#preview-text")[0].className=
this.model.get("current_theme");return this},renderUpMode:function(){var a=this.model.get("two_up");this.$("#one-up-option").toggleClass("selected",!a);this.$("#two-up-option").toggleClass("selected",a);return this},renderMarginRadio:function(){var a="#margin-option-"+this.model.get("current_margin");this.$(".margin-radio").toggleClass("selected",!1);this.$(a).toggleClass("selected",!0);return this},renderFontSize:function(){var a=this.model.get("font_size"),b=(a/10).toString()+"em";this.$("#preview-text").css("font-size",
b);this.$("#font-size-input").val(a)},events:{"click .theme-option":"selectTheme","click .margin-radio":"selectMargin","click #cancel-settings-but":"cancelSettings","click #save-settings-but":"applySettings","change #font-size-input":"extractFontSize","click #one-up-option":function(){this.model.set("two_up",!1)},"click #two-up-option":function(){this.model.set("two_up",!0)}},extractFontSize:function(){var a=$("#font-size-input").val(),a=parseInt(a,10);this.model.set("font_size",a)},selectTheme:function(a){a=
a.srcElement.id;a==="default-theme-option"&&this.model.set("current_theme","default-theme");a==="night-theme-option"&&this.model.set("current_theme","night-theme");a==="parchment-theme-option"&&this.model.set("current_theme","parchment-theme");a==="ballard-theme-option"&&this.model.set("current_theme","ballard-theme");a==="vancouver-theme-option"&&this.model.set("current_theme","vancouver-theme")},selectMargin:function(a){a=a.srcElement.id;a=a[a.length-1];a==="1"&&this.model.set("current_margin",
1);a==="2"&&this.model.set("current_margin",2);a==="3"&&this.model.set("current_margin",3);a==="4"&&this.model.set("current_margin",4);a==="5"&&this.model.set("current_margin",5)},cancelSettings:function(){this.$el.modal("hide");this.model.resetOptions()},applySettings:function(){this.model.applyOptions();this.$el.modal("hide")}});
Readium.Views.FixedLayoutBookZoomer=Backbone.View.extend({el:"#readium-right-content",horizontalPad:30,verticalPad:30,initialize:function(){this.zoomingModel=new Readium.Models.FixedLayoutBookZoomingModel},render:function(){this.$("#page-wrap").css(this.zoomingModel.getCSSProperties());return this},reset:function(){this.zoomingModel.setDefaults();this.render()},fitToBest:function(){var a=this.fitToWidthScale(),b=this.fitToHeightScale();a<b?this.applyScale(a):this.applyScale(b)},fitToWidth:function(){this.applyScale(this.fitToWidthScale())},
fitToHeight:function(){this.applyScale(this.fitToHeightScale())},fitToWidthScale:function(){return(this.containerWidth()-this.horizontalPad)/this.bookWidth()},fitToHeightScale:function(){return(this.containerHeight()-this.verticalPad)/this.bookHeight()},applyScale:function(a){this.zoomingModel.set("scale",a);this.zoomingModel.set("leftShift",this.leftShift(a));this.zoomingModel.set("topShift",this.verticalPad/2);this.render()},leftShift:function(a){return(this.containerWidth()-this.bookWidth()*a)/
2},containerWidth:function(){return this.$el.width()},containerHeight:function(){return this.$el.height()},bookWidth:function(){return this.$("#page-wrap").width()},bookHeight:function(){return this.$("#page-wrap").height()}});
Readium.Models.FixedLayoutBookZoomingModel=Backbone.Model.extend({initialize:function(){this.styleAttrs=this.getModernizedAttrs()},defaults:{scale:1,leftShift:0,topShift:0},setDefaults:function(){this.set(this.defaults)},getModernizedAttrs:function(){var a={};a.transform=this.modernizrCssPrefix("transform");a.transformOrigin=this.modernizrCssPrefix("transformOrigin");return a},modernizrCssPrefix:function(a){return Modernizr.prefixed(a).replace(/([A-Z])/g,function(a,c){return"-"+c.toLowerCase()}).replace(/^ms-/,
"-ms-")},getCSSProperties:function(){var a={};a[this.styleAttrs.transform]=this.getTransformString();a[this.styleAttrs.transformOrigin]="0 0";return a},getTransformString:function(){str="";str+="translate("+this.get("leftShift")+"px, "+this.get("topShift")+"px) ";str+="scale("+this.get("scale").toString()+")";return str}});
Readium.Views.ViewerApplicationView=Backbone.View.extend({el:"body",uiVisible:!1,initialize:function(){this.model.on("change:full_screen",this.toggleFullscreen,this);this.model.on("change:current_theme",this.renderTheme,this);this.model.on("change:toolbar_visible",this.renderPageButtons,this);this.model.on("change:toc_visible",this.renderTocVisible,this);this.optionsPresenter=new Readium.Models.OptionsPresenter({book:this.model});this.optionsView=new Readium.Views.OptionsView({model:this.optionsPresenter});
this.optionsView.render();this.toolbar=new Readium.Views.ToolbarView({model:_epubController});this.toolbar.render();this.model.on("change:has_toc",this.init_toc,this);this.addGlobalEventHandlers()},toggleFullscreen:function(){this.model.get("full_screen")?document.documentElement.webkitRequestFullScreen():document.webkitCancelFullScreen()},addGlobalEventHandlers:function(){var a=this.model,b=this;window.onresize=function(){a.trigger("repagination_event")};$(document).keydown(function(a){a.which==
39&&b.model.paginator.v.pages.goRight();a.which==37&&b.model.paginator.v.pages.goLeft()});$("#readium-book-view-el").on("swipeleft",function(a){a.preventDefault();b.model.paginator.v.pages.goRight()});$("#readium-book-view-el").on("swiperight",function(a){a.preventDefault();b.model.paginator.v.pages.goLeft()})},render:function(){this.renderTheme();this.renderPageButtons();this.renderTocVisible();return this},renderPageButtons:function(){var a=this.model.get("toolbar_visible");this.$("#prev-page-button").toggle(a);
this.$("#next-page-button").toggle(a);return this},renderTheme:function(){var a=this.model.get("current_theme");this.$el.toggleClass("default-theme","default-theme"===a);this.$el.toggleClass("night-theme","night-theme"===a);this.$el.toggleClass("parchment-theme","parchment-theme"===a);this.$el.toggleClass("ballard-theme","ballard-theme"===a);this.$el.toggleClass("vancouver-theme","vancouver-theme"===a);this.$("#readium-book-view-el").toggleClass("default-theme","default-theme"===a);this.$("#readium-book-view-el").toggleClass("night-theme",
"night-theme"===a);this.$("#readium-book-view-el").toggleClass("parchment-theme","parchment-theme"===a);this.$("#readium-book-view-el").toggleClass("ballard-theme","ballard-theme"===a);this.$("#readium-book-view-el").toggleClass("vancouver-theme","vancouver-theme"===a)},renderTocVisible:function(){this.$el.toggleClass("show-readium-toc",this.model.get("toc_visible"));return this},init_toc:function(){if(this.model.get("has_toc")){var a=this.model.getToc();this.toc=a.TocView();a.fetch()}},events:{"click #prev-page-button":function(){this.model.paginator.v.pages.goLeft()},
"click #next-page-button":function(){this.model.paginator.v.pages.goRight()}}});
Readium.Routers.ViewerRouter=Backbone.Router.extend({routes:{"views/viewer.html?book=:key":"openBook","*splat":"splat_handler"},openBook:function(a){var b=a+"_epubViewProperties";Lawnchair(function(){this.get(a,function(a){a===null?alert("Could not load ePUB, try refeshing your browser."):(window._epub=new Readium.Models.EPUB(a),this.get(b,function(a){window._epubController=new Readium.Models.EPUBController(_.extend({epub:window._epub},a));window._applicationView=new Readium.Views.ViewerApplicationView({model:window._epubController});
window._applicationView.render()}))})})},splat_handler:function(a){console.log(a)}});
Readium.Models.EPUB=Backbone.Model.extend({defaults:{can_two_up:!0},initialize:function(){this.packageDocument=new Readium.Models.PackageDocument({book:this,file_path:this.get("package_doc_path")})},getPackageDocument:function(){return this.packageDocument},toJSON:function(){return{apple_fixed:this.get("apple_fixed"),author:this.get("author"),cover_href:this.get("cover_href"),created_at:this.get("created_at"),description:this.get("description"),epub_version:this.get("epub_version"),fixed_layout:this.get("fixed_layout"),
id:this.get("id"),key:this.get("key"),language:this.get("language"),layout:this.get("layout"),modified_date:this.get("modified_date"),ncx:this.get("ncx"),open_to_spread:this.get("open_to_spread"),orientation:this.get("orientation"),package_doc_path:this.get("package_doc_path"),page_prog_dir:this.get("page_prog_dir"),paginate_backwards:this.get("paginate_backwards"),pubdate:this.get("pubdate"),publisher:this.get("publisher"),rights:this.get("rights"),spread:this.get("spread"),src_url:this.get("src_url"),
title:this.get("title")}},resolvePath:function(a){return this.packageDocument.resolvePath(a)},isFixedLayout:function(){return this.get("fixed_layout")||this.get("apple_fixed")}});
Readium.Models.PageNumberDisplayLogic=Backbone.Model.extend({initialize:function(){},getGotoPageNumsToDisplay:function(a,b,d,e){return b?d?e==="rtl"?this.displayedPageIsLeft(a)?[a-1,a]:this.displayedPageIsRight(a)?[a,a+1]:[a]:this.displayedPageIsLeft(a)?[a,a+1]:this.displayedPageIsRight(a)?[a-1,a]:[a]:a%2===1?[a,a+1]:[a-1,a]:[a]},getPrevPageNumsToDisplay:function(a,b,d){return b?d==="rtl"?this.displayedPageIsLeft(a)&&this.displayedPageIsRight(a-1)?[a-1,a]:[a]:this.displayedPageIsRight(a)&&this.displayedPageIsLeft(a-
1)?[a-1,a]:[a]:[a-1,a]},getNextPageNumsToDisplay:function(a,b,d){return b?d==="rtl"?this.displayedPageIsRight(a)&&this.displayedPageIsLeft(a+1)?[a,a+1]:[a]:this.displayedPageIsLeft(a)&&this.displayedPageIsRight(a+1)?[a,a+1]:[a]:[a,a+1]},getPageNumbersForTwoUp:function(a,b,d,e){var c=[];a?c[0]=b[0]===0?1:b[0]:e?d==="rtl"?this.displayedPageIsLeft(b[0])?(c[0]=b[0]-1,c[1]=b[0]):this.displayedPageIsRight(b[0])&&(c[0]=b[0],c[1]=b[0]+1):this.displayedPageIsLeft(b[0])?(c[0]=b[0],c[1]=b[0]+1):this.displayedPageIsRight(b[0])&&
(c[0]=b[0]-1,c[1]=b[0]):b[0]%2===1?(c[0]=b[0],c[1]=b[0]+1):(c[0]=b[0]-1,c[1]=b[0]);return c},displayedPageIsRight:function(a){return $("#page-"+a).hasClass("right_page")?!0:!1},displayedPageIsLeft:function(a){return $("#page-"+a).hasClass("left_page")?!0:!1},displayedPageIsCenter:function(a){return $("#page-"+a).hasClass("center_page")?!0:!1}});
Readium.Models.ReadiumPagination=Backbone.Model.extend({defaults:{num_pages:0},initialize:function(){this.epubController=this.get("model");this.set("current_page",[this.epubController.get("spine_position")+1]);this.pageNumberDisplayLogic=new Readium.Models.PageNumberDisplayLogic;this.on("change:num_pages",this.adjustCurrentPage,this)},toggleTwoUp:function(){this.epubController.get("can_two_up")&&this.set({current_page:this.pageNumberDisplayLogic.getPageNumbersForTwoUp(this.epubController.get("two_up"),
this.get("current_page"),this.epubController.epub.get("page_prog_dir"),this.epubController.getCurrentSection().isFixedLayout())})},goRight:function(){this.epubController.epub.get("page_prog_dir")==="rtl"?this.prevPage():this.nextPage()},goLeft:function(){this.epubController.epub.get("page_prog_dir")==="rtl"?this.nextPage():this.prevPage()},goToPage:function(a){this.set("current_page",this.pageNumberDisplayLogic.getGotoPageNumsToDisplay(a,this.epubController.get("two_up"),this.epubController.getCurrentSection().isFixedLayout(),
this.epubController.epub.get("page_prog_dir")))},isPageVisible:function(a){return this.get("current_page").indexOf(a)!==-1},prevPage:function(){var a=this.get("current_page"),b=a[0]-1;this.epubController.set("hash_fragment",void 0);a[0]<=1?this.epubController.goToPrevSection():this.epubController.paginator.shouldScroll()&&!this.epubController.getCurrentSection().isFixedLayout()?this.epubController.goToPrevSection():this.epubController.get("two_up")?(this.set("current_page",this.pageNumberDisplayLogic.getPrevPageNumsToDisplay(b,
this.epubController.getCurrentSection().isFixedLayout(),this.epubController.epub.get("page_prog_dir"))),this.epubController.get("rendered_spine_items").length>1&&(a=this.epubController.get("rendered_spine_items")[b>1?b-2:0],this.epubController.set("spine_position",a))):(this.set("current_page",[b]),this.epubController.get("rendered_spine_items").length>1&&(a=this.epubController.get("rendered_spine_items")[b-1],this.epubController.set("spine_position",a)))},nextPage:function(){var a=this.get("current_page"),
b=a[a.length-1]+1;this.epubController.set("hash_fragment",void 0);a[a.length-1]>=this.get("num_pages")?this.epubController.goToNextSection():(this.epubController.get("two_up")?this.set("current_page",this.pageNumberDisplayLogic.getNextPageNumsToDisplay(b,this.epubController.getCurrentSection().isFixedLayout(),this.epubController.epub.get("page_prog_dir"))):this.set("current_page",[b]),this.epubController.get("rendered_spine_items").length>1&&(a=this.epubController.get("rendered_spine_items")[b-1],
this.epubController.set("spine_position",a)))},adjustCurrentPage:function(){var a=this.get("current_page"),b=this.get("num_pages");this.epubController.get("two_up");a[a.length-1]>b&&this.goToLastPage()},goToLastPage:function(){this.goToPage(this.get("num_pages"))}});
(function(){var h=Handlebars.template,i=Handlebars.templates=Handlebars.templates||{};i.binding_template=h(function(){return'<iframe scrolling="no" \n\t\tframeborder="0" \n\t\tmarginwidth="0" \n\t\tmarginheight="0" \n\t\twidth="100%" \n\t\theight="100%" \n\t\tclass=\'binding-sandbox\'>\n</iframe>'});i.extracting_item_template=h(function(e,c,d){var d=d||e.helpers,e="",a,b=d.helperMissing,f=this.escapeExpression;e+="<h5>";a=(a=d.log_message)||c.log_message;typeof a==="function"?a=a.call(c,{hash:{}}):
a===void 0&&(a=b.call(c,"log_message",{hash:{}}));e+=f(a)+'</h5>\n<div class="progress progress-striped progress-success active ">\t\n\t\t<div role="status" aria-live="assertive" aria-relevant="all" class="bar" style="width: ';a=(a=d.progress)||c.progress;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=b.call(c,"progress",{hash:{}}));e+=f(a)+'%;"></div>\n</div>';return e});i.fixed_page_template=h(function(e,c,d){var d=d||e.helpers,e="",a,b=d.helperMissing,f=this.escapeExpression;e+='<div class="fixed-page-margin">\n\t<iframe scrolling="no" \n\t\t\tframeborder="0" \n\t\t\tmarginwidth="0" \n\t\t\tmarginheight="0" \n\t\t\twidth="';
a=(a=d.width)||c.width;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=b.call(c,"width",{hash:{}}));e+=f(a)+'px" \n\t\t\theight="';a=(a=d.height)||c.height;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=b.call(c,"height",{hash:{}}));e+=f(a)+'px" \n\t\t\tsrc="';a=(a=d.uri)||c.uri;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=b.call(c,"uri",{hash:{}}));e+=f(a)+"\"\n\t\t\tclass='content-sandbox'>\n\t</iframe>\n</div>";return e});i.image_page_template=h(function(e,
c,d){var d=d||e.helpers,e="",a=d.helperMissing,b=this.escapeExpression;e+='<div class="fixed-page-margin">\n\t<img src="';d=d.uri||c.uri;typeof d==="function"?d=d.call(c,{hash:{}}):d===void 0&&(d=a.call(c,"uri",{hash:{}}));e+=b(d)+'" >\n</div>';return e});i.library_item_template=h(function(e,c,d){var d=d||e.helpers,e="",a,b,f=d.helperMissing,g=this.escapeExpression;e+="<div class='info-wrap'>\n\t<div class='caption book-info'>\n\t\t<h2 class='green info-item title'>";a=(b=d.data)||c.data;a=a===null||
a===void 0||a===!1?a:a.title;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.title",{hash:{}}));e+=g(a)+"</h2>\n\t\t<div class='info-item author'>";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.author;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='info-item epub-version'>ePUB ";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.epub_version;b=(b=d.orUnknown)||
c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t\n\t</div>\n\t\n\t<img class='cover-image read' src='";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.cover_href;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.cover_href",{hash:{}}));e+=g(a)+"' width='150' height='220' alt='Open ePUB ";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.title;typeof a==="function"?a=a.call(c,{hash:{}}):
a===void 0&&(a=f.call(c,"data.title",{hash:{}}));e+=g(a)+"'>\n\t\n\t<a href=\"#details-modal-";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.key;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.key",{hash:{}}));e+=g(a)+'" class="info-icon" data-toggle="modal" role="button">\n\t\t<img class=\'info-icon pull-right\' src=\'/images/library/info-icon.png\' height="39px" width="39px" alt=\'';a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.title;typeof a==="function"?
a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.title",{hash:{}}));e+=g(a)+' information\'>\n\t</a>\n</div>\n\n<div class="caption buttons">\n\t<a href="#todo" class="btn read" data-book=\'';a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.key;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.key",{hash:{}}));e+=g(a)+"' role='button'>";a="i18n_read";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",
a,{hash:{}}):b;e+=g(a)+'</a>\n\t<a href="#details-modal-';a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.key;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.key",{hash:{}}));e+=g(a)+'" class="btn details" data-toggle="modal" role="button">\n\t\t';a="i18n_details";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a)+"\n\t</a>\n</div>\n\n<div id='details-modal-";a=(b=d.data)||
c.data;a=a===null||a===void 0||a===!1?a:a.key;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.key",{hash:{}}));e+=g(a)+"' class='modal fade details-modal'>\n\t<div class=\"pull-left modal-cover-wrap\">\n\t\t<img class='details-cover-image' src='";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.cover_href;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.cover_href",{hash:{}}));e+=g(a)+"' width='150' height='220' alt='ePUB cover'>\n\t\t<div class=\"caption modal-buttons\">\n\t\t\t<a href=\"#\" class=\"btn read\" data-book='<%= data.key %>' role='button'>";
a="i18n_read";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a)+"</a>\n\t\t\t<a class=\"btn btn-danger delete pull-right\" role='button'>";a="i18n_delete";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a)+"</a>\n\t\t</div>\n\t</div>\n\t<div class='caption modal-book-info'>\n\t\t<h3 class='green modal-title'>";
a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.title;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=f.call(c,"data.title",{hash:{}}));e+=g(a)+"</h3>\n\t\t<div class='modal-detail gap'>";a="i18n_author";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.author;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,
{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='modal-detail'>";a="i18n_publisher";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.publisher;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='modal-detail'>";
a="i18n_pub_date";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.pubdate;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='modal-detail'>";a="i18n_modified_date";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,
a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.modified_date;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='modal-detail gap'>";a="i18n_id";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;
a=a===null||a===void 0||a===!1?a:a.id;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='modal-detail green'>";a="i18n_epub_version";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.epub_version;b=(b=d.orUnknown)||c.orUnknown;a=typeof b===
"function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t\t<div class='modal-detail'>";a="i18n_created_at";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a);a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.created_at;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"</div>\n\t</div>\n\t<div class='modal-detail source'>\n\t<span class='green' style=\"padding-right: 10px\">";
a="i18n_source";b=(b=d.fetchInzMessage)||c.fetchInzMessage;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"fetchInzMessage",a,{hash:{}}):b;e+=g(a)+"</span>\n\t\t";a=(b=d.data)||c.data;a=a===null||a===void 0||a===!1?a:a.src_url;b=(b=d.orUnknown)||c.orUnknown;a=typeof b==="function"?b.call(c,a,{hash:{}}):b===void 0?f.call(c,"orUnknown",a,{hash:{}}):b;e+=g(a)+"\n\t</div>\n</div>\t\t\t";return e});i.library_items_template=h(function(e,c,d){var d=d||e.helpers,e="",a,b=d.helperMissing,
f=this.escapeExpression;e+="<div id='empty-message'>\n\t<p id='empty-message-text' class='green'>\n\t\t";a="i18n_add_items";d=d.fetchInzMessage||c.fetchInzMessage;a=typeof d==="function"?d.call(c,a,{hash:{}}):d===void 0?b.call(c,"fetchInzMessage",a,{hash:{}}):d;e+=f(a)+"\n\t</p>\n\t<img id='empty-arrow' src='/images/library/empty_library_arrow.png' alt='' />\n</div>";return e});i.ncx_nav_template=h(function(e,c,d){var d=d||e.helpers,e="",a,b=d.helperMissing,f=this.escapeExpression;e+='<li class="nav-elem">\n\t<a href="';
a=(a=d.href)||c.href;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=b.call(c,"href",{hash:{}}));e+=f(a)+'">';a=(a=d.text)||c.text;typeof a==="function"?a=a.call(c,{hash:{}}):a===void 0&&(a=b.call(c,"text",{hash:{}}));e+=f(a)+"</a>\n</li>";return e});i.reflowing_template=h(function(e,c,d){var d=d||e.helpers,e="",a=d.helperMissing,b=this.escapeExpression;e+='<div id="flowing-wrapper">\n\t<iframe scrolling="no" \n\t\t\tframeborder="0" \n\t\t\tmarginwidth="0" \n\t\t\tmarginheight="0" \n\t\t\twidth="50%" \n\t\t\theight="100%" \n\t\t\tsrc="';
d=d.uri||c.uri;typeof d==="function"?d=d.call(c,{hash:{}}):d===void 0&&(d=a.call(c,"uri",{hash:{}}));e+=b(d)+'"\n\t\t\tid="readium-flowing-content">\n\t</iframe>\n</div>';return e});i.scrolling_page_template=h(function(e,c,d){var d=d||e.helpers,e="",a=d.helperMissing,b=this.escapeExpression;e+='<div id="scrolling-content" class="scrolling-page-wrap">\n\t<div class="scrolling-page-margin">\n\n\t\t<iframe scrolling="yes" \n\t\t\t\tframeborder="0" \n\t\t\t\tmarginwidth="0" \n\t\t\t\tmarginheight="0" \n\t\t\t\twidth="100%" \n\t\t\t\theight="100%" \n\t\t\t\tsrc="';
d=d.uri||c.uri;typeof d==="function"?d=d.call(c,{hash:{}}):d===void 0&&(d=a.call(c,"uri",{hash:{}}));e+=b(d)+"\"\n\t\t\t\tclass='content-sandbox'>\n\t\t</iframe>\n\t</div>\n</div>";return e})})();
Readium.Models.MediaOverlayController=Backbone.Model.extend({defaults:{active_mo:null,mo_text_id:null,rate:1,volume:1},initialize:function(){this.currentSection=this.mo=null;this.processingMoTextSrc=this.autoplayNextSpineItem=!1;this.moTargetNode=null;this.savedVolume=0;this.currentView=this.pages=null;this.epubController=this.get("epubController");this.epubController.on("change:spine_position",this.handleSpineChanged,this);this.on("change:rate",this.rateChanged,this);this.on("change:volume",this.volumeChanged,
this)},setPages:function(a){this.pages!=null&&this.pages.off();this.pages=a},setView:function(a){this.currentView=a},playMo:function(){if(this.mo==null)alert("Sorry, there is no audio for this section.");else{this.set("active_mo",this.mo);this.mo.on("change:current_text_src",this.handleMoTextSrc,this);this.mo.on("change:is_document_done",this.handleMoDocumentDone,this);var a=this.moTargetNode;this.moTargetNode=null;if(this.currentSection.isFixedLayout())this.mo.get("has_started_playback")?this.resumeMo():
this.mo.startPlayback(null);else{var b=-1,c=this.get("mo_text_id");c!=null&&c!=void 0&&c!=""&&(b=this.currentView.getElemPageNumberById(c));this.pages.get("current_page").indexOf(b)!=-1?this.resumeMo():this.mo.startPlayback(a)}}},pauseMo:function(){this.mo&&(this.mo.off(),this.mo.pause(),this.set("active_mo",null))},mute:function(){if(this.mo)this.mo.getVolume()==0?this.set("volume",this.savedVolume):(this.savedVolume=this.mo.getVolume(),this.set("volume",0))},volumeChanged:function(){this.mo&&this.mo.setVolume(this.get("volume"))},
rateChanged:function(){this.mo&&this.mo.setRate(this.get("rate"))},reflowPageChanged:function(){if(!this.processingMoTextSrc&&!this.autoplayNextSpineItem){var a=this.get("active_mo")!=null;a&&this.pauseMo();this.setMoTarget();a&&this.playMo()}},pagesLoaded:function(){if(!this.currentSection.isFixedLayout()&&this.autoplayNextSpineItem==!0)this.autoplayNextSpineItem=!1,this.playMo()},resumeMo:function(){this.set("mo_text_id",null);this.handleMoTextSrc();this.mo.resume()},handleMoTextSrc:function(){var a=
this.mo.get("current_text_src");if(a==null)this.set("mo_text_id",null);else{this.processingMoTextSrc=!0;this.epubController.goToHref(a);var b="";a.indexOf("#")!=-1&&a.indexOf("#")<a.length-1&&(b=a.substr(a.indexOf("#")+1));this.set("mo_text_id",b);this.processingMoTextSrc=!1}},handleMoDocumentDone:function(){if(!(this.mo!=null&&this.mo!=void 0&&this.mo.get("is_document_done")==!1)&&(this.moTargetNode=null,this.pauseMo(),this.epubController.hasNextSection()))this.autoplayNextSpineItem=!0,this.epubController.goToNextSection()},
handleSpineChanged:function(){this.set("mo_text_id",null);if(this.epubController.getCurrentSection()!=this.currentSection){if(this.get("active_mo")!=null)this.autoplayNextSpineItem=!0,this.pauseMo();this.currentSection=this.epubController.getCurrentSection();this.mo=this.currentSection.getMediaOverlay();if(this.mo!=null&&(this.mo.setVolume(this.get("volume")),this.mo.setRate(this.get("rate")),this.mo.reset(),this.currentSection.isFixedLayout()&&this.autoplayNextSpineItem))this.autoplayNextSpineItem=
!1,this.playMo()}},setMoTarget:function(){var a,b;if(this.mo!=null)if(this.currentSection.isFixedLayout())this.moTargetNode=null;else{a=this.currentView.findVisiblePageElements();var c=this.currentSection.get("href");b=null;for(var d=0;d<a.length;d++)if(b=$(a[d]).attr("id"),b=this.mo.findNodeByTextSrc(c+"#"+b))break;this.moTargetNode=b}}});
Readium.Models.MediaOverlayViewHelper=Backbone.Model.extend({initialize:function(){this.epubController=this.get("epubController")},addActiveClass:function(a){var c=this.getActiveClass();a.toggleClass(c,!0)},removeActiveClass:function(a){if(a!=null&&a!=void 0){var c=this.getActiveClass(),a=$(a).find("."+c);a.toggleClass(c,!1);return a}return null},renderFixedLayoutMoFragHighlight:function(a,c,b){var d=this;$.each(a,function(){var a=b.getPageBody(this);d.removeActiveClass(a)});c&&$.each(a,function(){var a=
b.getPageBody(this);(a=$(a).find("#"+c))&&d.addActiveClass(a)})},renderFixedMoPlaying:function(a,c,b){var d=this;this.authorActiveClassExists()&&(c||$.each(a,function(){var a=b.getPageBody(this);d.removeActiveClass(a)}))},renderReflowableMoFragHighlight:function(a,c,b){a==="default"&&(a="default-theme");var d=c.getBody(),e=this.removeActiveClass(d);this.authorActiveClassExists()==!1&&e&&$(e).css("color","");if(b&&(b=$(d).find("#"+b)))this.addActiveClass(b),this.authorActiveClassExists()==!1&&$(b).css("color",
c.themes[a].color)},renderReflowableMoPlaying:function(a,c,b){if(this.authorActiveClassExists()){if(!c)var d=b.getBody(),a=this.removeActiveClass(d)}else a==="default"&&(a="default-theme"),d=b.getBody(),c?$(d).css("color",b.themes[a]["mo-color"]):($(d).css("color",b.themes[a].color),(a=this.removeActiveClass(b.getBody()))&&$(a).css("color",""))},getActiveClass:function(){var a=this.epubController.packageDocument.get("metadata").active_class;a==""&&(a="-readium-epub-media-overlay-active");return a},
authorActiveClassExists:function(){return this.epubController.packageDocument.get("metadata").active_class==""?!1:!0}});
for(var elems=document.getElementsByTagName("span"),i=0;i<elems.length;i++)if(elems[i].id!=null)if(elems[i].id.indexOf("i18n_html_",0)==0){var msg=chrome.i18n.getMessage(elems[i].id);if(msg!="")elems[i].innerHTML=msg}else if(elems[i].id.indexOf("i18n_",0)==0&&(msg=chrome.i18n.getMessage(elems[i].id),msg!=""))elems[i].innerText=msg;
(function(global) {
    
    var EPUBcfi = {};

    EPUBcfi.Parser = (function(){
  /*
   * Generated by PEG.js 0.7.0.
   *
   * http://pegjs.majda.cz/
   */
  
  function quote(s) {
    /*
     * ECMA-262, 5th ed., 7.8.4: All characters may appear literally in a
     * string literal except for the closing quote character, backslash,
     * carriage return, line separator, paragraph separator, and line feed.
     * Any character may appear in the form of an escape sequence.
     *
     * For portability, we also escape escape all control and non-ASCII
     * characters. Note that "\0" and "\v" escape sequences are not used
     * because JSHint does not like the first and IE the second.
     */
     return '"' + s
      .replace(/\\/g, '\\\\')  // backslash
      .replace(/"/g, '\\"')    // closing quote character
      .replace(/\x08/g, '\\b') // backspace
      .replace(/\t/g, '\\t')   // horizontal tab
      .replace(/\n/g, '\\n')   // line feed
      .replace(/\f/g, '\\f')   // form feed
      .replace(/\r/g, '\\r')   // carriage return
      .replace(/[\x00-\x07\x0B\x0E-\x1F\x80-\uFFFF]/g, escape)
      + '"';
  }
  
  var result = {
    /*
     * Parses the input with a generated parser. If the parsing is successfull,
     * returns a value explicitly or implicitly specified by the grammar from
     * which the parser was generated (see |PEG.buildParser|). If the parsing is
     * unsuccessful, throws |PEG.parser.SyntaxError| describing the error.
     */
    parse: function(input, startRule) {
      var parseFunctions = {
        "fragment": parse_fragment,
        "path": parse_path,
        "local_path": parse_local_path,
        "indexStep": parse_indexStep,
        "indirectionStep": parse_indirectionStep,
        "terminus": parse_terminus,
        "idAssertion": parse_idAssertion,
        "textLocationAssertion": parse_textLocationAssertion,
        "parameter": parse_parameter,
        "csv": parse_csv,
        "valueNoSpace": parse_valueNoSpace,
        "value": parse_value,
        "escapedSpecialChars": parse_escapedSpecialChars,
        "number": parse_number,
        "integer": parse_integer,
        "space": parse_space,
        "circumflex": parse_circumflex,
        "doubleQuote": parse_doubleQuote,
        "squareBracket": parse_squareBracket,
        "parentheses": parse_parentheses,
        "comma": parse_comma,
        "semicolon": parse_semicolon,
        "equal": parse_equal,
        "character": parse_character
      };
      
      if (startRule !== undefined) {
        if (parseFunctions[startRule] === undefined) {
          throw new Error("Invalid rule name: " + quote(startRule) + ".");
        }
      } else {
        startRule = "fragment";
      }
      
      var pos = 0;
      var reportFailures = 0;
      var rightmostFailuresPos = 0;
      var rightmostFailuresExpected = [];
      
      function padLeft(input, padding, length) {
        var result = input;
        
        var padLength = length - input.length;
        for (var i = 0; i < padLength; i++) {
          result = padding + result;
        }
        
        return result;
      }
      
      function escape(ch) {
        var charCode = ch.charCodeAt(0);
        var escapeChar;
        var length;
        
        if (charCode <= 0xFF) {
          escapeChar = 'x';
          length = 2;
        } else {
          escapeChar = 'u';
          length = 4;
        }
        
        return '\\' + escapeChar + padLeft(charCode.toString(16).toUpperCase(), '0', length);
      }
      
      function matchFailed(failure) {
        if (pos < rightmostFailuresPos) {
          return;
        }
        
        if (pos > rightmostFailuresPos) {
          rightmostFailuresPos = pos;
          rightmostFailuresExpected = [];
        }
        
        rightmostFailuresExpected.push(failure);
      }
      
      function parse_fragment() {
        var result0, result1, result2;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        if (input.substr(pos, 8) === "epubcfi(") {
          result0 = "epubcfi(";
          pos += 8;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"epubcfi(\"");
          }
        }
        if (result0 !== null) {
          result1 = parse_path();
          if (result1 !== null) {
            if (input.charCodeAt(pos) === 41) {
              result2 = ")";
              pos++;
            } else {
              result2 = null;
              if (reportFailures === 0) {
                matchFailed("\")\"");
              }
            }
            if (result2 !== null) {
              result0 = [result0, result1, result2];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, pathVal) { 
                
                return { type:"CFIAST", cfiString:pathVal }; 
            })(pos0, result0[1]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_path() {
        var result0, result1;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        result0 = parse_indexStep();
        if (result0 !== null) {
          result1 = parse_local_path();
          if (result1 !== null) {
            result0 = [result0, result1];
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, stepVal, localPathVal) { 
        
                return { type:"cfiString", path:stepVal, localPath:localPathVal }; 
            })(pos0, result0[0], result0[1]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_local_path() {
        var result0, result1;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        result1 = parse_indexStep();
        if (result1 === null) {
          result1 = parse_indirectionStep();
        }
        if (result1 !== null) {
          result0 = [];
          while (result1 !== null) {
            result0.push(result1);
            result1 = parse_indexStep();
            if (result1 === null) {
              result1 = parse_indirectionStep();
            }
          }
        } else {
          result0 = null;
        }
        if (result0 !== null) {
          result1 = parse_terminus();
          result1 = result1 !== null ? result1 : "";
          if (result1 !== null) {
            result0 = [result0, result1];
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, localPathStepVal, termStepVal) { 
        
                return { steps:localPathStepVal, termStep:termStepVal }; 
            })(pos0, result0[0], result0[1]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_indexStep() {
        var result0, result1, result2, result3, result4;
        var pos0, pos1, pos2;
        
        pos0 = pos;
        pos1 = pos;
        if (input.charCodeAt(pos) === 47) {
          result0 = "/";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"/\"");
          }
        }
        if (result0 !== null) {
          result1 = parse_integer();
          if (result1 !== null) {
            pos2 = pos;
            if (input.charCodeAt(pos) === 91) {
              result2 = "[";
              pos++;
            } else {
              result2 = null;
              if (reportFailures === 0) {
                matchFailed("\"[\"");
              }
            }
            if (result2 !== null) {
              result3 = parse_idAssertion();
              if (result3 !== null) {
                if (input.charCodeAt(pos) === 93) {
                  result4 = "]";
                  pos++;
                } else {
                  result4 = null;
                  if (reportFailures === 0) {
                    matchFailed("\"]\"");
                  }
                }
                if (result4 !== null) {
                  result2 = [result2, result3, result4];
                } else {
                  result2 = null;
                  pos = pos2;
                }
              } else {
                result2 = null;
                pos = pos2;
              }
            } else {
              result2 = null;
              pos = pos2;
            }
            result2 = result2 !== null ? result2 : "";
            if (result2 !== null) {
              result0 = [result0, result1, result2];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, stepLengthVal, assertVal) { 
        
                return { type:"indexStep", stepLength:stepLengthVal, idAssertion:assertVal[1] };
            })(pos0, result0[1], result0[2]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_indirectionStep() {
        var result0, result1, result2, result3, result4;
        var pos0, pos1, pos2;
        
        pos0 = pos;
        pos1 = pos;
        if (input.substr(pos, 2) === "!/") {
          result0 = "!/";
          pos += 2;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"!/\"");
          }
        }
        if (result0 !== null) {
          result1 = parse_integer();
          if (result1 !== null) {
            pos2 = pos;
            if (input.charCodeAt(pos) === 91) {
              result2 = "[";
              pos++;
            } else {
              result2 = null;
              if (reportFailures === 0) {
                matchFailed("\"[\"");
              }
            }
            if (result2 !== null) {
              result3 = parse_idAssertion();
              if (result3 !== null) {
                if (input.charCodeAt(pos) === 93) {
                  result4 = "]";
                  pos++;
                } else {
                  result4 = null;
                  if (reportFailures === 0) {
                    matchFailed("\"]\"");
                  }
                }
                if (result4 !== null) {
                  result2 = [result2, result3, result4];
                } else {
                  result2 = null;
                  pos = pos2;
                }
              } else {
                result2 = null;
                pos = pos2;
              }
            } else {
              result2 = null;
              pos = pos2;
            }
            result2 = result2 !== null ? result2 : "";
            if (result2 !== null) {
              result0 = [result0, result1, result2];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, stepLengthVal, assertVal) { 
        
                return { type:"indirectionStep", stepLength:stepLengthVal, idAssertion:assertVal[1] };
            })(pos0, result0[1], result0[2]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_terminus() {
        var result0, result1, result2, result3, result4;
        var pos0, pos1, pos2;
        
        pos0 = pos;
        pos1 = pos;
        if (input.charCodeAt(pos) === 58) {
          result0 = ":";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\":\"");
          }
        }
        if (result0 !== null) {
          result1 = parse_integer();
          if (result1 !== null) {
            pos2 = pos;
            if (input.charCodeAt(pos) === 91) {
              result2 = "[";
              pos++;
            } else {
              result2 = null;
              if (reportFailures === 0) {
                matchFailed("\"[\"");
              }
            }
            if (result2 !== null) {
              result3 = parse_textLocationAssertion();
              if (result3 !== null) {
                if (input.charCodeAt(pos) === 93) {
                  result4 = "]";
                  pos++;
                } else {
                  result4 = null;
                  if (reportFailures === 0) {
                    matchFailed("\"]\"");
                  }
                }
                if (result4 !== null) {
                  result2 = [result2, result3, result4];
                } else {
                  result2 = null;
                  pos = pos2;
                }
              } else {
                result2 = null;
                pos = pos2;
              }
            } else {
              result2 = null;
              pos = pos2;
            }
            result2 = result2 !== null ? result2 : "";
            if (result2 !== null) {
              result0 = [result0, result1, result2];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, textOffsetValue, textLocAssertVal) { 
        
                return { type:"textTerminus", offsetValue:textOffsetValue, textAssertion:textLocAssertVal[1] };
            })(pos0, result0[1], result0[2]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_idAssertion() {
        var result0;
        var pos0;
        
        pos0 = pos;
        result0 = parse_value();
        if (result0 !== null) {
          result0 = (function(offset, idVal) { 
        
                return idVal; 
            })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_textLocationAssertion() {
        var result0, result1;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        result0 = parse_csv();
        result0 = result0 !== null ? result0 : "";
        if (result0 !== null) {
          result1 = parse_parameter();
          result1 = result1 !== null ? result1 : "";
          if (result1 !== null) {
            result0 = [result0, result1];
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, csvVal, paramVal) { 
        
                return { type:"textLocationAssertion", csv:csvVal, parameter:paramVal }; 
            })(pos0, result0[0], result0[1]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_parameter() {
        var result0, result1, result2, result3;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        if (input.charCodeAt(pos) === 59) {
          result0 = ";";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\";\"");
          }
        }
        if (result0 !== null) {
          result1 = parse_valueNoSpace();
          if (result1 !== null) {
            if (input.charCodeAt(pos) === 61) {
              result2 = "=";
              pos++;
            } else {
              result2 = null;
              if (reportFailures === 0) {
                matchFailed("\"=\"");
              }
            }
            if (result2 !== null) {
              result3 = parse_valueNoSpace();
              if (result3 !== null) {
                result0 = [result0, result1, result2, result3];
              } else {
                result0 = null;
                pos = pos1;
              }
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, paramLHSVal, paramRHSVal) { 
        
                return { type:"parameter", LHSValue:paramLHSVal, RHSValue:paramRHSVal }; 
            })(pos0, result0[1], result0[3]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_csv() {
        var result0, result1, result2;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        result0 = parse_value();
        result0 = result0 !== null ? result0 : "";
        if (result0 !== null) {
          if (input.charCodeAt(pos) === 44) {
            result1 = ",";
            pos++;
          } else {
            result1 = null;
            if (reportFailures === 0) {
              matchFailed("\",\"");
            }
          }
          if (result1 !== null) {
            result2 = parse_value();
            result2 = result2 !== null ? result2 : "";
            if (result2 !== null) {
              result0 = [result0, result1, result2];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, preAssertionVal, postAssertionVal) { 
        
                return { type:"csv", preAssertion:preAssertionVal, postAssertion:postAssertionVal }; 
            })(pos0, result0[0], result0[2]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_valueNoSpace() {
        var result0, result1;
        var pos0;
        
        pos0 = pos;
        result1 = parse_escapedSpecialChars();
        if (result1 === null) {
          result1 = parse_character();
        }
        if (result1 !== null) {
          result0 = [];
          while (result1 !== null) {
            result0.push(result1);
            result1 = parse_escapedSpecialChars();
            if (result1 === null) {
              result1 = parse_character();
            }
          }
        } else {
          result0 = null;
        }
        if (result0 !== null) {
          result0 = (function(offset, stringVal) { 
        
                return stringVal.join(''); 
            })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_value() {
        var result0, result1;
        var pos0;
        
        pos0 = pos;
        result1 = parse_escapedSpecialChars();
        if (result1 === null) {
          result1 = parse_character();
          if (result1 === null) {
            result1 = parse_space();
          }
        }
        if (result1 !== null) {
          result0 = [];
          while (result1 !== null) {
            result0.push(result1);
            result1 = parse_escapedSpecialChars();
            if (result1 === null) {
              result1 = parse_character();
              if (result1 === null) {
                result1 = parse_space();
              }
            }
          }
        } else {
          result0 = null;
        }
        if (result0 !== null) {
          result0 = (function(offset, stringVal) { 
        
                return stringVal.join(''); 
            })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_escapedSpecialChars() {
        var result0, result1;
        var pos0, pos1;
        
        pos0 = pos;
        pos1 = pos;
        result0 = parse_circumflex();
        if (result0 !== null) {
          result1 = parse_circumflex();
          if (result1 !== null) {
            result0 = [result0, result1];
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 === null) {
          pos1 = pos;
          result0 = parse_circumflex();
          if (result0 !== null) {
            result1 = parse_squareBracket();
            if (result1 !== null) {
              result0 = [result0, result1];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
          if (result0 === null) {
            pos1 = pos;
            result0 = parse_circumflex();
            if (result0 !== null) {
              result1 = parse_parentheses();
              if (result1 !== null) {
                result0 = [result0, result1];
              } else {
                result0 = null;
                pos = pos1;
              }
            } else {
              result0 = null;
              pos = pos1;
            }
            if (result0 === null) {
              pos1 = pos;
              result0 = parse_circumflex();
              if (result0 !== null) {
                result1 = parse_comma();
                if (result1 !== null) {
                  result0 = [result0, result1];
                } else {
                  result0 = null;
                  pos = pos1;
                }
              } else {
                result0 = null;
                pos = pos1;
              }
              if (result0 === null) {
                pos1 = pos;
                result0 = parse_circumflex();
                if (result0 !== null) {
                  result1 = parse_semicolon();
                  if (result1 !== null) {
                    result0 = [result0, result1];
                  } else {
                    result0 = null;
                    pos = pos1;
                  }
                } else {
                  result0 = null;
                  pos = pos1;
                }
                if (result0 === null) {
                  pos1 = pos;
                  result0 = parse_circumflex();
                  if (result0 !== null) {
                    result1 = parse_equal();
                    if (result1 !== null) {
                      result0 = [result0, result1];
                    } else {
                      result0 = null;
                      pos = pos1;
                    }
                  } else {
                    result0 = null;
                    pos = pos1;
                  }
                }
              }
            }
          }
        }
        if (result0 !== null) {
          result0 = (function(offset, escSpecCharVal) { 
                
                return escSpecCharVal[1]; 
            })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_number() {
        var result0, result1, result2, result3;
        var pos0, pos1, pos2;
        
        pos0 = pos;
        pos1 = pos;
        pos2 = pos;
        if (/^[1-9]/.test(input.charAt(pos))) {
          result0 = input.charAt(pos);
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("[1-9]");
          }
        }
        if (result0 !== null) {
          if (/^[0-9]/.test(input.charAt(pos))) {
            result2 = input.charAt(pos);
            pos++;
          } else {
            result2 = null;
            if (reportFailures === 0) {
              matchFailed("[0-9]");
            }
          }
          if (result2 !== null) {
            result1 = [];
            while (result2 !== null) {
              result1.push(result2);
              if (/^[0-9]/.test(input.charAt(pos))) {
                result2 = input.charAt(pos);
                pos++;
              } else {
                result2 = null;
                if (reportFailures === 0) {
                  matchFailed("[0-9]");
                }
              }
            }
          } else {
            result1 = null;
          }
          if (result1 !== null) {
            result0 = [result0, result1];
          } else {
            result0 = null;
            pos = pos2;
          }
        } else {
          result0 = null;
          pos = pos2;
        }
        if (result0 !== null) {
          if (input.charCodeAt(pos) === 46) {
            result1 = ".";
            pos++;
          } else {
            result1 = null;
            if (reportFailures === 0) {
              matchFailed("\".\"");
            }
          }
          if (result1 !== null) {
            pos2 = pos;
            result2 = [];
            if (/^[0-9]/.test(input.charAt(pos))) {
              result3 = input.charAt(pos);
              pos++;
            } else {
              result3 = null;
              if (reportFailures === 0) {
                matchFailed("[0-9]");
              }
            }
            while (result3 !== null) {
              result2.push(result3);
              if (/^[0-9]/.test(input.charAt(pos))) {
                result3 = input.charAt(pos);
                pos++;
              } else {
                result3 = null;
                if (reportFailures === 0) {
                  matchFailed("[0-9]");
                }
              }
            }
            if (result2 !== null) {
              if (/^[1-9]/.test(input.charAt(pos))) {
                result3 = input.charAt(pos);
                pos++;
              } else {
                result3 = null;
                if (reportFailures === 0) {
                  matchFailed("[1-9]");
                }
              }
              if (result3 !== null) {
                result2 = [result2, result3];
              } else {
                result2 = null;
                pos = pos2;
              }
            } else {
              result2 = null;
              pos = pos2;
            }
            if (result2 !== null) {
              result0 = [result0, result1, result2];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        } else {
          result0 = null;
          pos = pos1;
        }
        if (result0 !== null) {
          result0 = (function(offset, intPartVal, fracPartVal) { 
        
                return intPartVal.join('') + "." + fracPartVal.join(''); 
            })(pos0, result0[0], result0[2]);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_integer() {
        var result0, result1, result2;
        var pos0, pos1;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 48) {
          result0 = "0";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"0\"");
          }
        }
        if (result0 === null) {
          pos1 = pos;
          if (/^[1-9]/.test(input.charAt(pos))) {
            result0 = input.charAt(pos);
            pos++;
          } else {
            result0 = null;
            if (reportFailures === 0) {
              matchFailed("[1-9]");
            }
          }
          if (result0 !== null) {
            result1 = [];
            if (/^[0-9]/.test(input.charAt(pos))) {
              result2 = input.charAt(pos);
              pos++;
            } else {
              result2 = null;
              if (reportFailures === 0) {
                matchFailed("[0-9]");
              }
            }
            while (result2 !== null) {
              result1.push(result2);
              if (/^[0-9]/.test(input.charAt(pos))) {
                result2 = input.charAt(pos);
                pos++;
              } else {
                result2 = null;
                if (reportFailures === 0) {
                  matchFailed("[0-9]");
                }
              }
            }
            if (result1 !== null) {
              result0 = [result0, result1];
            } else {
              result0 = null;
              pos = pos1;
            }
          } else {
            result0 = null;
            pos = pos1;
          }
        }
        if (result0 !== null) {
          result0 = (function(offset, integerVal) { 
        
                if (integerVal === "0") { 
                  return "0";
                } 
                else { 
                  return integerVal[0].concat(integerVal[1].join(''));
                }
            })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_space() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 32) {
          result0 = " ";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\" \"");
          }
        }
        if (result0 !== null) {
          result0 = (function(offset) { return " "; })(pos0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_circumflex() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 94) {
          result0 = "^";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"^\"");
          }
        }
        if (result0 !== null) {
          result0 = (function(offset) { return "^"; })(pos0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_doubleQuote() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 34) {
          result0 = "\"";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"\\\"\"");
          }
        }
        if (result0 !== null) {
          result0 = (function(offset) { return '"'; })(pos0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_squareBracket() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 91) {
          result0 = "[";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"[\"");
          }
        }
        if (result0 === null) {
          if (input.charCodeAt(pos) === 93) {
            result0 = "]";
            pos++;
          } else {
            result0 = null;
            if (reportFailures === 0) {
              matchFailed("\"]\"");
            }
          }
        }
        if (result0 !== null) {
          result0 = (function(offset, bracketVal) { return bracketVal; })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_parentheses() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 40) {
          result0 = "(";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"(\"");
          }
        }
        if (result0 === null) {
          if (input.charCodeAt(pos) === 41) {
            result0 = ")";
            pos++;
          } else {
            result0 = null;
            if (reportFailures === 0) {
              matchFailed("\")\"");
            }
          }
        }
        if (result0 !== null) {
          result0 = (function(offset, paraVal) { return paraVal; })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_comma() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 44) {
          result0 = ",";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\",\"");
          }
        }
        if (result0 !== null) {
          result0 = (function(offset) { return ","; })(pos0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_semicolon() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 59) {
          result0 = ";";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\";\"");
          }
        }
        if (result0 !== null) {
          result0 = (function(offset) { return ";"; })(pos0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_equal() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (input.charCodeAt(pos) === 61) {
          result0 = "=";
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("\"=\"");
          }
        }
        if (result0 !== null) {
          result0 = (function(offset) { return "="; })(pos0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      function parse_character() {
        var result0;
        var pos0;
        
        pos0 = pos;
        if (/^[a-z]/.test(input.charAt(pos))) {
          result0 = input.charAt(pos);
          pos++;
        } else {
          result0 = null;
          if (reportFailures === 0) {
            matchFailed("[a-z]");
          }
        }
        if (result0 === null) {
          if (/^[A-Z]/.test(input.charAt(pos))) {
            result0 = input.charAt(pos);
            pos++;
          } else {
            result0 = null;
            if (reportFailures === 0) {
              matchFailed("[A-Z]");
            }
          }
          if (result0 === null) {
            if (/^[0-9]/.test(input.charAt(pos))) {
              result0 = input.charAt(pos);
              pos++;
            } else {
              result0 = null;
              if (reportFailures === 0) {
                matchFailed("[0-9]");
              }
            }
            if (result0 === null) {
              if (input.charCodeAt(pos) === 45) {
                result0 = "-";
                pos++;
              } else {
                result0 = null;
                if (reportFailures === 0) {
                  matchFailed("\"-\"");
                }
              }
              if (result0 === null) {
                if (input.charCodeAt(pos) === 95) {
                  result0 = "_";
                  pos++;
                } else {
                  result0 = null;
                  if (reportFailures === 0) {
                    matchFailed("\"_\"");
                  }
                }
              }
            }
          }
        }
        if (result0 !== null) {
          result0 = (function(offset, charVal) { return charVal; })(pos0, result0);
        }
        if (result0 === null) {
          pos = pos0;
        }
        return result0;
      }
      
      
      function cleanupExpected(expected) {
        expected.sort();
        
        var lastExpected = null;
        var cleanExpected = [];
        for (var i = 0; i < expected.length; i++) {
          if (expected[i] !== lastExpected) {
            cleanExpected.push(expected[i]);
            lastExpected = expected[i];
          }
        }
        return cleanExpected;
      }
      
      function computeErrorPosition() {
        /*
         * The first idea was to use |String.split| to break the input up to the
         * error position along newlines and derive the line and column from
         * there. However IE's |split| implementation is so broken that it was
         * enough to prevent it.
         */
        
        var line = 1;
        var column = 1;
        var seenCR = false;
        
        for (var i = 0; i < Math.max(pos, rightmostFailuresPos); i++) {
          var ch = input.charAt(i);
          if (ch === "\n") {
            if (!seenCR) { line++; }
            column = 1;
            seenCR = false;
          } else if (ch === "\r" || ch === "\u2028" || ch === "\u2029") {
            line++;
            column = 1;
            seenCR = true;
          } else {
            column++;
            seenCR = false;
          }
        }
        
        return { line: line, column: column };
      }
      
      
      var result = parseFunctions[startRule]();
      
      /*
       * The parser is now in one of the following three states:
       *
       * 1. The parser successfully parsed the whole input.
       *
       *    - |result !== null|
       *    - |pos === input.length|
       *    - |rightmostFailuresExpected| may or may not contain something
       *
       * 2. The parser successfully parsed only a part of the input.
       *
       *    - |result !== null|
       *    - |pos < input.length|
       *    - |rightmostFailuresExpected| may or may not contain something
       *
       * 3. The parser did not successfully parse any part of the input.
       *
       *   - |result === null|
       *   - |pos === 0|
       *   - |rightmostFailuresExpected| contains at least one failure
       *
       * All code following this comment (including called functions) must
       * handle these states.
       */
      if (result === null || pos !== input.length) {
        var offset = Math.max(pos, rightmostFailuresPos);
        var found = offset < input.length ? input.charAt(offset) : null;
        var errorPosition = computeErrorPosition();
        
        throw new this.SyntaxError(
          cleanupExpected(rightmostFailuresExpected),
          found,
          offset,
          errorPosition.line,
          errorPosition.column
        );
      }
      
      return result;
    },
    
    /* Returns the parser source code. */
    toSource: function() { return this._source; }
  };
  
  /* Thrown when a parser encounters a syntax error. */
  
  result.SyntaxError = function(expected, found, offset, line, column) {
    function buildMessage(expected, found) {
      var expectedHumanized, foundHumanized;
      
      switch (expected.length) {
        case 0:
          expectedHumanized = "end of input";
          break;
        case 1:
          expectedHumanized = expected[0];
          break;
        default:
          expectedHumanized = expected.slice(0, expected.length - 1).join(", ")
            + " or "
            + expected[expected.length - 1];
      }
      
      foundHumanized = found ? quote(found) : "end of input";
      
      return "Expected " + expectedHumanized + " but " + foundHumanized + " found.";
    }
    
    this.name = "SyntaxError";
    this.expected = expected;
    this.found = found;
    this.message = buildMessage(expected, found);
    this.offset = offset;
    this.line = line;
    this.column = column;
  };
  
  result.SyntaxError.prototype = Error.prototype;
  
  return result;
})();
 

    // Description: This model contains the implementation for "instructions" included in the EPUB CFI domain specific language (DSL). 
//   Lexing and parsing a CFI produces a set of executable instructions for processing a CFI (represented in the AST). 
//   This object contains a set of functions that implement each of the executable instructions in the AST. 

EPUBcfi.CFIInstructions = {

	// ------------------------------------------------------------------------------------ //
	//  "PUBLIC" METHODS (THE API)                                                          //
	// ------------------------------------------------------------------------------------ //

	// Description: Follows a step
	// Rationale: The use of children() is important here, as this jQuery method returns a tree of xml nodes, EXCLUDING
	//   CDATA and text nodes. When we index into the set of child elements, we are assuming that text nodes have been 
	//   excluded.
	// REFACTORING CANDIDATE: This should be called "followIndexStep"
	getNextNode : function (CFIStepValue, $currNode, classBlacklist, elementBlacklist, idBlacklist) {

		// Find the jquery index for the current node
		var $targetNode;
		if (CFIStepValue % 2 == 0) {

			$targetNode = this.elementNodeStep(CFIStepValue, $currNode, classBlacklist, elementBlacklist, idBlacklist);
		}
		else {

			$targetNode = this.inferTargetTextNode(CFIStepValue, $currNode, classBlacklist, elementBlacklist, idBlacklist);
		}

		return $targetNode;
	},

	// Description: This instruction executes an indirection step, where a resource is retrieved using a 
	//   link contained on a attribute of the target element. The attribute that contains the link differs
	//   depending on the target. 
	// Note: Iframe indirection will (should) fail if the iframe is not from the same domain as its containing script due to 
	//   the cross origin security policy
	followIndirectionStep : function (CFIStepValue, $currNode, $packageDocument, classBlacklist, elementBlacklist, idBlacklist) {

		var that = this;
		var $contentDocument; 
		var $blacklistExcluded;
		var $startElement;
		var $targetNode;

		// TODO: This check must be expanded to all the different types of indirection step
		// Only expects iframes, at the moment
		if ($currNode === undefined || !$currNode.is("iframe")) {

			throw EPUBcfi.NodeTypeError($currNode, "expected an iframe element");
		}

		// Check node type; only iframe indirection is handled, at the moment
		if ($currNode.is("iframe")) {

			// Get content
			$contentDocument = $currNode.contents();

			// Go to the first XHTML element, which will be the first child of the top-level document object
			$blacklistExcluded = this.applyBlacklist($contentDocument.children(), classBlacklist, elementBlacklist, idBlacklist);
			$startElement = $($blacklistExcluded[0]);

			// Follow an index step
			$targetNode = this.getNextNode(CFIStepValue, $startElement, classBlacklist, elementBlacklist, idBlacklist);

			// Return that shit!
			return $targetNode; 
		}

		// TODO: Other types of indirection
		// TODO: $targetNode.is("embed")) : src
		// TODO: ($targetNode.is("object")) : data
		// TODO: ($targetNode.is("image") || $targetNode.is("xlink:href")) : xlink:href
	},

	// Description: Injects an element at the specified text node
	// Arguments: a cfi text termination string, a jquery object to the current node
	textTermination : function ($currNode, textOffset, elementToInject) {

		// Get the first node, this should be a text node
		if ($currNode === undefined) {

			throw EPUBcfi.NodeTypeError($currNode, "expected a terminating node, or node list");
		} 
		else if ($currNode.length === 0) {

			throw EPUBcfi.TerminusError("Text", "Text offset:" + textOffset, "no nodes found for termination condition");
		}

		$currNode = this.injectCFIMarkerIntoText($currNode, textOffset, elementToInject);
		return $currNode;
	},

	// Description: Checks that the id assertion for the node target matches that on 
	//   the found node. 
	targetIdMatchesIdAssertion : function ($foundNode, idAssertion) {

		if ($foundNode.attr("id") === idAssertion) {

			return true;
		}
		else {

			return false;
		}
	},

	// ------------------------------------------------------------------------------------ //
	//  "PRIVATE" HELPERS                                                                   //
	// ------------------------------------------------------------------------------------ //

	// Description: Step reference for xml element node. Expected that CFIStepValue is an even integer
	elementNodeStep : function (CFIStepValue, $currNode, classBlacklist, elementBlacklist, idBlacklist) {

		var $targetNode;
		var $blacklistExcluded;
		var numElements;
		var jqueryTargetNodeIndex = (CFIStepValue / 2) - 1;

		$blacklistExcluded = this.applyBlacklist($currNode.children(), classBlacklist, elementBlacklist, idBlacklist);
		numElements = $blacklistExcluded.length;

		if (this.indexOutOfRange(jqueryTargetNodeIndex, numElements)) {

			throw EPUBcfi.OutOfRangeError(jqueryTargetNodeIndex, numElements - 1, "");
		}

	    $targetNode = $($blacklistExcluded[jqueryTargetNodeIndex]);
		return $targetNode;
	},

	retrieveItemRefHref : function ($itemRefElement, $packageDocument) {

		return $("#" + $itemRefElement.attr("idref"), $packageDocument).attr("href");
	},

	indexOutOfRange : function (targetIndex, numChildElements) {

		return (targetIndex > numChildElements - 1) ? true : false;
	},

	// Rationale: In order to inject an element into a specific position, access to the parent object 
	//   is required. This is obtained with the jquery parent() method. An alternative would be to 
	//   pass in the parent with a filtered list containing only children that are part of the target text node.
	injectCFIMarkerIntoText : function ($textNodeList, textOffset, elementToInject) {

		var nodeNum;
		var currNodeLength;
		var currTextPosition = 0;
		var nodeOffset;
		var originalText;
		var $injectedNode;
		var $newTextNode;
		// The iteration counter may be incorrect here (should be $textNodeList.length - 1 ??)
		for (nodeNum = 0; nodeNum <= $textNodeList.length; nodeNum++) {

			if ($textNodeList[nodeNum].nodeType === 3) {

				currNodeMaxIndex = ($textNodeList[nodeNum].nodeValue.length - 1) + currTextPosition;
				nodeOffset = textOffset - currTextPosition;

				if (currNodeMaxIndex >= textOffset) {

					// This node is going to be split and the components re-inserted
					originalText = $textNodeList[nodeNum].nodeValue;	

					// Before part
				 	$textNodeList[nodeNum].nodeValue = originalText.slice(0, nodeOffset);

					// Injected element
					$injectedNode = $(elementToInject).insertAfter($textNodeList.eq(nodeNum));

					// After part
					$newTextNode = $(document.createTextNode(originalText.slice(nodeOffset, originalText.length)));
					$($newTextNode).insertAfter($injectedNode);

					return $textNodeList.parent();
				}
				else {

					currTextPosition = currTextPosition + currNodeMaxIndex;
				}
			}
		}

		throw EPUBcfi.TerminusError("Text", "Text offset:" + textOffset, "The offset exceeded the length of the text");
	},

	// Description: This method finds a target text node and then injects an element into the appropriate node
	// Arguments: A step value that is an odd integer. A current node with a set of child elements.
	// Rationale: The possibility that cfi marker elements have been injected into a text node at some point previous to 
	//   this method being called (and thus splitting the original text node into two separate text nodes) necessitates that
	//   the set of nodes that compromised the original target text node are inferred and returned.
	// Notes: Passed a current node. This node should have a set of elements under it. This will include at least one text node, 
	//   element nodes (maybe), or possibly a mix. 
	// REFACTORING CANDIDATE: This method is pretty long. Worth investigating to see if it can be refactored into something clearer.
	inferTargetTextNode : function (CFIStepValue, $currNode, classBlacklist, elementBlacklist, idBlacklist) {
		
		var $elementsWithoutMarkers;
		var currTextNodePosition;
		var logicalTargetPosition;
		var nodeNum;
		var $targetTextNodeList;

		// Remove any cfi marker elements from the set of elements. 
		// Rationale: A filtering function is used, as simply using a class selector with jquery appears to 
		//   result in behaviour where text nodes are also filtered out, along with the class element being filtered.
		$elementsWithoutMarkers = this.applyBlacklist($currNode.contents(), classBlacklist, elementBlacklist, idBlacklist);

		// Convert CFIStepValue to logical index; assumes odd integer for the step value
		logicalTargetPosition = (parseInt(CFIStepValue) + 1) / 2;

		// Set text node position counter
		currTextNodePosition = 1;
		$targetTextNodeList = $elementsWithoutMarkers.filter(
			function () {

				if (currTextNodePosition === logicalTargetPosition) {

					// If it's a text node
					if (this.nodeType === 3) {
						return true; 
					}
					// Any other type of node, move onto the next text node
					else {
						currTextNodePosition++; 
						return false;
					}
				}
				// In this case, don't return any elements
				else {

					// If its the last child and it's not a text node, there are no text nodes after it
					// and the currTextNodePosition shouldn't be incremented
					if (this.nodeType !== 3 && this !== $elementsWithoutMarkers.lastChild) {
						currTextNodePosition++;
					}

					return false;
				}
			}
		);

		// The filtering above should have counted the number of "logical" text nodes; this can be used to 
		// detect out of range errors
		if ($targetTextNodeList.length === 0) {

			throw EPUBcfi.OutOfRangeError(logicalTargetPosition, currTextNodePosition - 1, "Index out of range");
		}

		// return the text node list
		return $targetTextNodeList;
	},

	applyBlacklist : function ($elements, classBlacklist, elementBlacklist, idBlacklist) {

        var $filteredElements;

        $filteredElements = $elements.filter(
            function () {

                var $currElement = $(this);
                var includeInList = true;

                if (classBlacklist) {

                	// Filter each element with the class type
                	$.each(classBlacklist, function (index, value) {

	                    if ($currElement.hasClass(value)) {
	                    	includeInList = false;

	                    	// Break this loop
	                        return false;
	                    }
                	});
                }

                if (elementBlacklist) {
                	
	                // For each type of element
	                $.each(elementBlacklist, function (index, value) {

	                    if ($currElement.is(value)) {
	                    	includeInList = false;

	                    	// Break this loop
	                        return false;
	                    }
	                });
				}

				if (idBlacklist) {
                	
	                // For each type of element
	                $.each(idBlacklist, function (index, value) {

	                    if ($currElement.attr("id") === value) {
	                    	includeInList = false;

	                    	// Break this loop
	                        return false;
	                    }
	                });
				}

                return includeInList;
            }
        );

        return $filteredElements;
    }
};




    // Description: This is an interpreter that inteprets an Abstract Syntax Tree (AST) for a CFI. The result of executing the interpreter
//   is to inject an element, or set of elements, into an EPUB content document (which is just an XHTML document). These element(s) will
//   represent the position or area in the EPUB referenced by a CFI.
// Rationale: The AST is a clean and readable expression of the step-terminus structure of a CFI. Although building an interpreter adds to the
//   CFI infrastructure, it provides a number of benefits. First, it emphasizes a clear separation of concerns between lexing/parsing a
//   CFI, which involves some complexity related to escaped and special characters, and the execution of the underlying set of steps 
//   represented by the CFI. Second, it will be easier to extend the interpreter to account for new/altered CFI steps (say for references
//   to vector objects or multiple CFIs) than if lexing, parsing and interpretation were all handled in a single step. Finally, Readium's objective is 
//   to demonstrate implementation of the EPUB 3.0 spec. An implementation with a strong separation of concerns that conforms to 
//   well-understood patterns for DSL processing should be easier to communicate, analyze and understand. 
// REFACTORING CANDIDATE: node type errors shouldn't really be possible if the CFI syntax is correct and the parser is error free. 
//   Might want to make the script die in those instances, once the grammar and interpreter are more stable. 
// REFACTORING CANDIDATE: The use of the 'nodeType' property is confusing as this is a DOM node property and the two are unrelated. 
//   Whoops. There shouldn't be any interference, however, I think this should be changed. 

EPUBcfi.Interpreter = {

    // ------------------------------------------------------------------------------------ //
    //  "PUBLIC" METHODS (THE API)                                                          //
    // ------------------------------------------------------------------------------------ //

    // Description: Find the content document referenced by the spine item. This should be the spine item 
    //   referenced by the first indirection step in the CFI.
    // Rationale: This method is a part of the API so that the reading system can "interact" the content document 
    //   pointed to by a CFI. If this is not a separate step, the processing of the CFI must be tightly coupled with 
    //   the reading system, as it stands now. 
    getContentDocHref : function (CFI, packageDocument, classBlacklist, elementBlacklist, idBlacklist) {

        // Decode for URI/IRI escape characters
        var $packageDocument = $(packageDocument);
        var decodedCFI = decodeURI(CFI);
        var CFIAST = EPUBcfi.Parser.parse(decodedCFI);

        // Check node type; throw error if wrong type
        if (CFIAST === undefined || CFIAST.type !== "CFIAST") { 

            throw EPUBcfi.NodeTypeError(CFIAST, "expected CFI AST root node");
        }

        var $packageElement = $($("package", $packageDocument)[0]);

        // Interpet the path node (the package document step)
        var $currElement = this.interpretIndexStepNode(CFIAST.cfiString.path, $packageElement, classBlacklist, elementBlacklist, idBlacklist);

        // Interpret the local_path node, which is a set of steps and and a terminus condition
        var stepNum = 0;
        var nextStepNode;
        for (stepNum = 0 ; stepNum <= CFIAST.cfiString.localPath.steps.length - 1 ; stepNum++) {
        
            nextStepNode = CFIAST.cfiString.localPath.steps[stepNum];
            if (nextStepNode.type === "indexStep") {

                $currElement = this.interpretIndexStepNode(nextStepNode, $currElement, classBlacklist, elementBlacklist, idBlacklist);
            }
            else if (nextStepNode.type === "indirectionStep") {

                $currElement = this.interpretIndirectionStepNode(nextStepNode, $currElement, $packageDocument, classBlacklist, elementBlacklist, idBlacklist);
            }

            // Found the content document href referenced by the spine item 
            if ($currElement.is("itemref")) {

                return EPUBcfi.CFIInstructions.retrieveItemRefHref($currElement, $packageDocument);
            }
        }

        // TODO: If you get to here, an itemref element was never found - a runtime error. The cfi is misspecified or 
        //   the package document is messed up.
    },

    // Description: Inject an arbirtary html element into a position in a content document referenced by a CFI
    injectElement : function (CFI, contentDocument, elementToInject, classBlacklist, elementBlacklist, idBlacklist) {

        var decodedCFI = decodeURI(CFI);
        var CFIAST = EPUBcfi.Parser.parse(decodedCFI);

        // Find the first indirection step in the local path; follow it like a regular step, as the content document it 
        //   references is already loaded and has been passed to this method
        var stepNum = 0;
        var nextStepNode;
        for (stepNum; stepNum <= CFIAST.cfiString.localPath.steps.length - 1 ; stepNum++) {
        
            nextStepNode = CFIAST.cfiString.localPath.steps[stepNum];
            if (nextStepNode.type === "indirectionStep") {

                // This is now assuming that indirection steps and index steps conform to an interface: an object with stepLength, idAssertion
                nextStepNode.type = "indexStep";
                // Getting the html element and creating a jquery object for it; excluding cfiMarkers
                $currElement = this.interpretIndexStepNode(nextStepNode, $("html", contentDocument), classBlacklist, elementBlacklist, idBlacklist);
                stepNum++ // Increment the step num as this will be passed as the starting point for continuing interpretation
                break;
            }
        }

        // Interpret the rest of the steps
        $currElement = this.interpretLocalPath(CFIAST.cfiString, stepNum, $currElement, classBlacklist, elementBlacklist, idBlacklist);

        // TODO: detect what kind of terminus; for now, text node termini are the only kind implemented
        $currElement = this.interpretTextTerminusNode(CFIAST.cfiString.localPath.termStep, $currElement, elementToInject);

        // Return the element that was injected into
        return $currElement;
    },

    // ------------------------------------------------------------------------------------ //
    //  "PRIVATE" HELPERS                                                                   //
    // ------------------------------------------------------------------------------------ //

    interpretLocalPath : function (cfiStringNode, startStepNum, $currElement, classBlacklist, elementBlacklist, idBlacklist) {

        var stepNum = startStepNum;
        var nextStepNode;
        for (stepNum; stepNum <= cfiStringNode.localPath.steps.length - 1 ; stepNum++) {
        
            nextStepNode = cfiStringNode.localPath.steps[stepNum];
            if (nextStepNode.type === "indexStep") {

                $currElement = this.interpretIndexStepNode(nextStepNode, $currElement, classBlacklist, elementBlacklist, idBlacklist);
            }
            else if (nextStepNode.type === "indirectionStep") {

                $currElement = this.interpretIndirectionStepNode(nextStepNode, $currElement, $packageDocument, classBlacklist, elementBlacklist, idBlacklist);
            }
        }

        return $currElement;
    },

    interpretIndexStepNode : function (indexStepNode, $currElement, classBlacklist, elementBlacklist, idBlacklist) {

        // Check node type; throw error if wrong type
        if (indexStepNode === undefined || indexStepNode.type !== "indexStep") {

            throw EPUBcfi.NodeTypeError(indexStepNode, "expected index step node");
        }

        // Index step
        var $stepTarget = EPUBcfi.CFIInstructions.getNextNode(indexStepNode.stepLength, $currElement, classBlacklist, elementBlacklist, idBlacklist);

        // Check the id assertion, if it exists
        if (indexStepNode.idAssertion) {

            if (!EPUBcfi.CFIInstructions.targetIdMatchesIdAssertion($stepTarget, indexStepNode.idAssertion)) {

                throw EPUBcfi.CFIAssertionError(indexStepNode.idAssertion, $stepTarget.attr('id'), "Id assertion failed");
            }
        }

        return $stepTarget;
    },

    interpretIndirectionStepNode : function (indirectionStepNode, $currElement, $packageDocument, classBlacklist, elementBlacklist, idBlacklist) {

        // Check node type; throw error if wrong type
        if (indirectionStepNode === undefined || indirectionStepNode.type !== "indirectionStep") {

            throw EPUBcfi.NodeTypeError(indirectionStepNode, "expected indirection step node");
        }

        // Indirection step
        var $stepTarget = EPUBcfi.CFIInstructions.followIndirectionStep(
            indirectionStepNode.stepLength, 
            $currElement,
            $packageDocument, 
            classBlacklist, 
            elementBlacklist);

        // Check the id assertion, if it exists
        if (indirectionStepNode.idAssertion) {

            if (!EPUBcfi.CFIInstructions.targetIdMatchesIdAssertion($stepTarget, indirectionStepNode.idAssertion)) {

                throw EPUBcfi.CFIAssertionError(indirectionStepNode.idAssertion, $stepTarget.attr('id'), "Id assertion failed");
            }
        }

        return $stepTarget;
    },

    interpretTextTerminusNode : function (terminusNode, $currElement, elementToInject) {

        if (terminusNode === undefined || terminusNode.type !== "textTerminus") {

            throw EPUBcfi.NodeTypeError(terminusNode, "expected text terminus node");
        }

        var $elementInjectedInto = EPUBcfi.CFIInstructions.textTermination(
            $currElement, 
            terminusNode.offsetValue, 
            elementToInject);

        return $elementInjectedInto;
    }
};

    // Description: This is a set of runtime errors that the CFI interpreter can throw. 
// Rationale: These error types extend the basic javascript error object so error things like the stack trace are 
//   included with the runtime errors. 

// REFACTORING CANDIDATE: This type of error may not be required in the long run. The parser should catch any syntax errors, 
//   provided it is error-free, and as such, the AST should never really have any node type errors, which are essentially errors
//   in the structure of the AST. This error should probably be refactored out when the grammar and interpreter are more stable.
EPUBcfi.NodeTypeError = function (node, message) {

    function NodeTypeError () {

        this.node = node;
    }

    NodeTypeError.prototype = new Error(message);
    NodeTypeError.constructor = NodeTypeError;

    return new NodeTypeError();
};

// REFACTORING CANDIDATE: Might make sense to include some more specifics about the out-of-rangeyness.
EPUBcfi.OutOfRangeError = function (targetIndex, maxIndex, message) {

    function OutOfRangeError () {

        this.targetIndex = targetIndex;
        this.maxIndex = maxIndex;
    }

    OutOfRangeError.prototype = new Error(message);
    OutOfRangeError.constructor = OutOfRangeError()

    return new OutOfRangeError();
};

// REFACTORING CANDIDATE: This is a bit too general to be useful. When I have a better understanding of the type of errors
//   that can occur with the various terminus conditions, it'll make more sense to revisit this. 
EPUBcfi.TerminusError = function (terminusType, terminusCondition, message) {

    function TerminusError () {

        this.terminusType = terminusType;
        this.terminusCondition = terminusCondition;
    }

    TerminusError.prototype = new Error(message);
    TerminusError.constructor = TerminusError();

    return new TerminusError();
};

EPUBcfi.CFIAssertionError = function (expectedAssertion, targetElementAssertion, message) {

    function CFIAssertionError () {

        this.expectedAssertion = expectedAssertion;
        this.targetElementAssertion = targetElementAssertion;
    }

    CFIAssertionError.prototype = new Error(message);
    CFIAssertionError.constructor = CFIAssertionError();

    return new CFIAssertionError();
};


    EPUBcfi.Generator = {

    // Description: Generates a character offset CFI 
    // Arguments: The text node that contains the offset referenced by the cfi, the offset value, the name of the 
    //   content document that contains the text node, the package document for this EPUB.
    generateCharacterOffsetCFI : function (startTextNode, characterOffset, contentDocumentName, packageDocument, classBlacklist, elementBlacklist, idBlacklist) {

        // ------------------------------------------------------------------------------------ //
        //  "PUBLIC" METHODS (THE API)                                                          //
        // ------------------------------------------------------------------------------------ //

        var contentDocCFI;
        var $itemRefStartNode;
        var packageDocCFI;

        // Check that the text node to start from IS a text node
        if (!startTextNode) {
            throw new EPUBcfi.NodeTypeError(startTextNode, "Cannot generate a character offset from a starting point that is not a text node");
        } else if (startTextNode.nodeType != 3) {
            throw new EPUBcfi.NodeTypeError(startTextNode, "Cannot generate a character offset from a starting point that is not a text node");
        }

        // Check that the character offset is within a valid range for the text node supplied
        if (characterOffset < 0) {
            throw new EPUBcfi.OutOfRangeError(characterOffset, 0, "Character offset cannot be less than 0");
        }
        else if (characterOffset > startTextNode.nodeValue.length) {
            throw new EPUBcfi.OutOfRangeError(characterOffset, startTextNode.nodeValue.length - 1, "character offset cannot be greater than the length of the text node");
        }

        // Check that the idref for the content document has been provided
        if (!contentDocumentName) {
            throw new Error("The idref for the content document, as found in the spine, must be supplied");
        }

        // Check that the package document is non-empty and contains an itemref element for the supplied idref
        if (!packageDocument) {
            throw new Error("A package document must be supplied to generate a CFI");
        }
        else if ($($("itemref[idref='" + contentDocumentName + "']", packageDocument)[0]).length === 0) {
            throw new Error("The idref of the content document could not be found in the spine");
        }

        // Call the recursive method to create all the steps up to the head element of the content document (the "html" element)
        contentDocCFI = this.createCFIElementSteps($(startTextNode), characterOffset, "html", classBlacklist, elementBlacklist, idBlacklist);

        // Get the start node (itemref element) that references the content document
        $itemRefStartNode = $("itemref[idref='" + contentDocumentName + "']", $(packageDocument));

        // Create the steps up to the top element of the package document (the "package" element)
        packageDocCFI = this.createCFIElementSteps($itemRefStartNode, characterOffset, "package", classBlacklist, elementBlacklist, idBlacklist);

        // Return the CFI wrapped with "epubcfi()"
        return "epubcfi(" + packageDocCFI + contentDocCFI + ")";
    },

    // ------------------------------------------------------------------------------------ //
    //  "PRIVATE" HELPERS                                                                   //
    // ------------------------------------------------------------------------------------ //

    // Description: Creates a CFI terminating step, to a text node, with a character offset
    // Arguments:
    // Rationale:
    // Notes:
    // REFACTORING CANDIDATE: Some of the parts of this method could be refactored into their own methods
    createCFITextNodeStep : function ($startTextNode, characterOffset, classBlacklist, elementBlacklist, idBlacklist) {

        var $parentNode;
        var $contentsExcludingMarkers;
        var CFIIndex;
        var indexOfTextNode;
        var preAssertion;
        var preAssertionStartIndex;
        var textLength;
        var postAssertion;
        var postAssertionEndIndex;

        // Find text node position in the set of child elements, ignoring any blacklisted elements 
        $parentNode = $startTextNode.parent();
        $contentsExcludingMarkers = EPUBcfi.CFIInstructions.applyBlacklist($parentNode.contents(), classBlacklist, elementBlacklist, idBlacklist);

        // Find the text node index in the parent list, inferring nodes that were originally a single text node
        var prevNodeWasTextNode;
        var indexOfFirstInSequence;
        $.each($contentsExcludingMarkers, 
            function (index) {

                // If this is a text node, check if it matches and return the current index
                if (this.nodeType === 3) {

                    if (this === $startTextNode[0]) {

                        // Set index as the first in the adjacent sequence of text nodes, or as the index of the current node if this 
                        //   node is a standard one sandwiched between two element nodes. 
                        if (prevNodeWasTextNode) {
                            indexOfTextNode = indexOfFirstInSequence;
                        }
                        else {
                            indexOfTextNode = index;
                        }
                        
                        // Break out of .each loop
                        return false; 
                    }

                    // Save this index as the first in sequence of adjacent text nodes, if it is not already set by this point
                    prevNodeWasTextNode = true;
                    if (!indexOfFirstInSequence) {
                        indexOfFirstInSequence = index;
                    }
                }
                // This node is not a text node
                else {
                    prevNodeWasTextNode = false;
                    indexOfFirstInSequence = undefined;
                }
            }
        );

        // Convert the text node index to a CFI odd-integer representation
        CFIIndex = (indexOfTextNode * 2) + 1;

        // TODO: text assertions are not in the grammar yet, I think, or they're just causing problems. This has
        //   been temporarily removed. 

        // Add pre- and post- text assertions
        // preAssertionStartIndex = (characterOffset - 3 >= 0) ? characterOffset - 3 : 0;
        // preAssertion = $startTextNode[0].nodeValue.substring(preAssertionStartIndex, characterOffset);

        // textLength = $startTextNode[0].nodeValue.length;
        // postAssertionEndIndex = (characterOffset + 3 <= textLength) ? characterOffset + 3 : textLength;
        // postAssertion = $startTextNode[0].nodeValue.substring(characterOffset, postAssertionEndIndex);

        // Gotta infer the correct character offset, as well

        // Return the constructed CFI text node step
        return "/" + CFIIndex + ":" + characterOffset;
         // + "[" + preAssertion + "," + postAssertion + "]";
    },

    // Description: A set of adjacent text nodes can be inferred to have been a single text node in the original document. As such, 
    //   if the character offset is specified for one of the adjacent text nodes, the true offset for the original node must be
    //   inferred.
    findOriginalTextNodeCharOffset : function ($startTextNode, specifiedCharacterOffset, classBlacklist, elementBlacklist, idBlacklist) {

        var $parentNode;
        var $contentsExcludingMarkers;
        var textLength;
        
        // Find text node position in the set of child elements, ignoring any cfi markers 
        $parentNode = $startTextNode.parent();
        $contentsExcludingMarkers = EPUBcfi.CFIInstructions.applyBlacklist($parentNode.contents(), classBlacklist, elementBlacklist, idBlacklist);

        // Find the text node number in the list, inferring nodes that were originally a single text node
        var prevNodeWasTextNode;
        var originalCharOffset = -1; // So the character offset is a 0-based index; we'll be adding lengths of text nodes to this number
        $.each($contentsExcludingMarkers, 
            function (index) {

                // If this is a text node, check if it matches and return the current index
                if (this.nodeType === 3) {

                    if (this === $startTextNode[0]) {

                        if (prevNodeWasTextNode) {
                            originalCharOffset = originalCharOffset + specifiedCharacterOffset;
                        }
                        else {
                            originalCharOffset = specifiedCharacterOffset;
                        }

                        return false; // Break out of .each loop
                    }
                    else {

                        originalCharOffset = originalCharOffset + this.length;
                    }

                    // save this index as the first in sequence of adjacent text nodes, if not set
                    prevNodeWasTextNode = true;
                }
                // This node is not a text node
                else {
                    prevNodeWasTextNode = false;
                }
            }
        );

        return originalCharOffset;
    },

    // REFACTORING CANDIDATE: Consider putting the handling of the starting text node into the body of the 
    //   generateCharacterOffsetCfi() method; this way the characterOffset argument could be removed, which 
    //   would clarify the abstraction
    createCFIElementSteps : function ($currNode, characterOffset, topLevelElement, classBlacklist, elementBlacklist, idBlacklist) {

        var textNodeStep;
        var $blacklistExcluded;
        var $parentNode;
        var currNodePosition;
        var CFIPosition;
        var idAssertion;
        var elementStep; 

        if ($currNode[0].nodeType === 3) {

            textNodeStep = this.createCFITextNodeStep($currNode, characterOffset, classBlacklist, elementBlacklist, idBlacklist);
            return this.createCFIElementSteps($currNode.parent(), characterOffset, topLevelElement, classBlacklist, elementBlacklist, idBlacklist) + textNodeStep; 
        }

        // Find position of current node in parent list
        $blacklistExcluded = EPUBcfi.CFIInstructions.applyBlacklist($currNode.parent().children(), classBlacklist, elementBlacklist, idBlacklist);
        $.each($blacklistExcluded, 
            function (index, value) {

                if (this === $currNode[0]) {

                    currNodePosition = index;

                    // Break loop
                    return false;
                }
        });

        // Convert position to the CFI even-integer representation
        CFIPosition = (currNodePosition + 1) * 2;

        // Create CFI step with id assertion, if the element has an id
        if ($currNode.attr("id")) {
            elementStep = "/" + CFIPosition + "[" + $currNode.attr("id") + "]";
        }
        else {
            elementStep = "/" + CFIPosition;
        }

        // If a parent is an html element return the (last) step for this content document, otherwise, continue
        $parentNode = $currNode.parent();
        if ($parentNode.is(topLevelElement)) {
            
            // If the top level node is a type from which an indirection step, add an indirection step character (!)
            // REFACTORING CANDIDATE: It is possible that this should be changed to if (topLevelElement = 'package') do
            //   not return an indirection character. Every other type of top-level element may require an indirection
            //   step to navigate to, thus requiring that ! is always prepended. 
            if (topLevelElement === 'html') {
                return "!" + elementStep;
            }
            else {
                return elementStep;
            }
        }
        else {
            return this.createCFIElementSteps($parentNode, characterOffset, topLevelElement, classBlacklist, elementBlacklist, idBlacklist) + elementStep;
        }
    }
};

    if (global.EPUBcfi) {

        throw new Error('The EPUB cfi library has already been defined');
    }
    else {

        global.EPUBcfi = EPUBcfi;
    }
}) (typeof window === 'undefined' ? this : window);
/*
Copyright 2012 Igor Vaynberg
 
Version: 3.2 Timestamp: Mon Sep 10 10:38:04 PDT 2012

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this work except in
compliance with the License. You may obtain a copy of the License in the LICENSE file, or at:

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under the License is
distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and limitations under the License.
*/
(function(e){"undefined"==typeof e.fn.each2&&e.fn.extend({each2:function(g){for(var i=e([0]),m=-1,s=this.length;++m<s&&(i.context=i[0]=this[m])&&!1!==g.call(i[0],m,i););return this}})})(jQuery);
(function(e,g){function i(a,b){var c=0,d=b.length,j;if("undefined"===typeof a)return-1;if(a.constructor===String)for(;c<d;c+=1){if(0===a.localeCompare(b[c]))return c}else for(;c<d;c+=1)if(j=b[c],j.constructor===String){if(0===j.localeCompare(a))return c}else if(j===a)return c;return-1}function m(a,b){return a===b?!0:a===g||b===g||null===a||null===b?!1:a.constructor===String?0===a.localeCompare(b):b.constructor===String?0===b.localeCompare(a):!1}function s(a,b){var c,d,j;if(null===a||1>a.length)return[];
c=a.split(b);d=0;for(j=c.length;d<j;d+=1)c[d]=e.trim(c[d]);return c}function A(a,b,c){var c=c||g,d;return function(){var j=arguments;window.clearTimeout(d);d=window.setTimeout(function(){b.apply(c,j)},a)}}function l(a){a.preventDefault();a.stopPropagation()}function B(a,b,c){var d=a.toUpperCase().indexOf(b.toUpperCase()),b=b.length;0>d?c.push(a):(c.push(a.substring(0,d)),c.push("<span class='select2-match'>"),c.push(a.substring(d,d+b)),c.push("</span>"),c.push(a.substring(d+b,a.length)))}function C(a){var b,
c=0,d=null,j=a.quietMillis||100;return function(h){window.clearTimeout(b);b=window.setTimeout(function(){var b=c+=1,j=a.data,n=a.transport||e.ajax,f=a.traditional||!1,g=a.type||"GET",j=j.call(this,h.term,h.page,h.context);null!==d&&d.abort();d=n.call(null,{url:a.url,dataType:a.dataType,data:j,type:g,traditional:f,success:function(d){b<c||(d=a.results(d,h.page),h.callback(d))}})},j)}}function D(a){var b=a,c,d=function(a){return""+a.text};e.isArray(b)||(d=b.text,e.isFunction(d)||(c=b.text,d=function(a){return a[c]}),
b=b.results);return function(a){var c=a.term,f={results:[]},k;if(c==="")a.callback({results:b});else{k=function(b,f){var g,t,b=b[0];if(b.children){g={};for(t in b)b.hasOwnProperty(t)&&(g[t]=b[t]);g.children=[];e(b.children).each2(function(a,b){k(b,g.children)});g.children.length&&f.push(g)}else a.matcher(c,d(b))&&f.push(b)};e(b).each2(function(a,b){k(b,f.results)});a.callback(f)}}}function E(a){return e.isFunction(a)?a:function(b){var c=b.term,d={results:[]};e(a).each(function(){var a=this.text!==
g,e=a?this.text:this;if(""===c||b.matcher(c,e))d.results.push(a?this:{id:this,text:this})});b.callback(d)}}function u(a){if(e.isFunction(a))return!0;if(!a)return!1;throw Error("formatterName must be a function or a falsy value");}function v(a){return e.isFunction(a)?a():a}function F(a){var b=0;e.each(a,function(a,d){d.children?b+=F(d.children):b++});return b}function H(a,b,c,d){var e=a,h=!1,f,k,n,o;if(!d.createSearchChoice||!d.tokenSeparators||1>d.tokenSeparators.length)return g;for(;;){h=-1;k=0;
for(n=d.tokenSeparators.length;k<n&&!(o=d.tokenSeparators[k],h=a.indexOf(o),0<=h);k++);if(0>h)break;f=a.substring(0,h);a=a.substring(h+o.length);if(0<f.length&&(f=d.createSearchChoice(f,b),f!==g&&null!==f&&d.id(f)!==g&&null!==d.id(f))){h=!1;k=0;for(n=b.length;k<n;k++)if(m(d.id(f),d.id(b[k]))){h=!0;break}h||c(f)}}if(0!=e.localeCompare(a))return a}function x(a,b){var c=function(){};c.prototype=new a;c.prototype.constructor=c;c.prototype.parent=a.prototype;c.prototype=e.extend(c.prototype,b);return c}
if(window.Select2===g){var f,w,y,z,G,q;f={TAB:9,ENTER:13,ESC:27,SPACE:32,LEFT:37,UP:38,RIGHT:39,DOWN:40,SHIFT:16,CTRL:17,ALT:18,PAGE_UP:33,PAGE_DOWN:34,HOME:36,END:35,BACKSPACE:8,DELETE:46,isArrow:function(a){a=a.which?a.which:a;switch(a){case f.LEFT:case f.RIGHT:case f.UP:case f.DOWN:return!0}return!1},isControl:function(a){switch(a.which){case f.SHIFT:case f.CTRL:case f.ALT:return!0}return a.metaKey?!0:!1},isFunctionKey:function(a){a=a.which?a.which:a;return 112<=a&&123>=a}};var I=1;G=function(){return I++};
e(document).delegate("body","mousemove",function(a){e.data(document,"select2-lastpos",{x:a.pageX,y:a.pageY})});e(document).ready(function(){e(document).delegate("body","mousedown touchend",function(a){var b=e(a.target).closest("div.select2-container").get(0),c;b?e(document).find("div.select2-container-active").each(function(){this!==b&&e(this).data("select2").blur()}):(b=e(a.target).closest("div.select2-drop").get(0),e(document).find("div.select2-drop-active").each(function(){this!==b&&e(this).data("select2").blur()}));
b=e(a.target);c=b.attr("for");"LABEL"===a.target.tagName&&(c&&0<c.length)&&(b=e("#"+c),b=b.data("select2"),b!==g&&(b.focus(),a.preventDefault()))})});w=x(Object,{bind:function(a){var b=this;return function(){a.apply(b,arguments)}},init:function(a){var b,c;this.opts=a=this.prepareOpts(a);this.id=a.id;a.element.data("select2")!==g&&null!==a.element.data("select2")&&this.destroy();this.enabled=!0;this.container=this.createContainer();this.containerId="s2id_"+(a.element.attr("id")||"autogen"+G());this.containerSelector=
"#"+this.containerId.replace(/([;&,\.\+\*\~':"\!\^#$%@\[\]\(\)=>\|])/g,"\\$1");this.container.attr("id",this.containerId);var d=!1,j;this.body=function(){!1===d&&(j=a.element.closest("body"),d=!0);return j};a.element.attr("class")!==g&&this.container.addClass(a.element.attr("class").replace(/validate\[[\S ]+] ?/,""));this.container.css(v(a.containerCss));this.container.addClass(v(a.containerCssClass));this.opts.element.data("select2",this).hide().before(this.container);this.container.data("select2",
this);this.dropdown=this.container.find(".select2-drop");this.dropdown.addClass(v(a.dropdownCssClass));this.dropdown.data("select2",this);this.results=b=this.container.find(".select2-results");this.search=c=this.container.find("input.select2-input");c.attr("tabIndex",this.opts.element.attr("tabIndex"));this.resultsPage=0;this.context=null;this.initContainer();this.initContainerWidth();this.results.bind("mousemove",function(a){var b=e.data(document,"select2-lastpos");(b===g||b.x!==a.pageX||b.y!==a.pageY)&&
e(a.target).trigger("mousemove-filtered",a)});this.dropdown.delegate(".select2-results","mousemove-filtered",this.bind(this.highlightUnderEvent));var h=this.results,f=A(80,function(a){h.trigger("scroll-debounced",a)});h.bind("scroll",function(a){0<=i(a.target,h.get())&&f(a)});this.dropdown.delegate(".select2-results","scroll-debounced",this.bind(this.loadMoreIfNeeded));e.fn.mousewheel&&b.mousewheel(function(a,c,d,e){c=b.scrollTop();0<e&&0>=c-e?(b.scrollTop(0),l(a)):0>e&&b.get(0).scrollHeight-b.scrollTop()+
e<=b.height()&&(b.scrollTop(b.get(0).scrollHeight-b.height()),l(a))});c.bind("keydown",function(){e.data(c,"keyup-change-value")===g&&e.data(c,"keyup-change-value",c.val())});c.bind("keyup",function(){var a=e.data(c,"keyup-change-value");a!==g&&c.val()!==a&&(e.removeData(c,"keyup-change-value"),c.trigger("keyup-change"))});c.bind("keyup-change",this.bind(this.updateResults));c.bind("focus",function(){c.addClass("select2-focused");" "===c.val()&&c.val("")});c.bind("blur",function(){c.removeClass("select2-focused")});
this.dropdown.delegate(".select2-results","mouseup",this.bind(function(a){0<e(a.target).closest(".select2-result-selectable:not(.select2-disabled)").length?(this.highlightUnderEvent(a),this.selectHighlighted(a)):this.focusSearch();l(a)}));this.dropdown.bind("click mouseup mousedown",function(a){a.stopPropagation()});e.isFunction(this.opts.initSelection)&&(this.initSelection(),this.monitorSource());(a.element.is(":disabled")||a.element.is("[readonly='readonly']"))&&this.disable()},destroy:function(){var a=
this.opts.element.data("select2");a!==g&&(a.container.remove(),a.dropdown.remove(),a.opts.element.removeData("select2").unbind(".select2").show())},prepareOpts:function(a){var b,c,d;b=a.element;"select"===b.get(0).tagName.toLowerCase()&&(this.select=c=a.element);c&&e.each("id multiple ajax query createSearchChoice initSelection data tags".split(" "),function(){if(this in a)throw Error("Option '"+this+"' is not allowed for Select2 when attached to a <select> element.");});a=e.extend({},{populateResults:function(b,
c,d){var f,n=this.opts.id,o=this;f=function(b,c,j){var h,l,i,m,r,p,q;h=0;for(l=b.length;h<l;h=h+1){i=b[h];m=n(i)!==g;r=i.children&&i.children.length>0;p=e("<li></li>");p.addClass("select2-results-dept-"+j);p.addClass("select2-result");p.addClass(m?"select2-result-selectable":"select2-result-unselectable");r&&p.addClass("select2-result-with-children");p.addClass(o.opts.formatResultCssClass(i));m=e("<div></div>");m.addClass("select2-result-label");q=a.formatResult(i,m,d);q!==g&&m.html(o.opts.escapeMarkup(q));
p.append(m);if(r){r=e("<ul></ul>");r.addClass("select2-result-sub");f(i.children,r,j+1);p.append(r)}p.data("select2-data",i);c.append(p)}};f(c,b,0)}},e.fn.select2.defaults,a);"function"!==typeof a.id&&(d=a.id,a.id=function(a){return a[d]});if(c)a.query=this.bind(function(a){var c={results:[],more:false},d=a.term,f,n,o;o=function(b,c){var e;if(b.is("option"))a.matcher(d,b.text(),b)&&c.push({id:b.attr("value"),text:b.text(),element:b.get(),css:b.attr("class")});else if(b.is("optgroup")){e={text:b.attr("label"),
children:[],element:b.get(),css:b.attr("class")};b.children().each2(function(a,b){o(b,e.children)});e.children.length>0&&c.push(e)}};f=b.children();if(this.getPlaceholder()!==g&&f.length>0){n=f[0];e(n).text()===""&&(f=f.not(n))}f.each2(function(a,b){o(b,c.results)});a.callback(c)}),a.id=function(a){return a.id},a.formatResultCssClass=function(a){return a.css};else if(!("query"in a))if("ajax"in a){if((c=a.element.data("ajax-url"))&&0<c.length)a.ajax.url=c;a.query=C(a.ajax)}else"data"in a?a.query=D(a.data):
"tags"in a&&(a.query=E(a.tags),a.createSearchChoice=function(a){return{id:a,text:a}},a.initSelection=function(b,c){var d=[];e(s(b.val(),a.separator)).each(function(){var b=this,c=this,j=a.tags;e.isFunction(j)&&(j=j());e(j).each(function(){if(m(this.id,b)){c=this.text;return false}});d.push({id:b,text:c})});c(d)});if("function"!==typeof a.query)throw"query function not defined for Select2 "+a.element.attr("id");return a},monitorSource:function(){this.opts.element.bind("change.select2",this.bind(function(){!0!==
this.opts.element.data("select2-change-triggered")&&this.initSelection()}))},triggerChange:function(a){a=a||{};a=e.extend({},a,{type:"change",val:this.val()});this.opts.element.data("select2-change-triggered",!0);this.opts.element.trigger(a);this.opts.element.data("select2-change-triggered",!1);this.opts.element.click();this.opts.blurOnChange&&this.opts.element.blur()},enable:function(){this.enabled||(this.enabled=!0,this.container.removeClass("select2-container-disabled"))},disable:function(){this.enabled&&
(this.close(),this.enabled=!1,this.container.addClass("select2-container-disabled"))},opened:function(){return this.container.hasClass("select2-dropdown-open")},positionDropdown:function(){var a=this.container.offset(),b=this.container.outerHeight(),c=this.container.outerWidth(),d=this.dropdown.outerHeight(),j=e(window).scrollTop()+document.documentElement.clientHeight,b=a.top+b,f=a.left,j=b+d<=j,g=a.top-d>=this.body().scrollTop(),k=this.dropdown.hasClass("select2-drop-above"),n;"static"!==this.body().css("position")&&
(n=this.body().offset(),b-=n.top,f-=n.left);k?(k=!0,!g&&j&&(k=!1)):(k=!1,!j&&g&&(k=!0));k?(b=a.top-d,this.container.addClass("select2-drop-above"),this.dropdown.addClass("select2-drop-above")):(this.container.removeClass("select2-drop-above"),this.dropdown.removeClass("select2-drop-above"));a=e.extend({top:b,left:f,width:c},v(this.opts.dropdownCss));this.dropdown.css(a)},shouldOpen:function(){var a;if(this.opened())return!1;a=e.Event("open");this.opts.element.trigger(a);return!a.isDefaultPrevented()},
clearDropdownAlignmentPreference:function(){this.container.removeClass("select2-drop-above");this.dropdown.removeClass("select2-drop-above")},open:function(){if(!this.shouldOpen())return!1;window.setTimeout(this.bind(this.opening),1);return!0},opening:function(){var a=this.containerId,b=this.containerSelector,c="scroll."+a,d="resize."+a;this.container.parents().each(function(){e(this).bind(c,function(){var a=e(b);0==a.length&&e(this).unbind(c);a.select2("close")})});e(window).bind(d,function(){var a=
e(b);0==a.length&&e(window).unbind(d);a.select2("close")});this.clearDropdownAlignmentPreference();" "===this.search.val()&&this.search.val("");this.container.addClass("select2-dropdown-open").addClass("select2-container-active");this.updateResults(!0);this.dropdown[0]!==this.body().children().last()[0]&&this.dropdown.detach().appendTo(this.body());this.dropdown.show();this.positionDropdown();this.dropdown.addClass("select2-drop-active");this.ensureHighlightVisible();this.focusSearch()},close:function(){if(this.opened()){var a=
this;this.container.parents().each(function(){e(this).unbind("scroll."+a.containerId)});e(window).unbind("resize."+this.containerId);this.clearDropdownAlignmentPreference();this.dropdown.hide();this.container.removeClass("select2-dropdown-open").removeClass("select2-container-active");this.results.empty();this.clearSearch();this.opts.element.trigger(e.Event("close"))}},clearSearch:function(){},ensureHighlightVisible:function(){var a=this.results,b,c,d,f;c=this.highlight();0>c||(0==c?a.scrollTop(0):
(b=a.find(".select2-result-selectable"),d=e(b[c]),f=d.offset().top+d.outerHeight(),c===b.length-1&&(b=a.find("li.select2-more-results"),0<b.length&&(f=b.offset().top+b.outerHeight())),b=a.offset().top+a.outerHeight(),f>b&&a.scrollTop(a.scrollTop()+(f-b)),d=d.offset().top-a.offset().top,0>d&&a.scrollTop(a.scrollTop()+d)))},moveHighlight:function(a){for(var b=this.results.find(".select2-result-selectable"),c=this.highlight();-1<c&&c<b.length;){var c=c+a,d=e(b[c]);if(d.hasClass("select2-result-selectable")&&
!d.hasClass("select2-disabled")){this.highlight(c);break}}},highlight:function(a){var b=this.results.find(".select2-result-selectable").not(".select2-disabled");if(0===arguments.length)return i(b.filter(".select2-highlighted")[0],b.get());a>=b.length&&(a=b.length-1);0>a&&(a=0);b.removeClass("select2-highlighted");e(b[a]).addClass("select2-highlighted");this.ensureHighlightVisible()},countSelectableResults:function(){return this.results.find(".select2-result-selectable").not(".select2-disabled").length},
highlightUnderEvent:function(a){a=e(a.target).closest(".select2-result-selectable");if(0<a.length&&!a.is(".select2-highlighted")){var b=this.results.find(".select2-result-selectable");this.highlight(b.index(a))}else 0==a.length&&this.results.find(".select2-highlighted").removeClass("select2-highlighted")},loadMoreIfNeeded:function(){var a=this.results,b=a.find("li.select2-more-results"),c,d=this.resultsPage+1,e=this,f=this.search.val(),g=this.context;0!==b.length&&(c=b.offset().top-a.offset().top-
a.height(),0>=c&&(b.addClass("select2-active"),this.opts.query({term:f,page:d,context:g,matcher:this.opts.matcher,callback:this.bind(function(c){e.opened()&&(e.opts.populateResults.call(this,a,c.results,{term:f,page:d,context:g}),!0===c.more?(b.detach().appendTo(a).text(e.opts.formatLoadMore(d+1)),window.setTimeout(function(){e.loadMoreIfNeeded()},10)):b.remove(),e.positionDropdown(),e.resultsPage=d)})})))},tokenize:function(){},updateResults:function(a){function b(){f.scrollTop(0);d.removeClass("select2-active");
k.positionDropdown()}function c(a){f.html(k.opts.escapeMarkup(a));b()}var d=this.search,f=this.results,h=this.opts,i,k=this;if(!(!0!==a&&(!1===this.showSearchInput||!this.opened()))){d.addClass("select2-active");if(1<=h.maximumSelectionSize&&(i=this.data(),e.isArray(i)&&i.length>=h.maximumSelectionSize&&u(h.formatSelectionTooBig,"formatSelectionTooBig"))){c("<li class='select2-selection-limit'>"+h.formatSelectionTooBig(h.maximumSelectionSize)+"</li>");return}d.val().length<h.minimumInputLength&&u(h.formatInputTooShort,
"formatInputTooShort")?c("<li class='select2-no-results'>"+h.formatInputTooShort(d.val(),h.minimumInputLength)+"</li>"):(c("<li class='select2-searching'>"+h.formatSearching()+"</li>"),i=this.tokenize(),i!=g&&null!=i&&d.val(i),this.resultsPage=1,h.query({term:d.val(),page:this.resultsPage,context:null,matcher:h.matcher,callback:this.bind(function(i){var l;this.opened()&&((this.context=i.context===g?null:i.context,this.opts.createSearchChoice&&""!==d.val()&&(l=this.opts.createSearchChoice.call(null,
d.val(),i.results),l!==g&&null!==l&&k.id(l)!==g&&null!==k.id(l)&&0===e(i.results).filter(function(){return m(k.id(this),k.id(l))}).length&&i.results.unshift(l)),0===i.results.length&&u(h.formatNoMatches,"formatNoMatches"))?c("<li class='select2-no-results'>"+h.formatNoMatches(d.val())+"</li>"):(f.empty(),k.opts.populateResults.call(this,f,i.results,{term:d.val(),page:this.resultsPage,context:null}),!0===i.more&&u(h.formatLoadMore,"formatLoadMore")&&(f.append("<li class='select2-more-results'>"+k.opts.escapeMarkup(h.formatLoadMore(this.resultsPage))+
"</li>"),window.setTimeout(function(){k.loadMoreIfNeeded()},10)),this.postprocessResults(i,a),b()))})}))}},cancel:function(){this.close()},blur:function(){this.close();this.container.removeClass("select2-container-active");this.dropdown.removeClass("select2-drop-active");this.search[0]===document.activeElement&&this.search.blur();this.clearSearch();this.selection.find(".select2-search-choice-focus").removeClass("select2-search-choice-focus")},focusSearch:function(){this.search.show();this.search.focus();
window.setTimeout(this.bind(function(){this.search.show();this.search.focus();this.search.val(this.search.val())}),10)},selectHighlighted:function(){var a=this.highlight(),b=this.results.find(".select2-highlighted").not(".select2-disabled"),c=b.closest(".select2-result-selectable").data("select2-data");c&&(b.addClass("select2-disabled"),this.highlight(a),this.onSelect(c))},getPlaceholder:function(){return this.opts.element.attr("placeholder")||this.opts.element.attr("data-placeholder")||this.opts.element.data("placeholder")||
this.opts.placeholder},initContainerWidth:function(){var a=function(){var a,c,d,f;if("off"===this.opts.width)return null;if("element"===this.opts.width)return 0===this.opts.element.outerWidth()?"auto":this.opts.element.outerWidth()+"px";if("copy"===this.opts.width||"resolve"===this.opts.width){a=this.opts.element.attr("style");if(a!==g){a=a.split(";");d=0;for(f=a.length;d<f;d+=1)if(c=a[d].replace(/\s/g,"").match(/width:(([-+]?([0-9]*\.)?[0-9]+)(px|em|ex|%|in|cm|mm|pt|pc))/),null!==c&&1<=c.length)return c[1]}return"resolve"===
this.opts.width?(a=this.opts.element.css("width"),0<a.indexOf("%")?a:0===this.opts.element.outerWidth()?"auto":this.opts.element.outerWidth()+"px"):null}return e.isFunction(this.opts.width)?this.opts.width():this.opts.width}.call(this);null!==a&&this.container.attr("style","width: "+a)}});y=x(w,{createContainer:function(){return e("<div></div>",{"class":"select2-container"}).html("    <a href='#' onclick='return false;' class='select2-choice'>   <span></span><abbr class='select2-search-choice-close' style='display:none;'></abbr>   <div><b></b></div></a>    <div class='select2-drop select2-offscreen'>   <div class='select2-search'>       <input type='text' autocomplete='off' class='select2-input'/>   </div>   <ul class='select2-results'>   </ul></div>")},
opening:function(){this.search.show();this.parent.opening.apply(this,arguments);this.dropdown.removeClass("select2-offscreen")},close:function(){this.opened()&&(this.parent.close.apply(this,arguments),this.dropdown.removeAttr("style").addClass("select2-offscreen").insertAfter(this.selection).show())},focus:function(){this.close();this.selection.focus()},isFocused:function(){return this.selection[0]===document.activeElement},cancel:function(){this.parent.cancel.apply(this,arguments);this.selection.focus()},
initContainer:function(){var a,b=this.dropdown;this.selection=a=this.container.find(".select2-choice");this.search.bind("keydown",this.bind(function(a){if(this.enabled)if(a.which===f.PAGE_UP||a.which===f.PAGE_DOWN)l(a);else if(this.opened())switch(a.which){case f.UP:case f.DOWN:this.moveHighlight(a.which===f.UP?-1:1);l(a);break;case f.TAB:case f.ENTER:this.selectHighlighted();l(a);break;case f.ESC:this.cancel(a),l(a)}else a.which===f.TAB||f.isControl(a)||f.isFunctionKey(a)||a.which===f.ESC||!1===
this.opts.openOnEnter&&a.which===f.ENTER||this.open()}));this.search.bind("focus",this.bind(function(){this.selection.attr("tabIndex","-1")}));this.search.bind("blur",this.bind(function(){this.opened()||this.container.removeClass("select2-container-active");window.setTimeout(this.bind(function(){this.selection.attr("tabIndex",this.opts.element.attr("tabIndex"))}),10)}));a.bind("mousedown",this.bind(function(){this.opened()?(this.close(),this.selection.focus()):this.enabled&&this.open()}));b.bind("mousedown",
this.bind(function(){this.search.focus()}));a.bind("focus",this.bind(function(){this.container.addClass("select2-container-active");this.search.attr("tabIndex","-1")}));a.bind("blur",this.bind(function(){this.opened()||this.container.removeClass("select2-container-active");window.setTimeout(this.bind(function(){this.search.attr("tabIndex",this.opts.element.attr("tabIndex"))}),10)}));a.bind("keydown",this.bind(function(a){if(this.enabled)if(a.which===f.PAGE_UP||a.which===f.PAGE_DOWN)l(a);else if(!(a.which===
f.TAB||f.isControl(a)||f.isFunctionKey(a)||a.which===f.ESC)&&!(!1===this.opts.openOnEnter&&a.which===f.ENTER))if(a.which==f.DELETE)this.opts.allowClear&&this.clear();else{this.open();if(a.which!==f.ENTER&&!(48>a.which)){var b=String.fromCharCode(a.which).toLowerCase();a.shiftKey&&(b=b.toUpperCase());this.search.focus();this.search.val(b)}l(a)}}));a.delegate("abbr","mousedown",this.bind(function(a){this.enabled&&(this.clear(),l(a),this.close(),this.triggerChange(),this.selection.focus())}));this.setPlaceholder();
this.search.bind("focus",this.bind(function(){this.container.addClass("select2-container-active")}))},clear:function(){this.opts.element.val("");this.selection.find("span").empty();this.selection.removeData("select2-data");this.setPlaceholder()},initSelection:function(){if(""===this.opts.element.val())this.close(),this.setPlaceholder();else{var a=this;this.opts.initSelection.call(null,this.opts.element,function(b){b!==g&&null!==b&&(a.updateSelection(b),a.close(),a.setPlaceholder())})}},prepareOpts:function(){var a=
this.parent.prepareOpts.apply(this,arguments);"select"===a.element.get(0).tagName.toLowerCase()&&(a.initSelection=function(a,c){var d=a.find(":selected");e.isFunction(c)&&c({id:d.attr("value"),text:d.text()})});return a},setPlaceholder:function(){var a=this.getPlaceholder();""===this.opts.element.val()&&a!==g&&!(this.select&&""!==this.select.find("option:first").text())&&(this.selection.find("span").html(this.opts.escapeMarkup(a)),this.selection.addClass("select2-default"),this.selection.find("abbr").hide())},
postprocessResults:function(a,b){var c=0,d=this,f=!0;this.results.find(".select2-result-selectable").each2(function(a,b){if(m(d.id(b.data("select2-data")),d.opts.element.val()))return c=a,!1});this.highlight(c);!0===b&&(f=this.showSearchInput=F(a.results)>=this.opts.minimumResultsForSearch,this.dropdown.find(".select2-search")[f?"removeClass":"addClass"]("select2-search-hidden"),e(this.dropdown,this.container)[f?"addClass":"removeClass"]("select2-with-searchbox"))},onSelect:function(a){var b=this.opts.element.val();
this.opts.element.val(this.id(a));this.updateSelection(a);this.close();this.selection.focus();m(b,this.id(a))||this.triggerChange()},updateSelection:function(a){var b=this.selection.find("span");this.selection.data("select2-data",a);b.empty();a=this.opts.formatSelection(a,b);a!==g&&b.append(this.opts.escapeMarkup(a));this.selection.removeClass("select2-default");this.opts.allowClear&&this.getPlaceholder()!==g&&this.selection.find("abbr").show()},val:function(){var a,b=null,c=this;if(0===arguments.length)return this.opts.element.val();
a=arguments[0];if(this.select)this.select.val(a).find(":selected").each2(function(a,c){b={id:c.attr("value"),text:c.text()};return!1}),this.updateSelection(b),this.setPlaceholder();else{if(this.opts.initSelection===g)throw Error("cannot call val() if initSelection() is not defined");a?(this.opts.element.val(a),this.opts.initSelection(this.opts.element,function(a){c.opts.element.val(!a?"":c.id(a));c.updateSelection(a);c.setPlaceholder()})):this.clear()}},clearSearch:function(){this.search.val("")},
data:function(a){var b;if(0===arguments.length)return b=this.selection.data("select2-data"),b==g&&(b=null),b;!a||""===a?this.clear():(this.opts.element.val(!a?"":this.id(a)),this.updateSelection(a))}});z=x(w,{createContainer:function(){return e("<div></div>",{"class":"select2-container select2-container-multi"}).html("    <ul class='select2-choices'>  <li class='select2-search-field'>    <input type='text' autocomplete='off' class='select2-input'>  </li></ul><div class='select2-drop select2-drop-multi' style='display:none;'>   <ul class='select2-results'>   </ul></div>")},
prepareOpts:function(){var a=this.parent.prepareOpts.apply(this,arguments);"select"===a.element.get(0).tagName.toLowerCase()&&(a.initSelection=function(a,c){var d=[];a.find(":selected").each2(function(a,b){d.push({id:b.attr("value"),text:b.text()})});e.isFunction(c)&&c(d)});return a},initContainer:function(){var a;this.searchContainer=this.container.find(".select2-search-field");this.selection=a=this.container.find(".select2-choices");this.search.bind("keydown",this.bind(function(b){if(this.enabled){if(b.which===
f.BACKSPACE&&""===this.search.val()){this.close();var c;c=a.find(".select2-search-choice-focus");if(0<c.length){this.unselect(c.first());this.search.width(10);l(b);return}c=a.find(".select2-search-choice");0<c.length&&c.last().addClass("select2-search-choice-focus")}else a.find(".select2-search-choice-focus").removeClass("select2-search-choice-focus");if(this.opened())switch(b.which){case f.UP:case f.DOWN:this.moveHighlight(b.which===f.UP?-1:1);l(b);return;case f.ENTER:case f.TAB:this.selectHighlighted();
l(b);return;case f.ESC:this.cancel(b);l(b);return}if(!(b.which===f.TAB||f.isControl(b)||f.isFunctionKey(b)||b.which===f.BACKSPACE||b.which===f.ESC)&&!(!1===this.opts.openOnEnter&&b.which===f.ENTER))this.open(),(b.which===f.PAGE_UP||b.which===f.PAGE_DOWN)&&l(b)}}));this.search.bind("keyup",this.bind(this.resizeSearch));this.search.bind("blur",this.bind(function(a){this.container.removeClass("select2-container-active");this.search.removeClass("select2-focused");this.clearSearch();a.stopImmediatePropagation()}));
this.container.delegate(".select2-choices","mousedown",this.bind(function(a){this.enabled&&!(0<e(a.target).closest(".select2-search-choice").length)&&(this.clearPlaceholder(),this.open(),this.focusSearch(),a.preventDefault())}));this.container.delegate(".select2-choices","focus",this.bind(function(){this.enabled&&(this.container.addClass("select2-container-active"),this.dropdown.addClass("select2-drop-active"),this.clearPlaceholder())}));this.clearSearch()},enable:function(){this.enabled||(this.parent.enable.apply(this,
arguments),this.search.removeAttr("disabled"))},disable:function(){this.enabled&&(this.parent.disable.apply(this,arguments),this.search.attr("disabled",!0))},initSelection:function(){""===this.opts.element.val()&&(this.updateSelection([]),this.close(),this.clearSearch());if(this.select||""!==this.opts.element.val()){var a=this;this.opts.initSelection.call(null,this.opts.element,function(b){if(b!==g&&b!==null){a.updateSelection(b);a.close();a.clearSearch()}})}},clearSearch:function(){var a=this.getPlaceholder();
a!==g&&0===this.getVal().length&&!1===this.search.hasClass("select2-focused")?(this.search.val(a).addClass("select2-default"),this.resizeSearch()):this.search.val(" ").width(10)},clearPlaceholder:function(){this.search.hasClass("select2-default")?this.search.val("").removeClass("select2-default"):" "===this.search.val()&&this.search.val("")},opening:function(){this.parent.opening.apply(this,arguments);this.clearPlaceholder();this.resizeSearch();this.focusSearch()},close:function(){this.opened()&&
this.parent.close.apply(this,arguments)},focus:function(){this.close();this.search.focus()},isFocused:function(){return this.search.hasClass("select2-focused")},updateSelection:function(a){var b=[],c=[],d=this;e(a).each(function(){0>i(d.id(this),b)&&(b.push(d.id(this)),c.push(this))});a=c;this.selection.find(".select2-search-choice").remove();e(a).each(function(){d.addSelectedChoice(this)});d.postprocessResults()},tokenize:function(){var a=this.search.val(),a=this.opts.tokenizer(a,this.data(),this.bind(this.onSelect),
this.opts);null!=a&&a!=g&&(this.search.val(a),0<a.length&&this.open())},onSelect:function(a){this.addSelectedChoice(a);this.select&&this.postprocessResults();this.opts.closeOnSelect?(this.close(),this.search.width(10)):0<this.countSelectableResults()?(this.search.width(10),this.resizeSearch(),this.positionDropdown()):this.close();this.triggerChange({added:a});this.focusSearch()},cancel:function(){this.close();this.focusSearch()},addSelectedChoice:function(a){var b=e("<li class='select2-search-choice'>    <div></div>    <a href='#' onclick='return false;' class='select2-search-choice-close' tabindex='-1'></a></li>"),
c=this.id(a),d=this.getVal(),f;f=this.opts.formatSelection(a,b);b.find("div").replaceWith("<div>"+this.opts.escapeMarkup(f)+"</div>");b.find(".select2-search-choice-close").bind("mousedown",l).bind("click dblclick",this.bind(function(a){this.enabled&&(e(a.target).closest(".select2-search-choice").fadeOut("fast",this.bind(function(){this.unselect(e(a.target));this.selection.find(".select2-search-choice-focus").removeClass("select2-search-choice-focus");this.close();this.focusSearch()})).dequeue(),
l(a))})).bind("focus",this.bind(function(){this.enabled&&(this.container.addClass("select2-container-active"),this.dropdown.addClass("select2-drop-active"))}));b.data("select2-data",a);b.insertBefore(this.searchContainer);d.push(c);this.setVal(d)},unselect:function(a){var b=this.getVal(),c,d,a=a.closest(".select2-search-choice");if(0===a.length)throw"Invalid argument: "+a+". Must be .select2-search-choice";c=a.data("select2-data");d=i(this.id(c),b);0<=d&&(b.splice(d,1),this.setVal(b),this.select&&
this.postprocessResults());a.remove();this.triggerChange({removed:c})},postprocessResults:function(){var a=this.getVal(),b=this.results.find(".select2-result-selectable"),c=this.results.find(".select2-result-with-children"),d=this;b.each2(function(b,c){var e=d.id(c.data("select2-data"));0<=i(e,a)?c.addClass("select2-disabled").removeClass("select2-result-selectable"):c.removeClass("select2-disabled").addClass("select2-result-selectable")});c.each2(function(a,b){0==b.find(".select2-result-selectable").length?
b.addClass("select2-disabled"):b.removeClass("select2-disabled")});b.each2(function(a,b){if(!b.hasClass("select2-disabled")&&b.hasClass("select2-result-selectable"))return d.highlight(0),!1})},resizeSearch:function(){var a,b,c,d,f=this.search.outerWidth()-this.search.width();a=this.search;q||(c=a[0].currentStyle||window.getComputedStyle(a[0],null),q=e("<div></div>").css({position:"absolute",left:"-10000px",top:"-10000px",display:"none",fontSize:c.fontSize,fontFamily:c.fontFamily,fontStyle:c.fontStyle,
fontWeight:c.fontWeight,letterSpacing:c.letterSpacing,textTransform:c.textTransform,whiteSpace:"nowrap"}),e("body").append(q));q.text(a.val());a=q.width()+10;b=this.search.offset().left;c=this.selection.width();d=this.selection.offset().left;b=c-(b-d)-f;b<a&&(b=c-f);40>b&&(b=c-f);this.search.width(b)},getVal:function(){var a;if(this.select)return a=this.select.val(),null===a?[]:a;a=this.opts.element.val();return s(a,this.opts.separator)},setVal:function(a){var b;this.select?this.select.val(a):(b=
[],e(a).each(function(){0>i(this,b)&&b.push(this)}),this.opts.element.val(0===b.length?"":b.join(this.opts.separator)))},val:function(){var a,b=[],c=this;if(0===arguments.length)return this.getVal();if(a=arguments[0])if(this.setVal(a),this.select)this.select.find(":selected").each(function(){b.push({id:e(this).attr("value"),text:e(this).text()})}),this.updateSelection(b);else{if(this.opts.initSelection===g)throw Error("val() cannot be called if initSelection() is not defined");this.opts.initSelection(this.opts.element,
function(a){var b=e(a).map(c.id);c.setVal(b);c.updateSelection(a);c.clearSearch()})}else this.opts.element.val(""),this.updateSelection([]);this.clearSearch()},onSortStart:function(){if(this.select)throw Error("Sorting of elements is not supported when attached to <select>. Attach to <input type='hidden'/> instead.");this.search.width(0);this.searchContainer.hide()},onSortEnd:function(){var a=[],b=this;this.searchContainer.show();this.searchContainer.appendTo(this.searchContainer.parent());this.resizeSearch();
this.selection.find(".select2-search-choice").each(function(){a.push(b.opts.id(e(this).data("select2-data")))});this.setVal(a);this.triggerChange()},data:function(a){var b=this,c;if(0===arguments.length)return this.selection.find(".select2-search-choice").map(function(){return e(this).data("select2-data")}).get();a||(a=[]);c=e.map(a,function(a){return b.opts.id(a)});this.setVal(c);this.updateSelection(a);this.clearSearch()}});e.fn.select2=function(){var a=Array.prototype.slice.call(arguments,0),b,
c,d,f,h="val destroy opened open close focus isFocused container onSortStart onSortEnd enable disable positionDropdown data".split(" ");this.each(function(){if(0===a.length||"object"===typeof a[0])b=0===a.length?{}:e.extend({},a[0]),b.element=e(this),"select"===b.element.get(0).tagName.toLowerCase()?f=b.element.attr("multiple"):(f=b.multiple||!1,"tags"in b&&(b.multiple=f=!0)),c=f?new z:new y,c.init(b);else if("string"===typeof a[0]){if(0>i(a[0],h))throw"Unknown method: "+a[0];d=g;c=e(this).data("select2");
if(c!==g&&(d="container"===a[0]?c.container:c[a[0]].apply(c,a.slice(1)),d!==g))return!1}else throw"Invalid arguments to select2 plugin: "+a;});return d===g?this:d};e.fn.select2.defaults={width:"copy",closeOnSelect:!0,openOnEnter:!0,containerCss:{},dropdownCss:{},containerCssClass:"",dropdownCssClass:"",formatResult:function(a,b,c){b=[];B(a.text,c.term,b);return b.join("")},formatSelection:function(a){return a?a.text:g},formatResultCssClass:function(){return g},formatNoMatches:function(){return"No matches found"},
formatInputTooShort:function(a,b){return"Please enter "+(b-a.length)+" more characters"},formatSelectionTooBig:function(a){return"You can only select "+a+" item"+(1==a?"":"s")},formatLoadMore:function(){return"Loading more results..."},formatSearching:function(){return"Searching..."},minimumResultsForSearch:0,minimumInputLength:0,maximumSelectionSize:0,id:function(a){return a.id},matcher:function(a,b){return 0<=b.toUpperCase().indexOf(a.toUpperCase())},separator:",",tokenSeparators:[],tokenizer:H,
escapeMarkup:function(a){return a&&"string"===typeof a?a.replace(/&/g,"&amp;"):a},blurOnChange:!1};window.Select2={query:{ajax:C,local:D,tags:E},util:{debounce:A,markMatch:B},"class":{"abstract":w,single:y,multi:z}}}})(jQuery);
